@rem Gradle startup script for Windows
@rem
@if "%DEBUG%"=="" @echo off
@rem Add default JVM options here.
set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"
set JAVA_HOME_TRY_PATHS=C:\Program Files\Java\jdk-17
set APP_HOME=%~dp0
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not defined JAVA_HOME goto fail
set JAVA_EXE=%JAVA_HOME%\bin\java.exe
"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
goto mainEnd
:fail
echo Error: JAVA_HOME is not set.
:mainEnd
