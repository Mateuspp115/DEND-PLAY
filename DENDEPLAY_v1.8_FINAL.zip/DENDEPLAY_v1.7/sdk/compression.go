// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package sdk

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
)

// ══════════════════════════════════════════════════════════
// Compressor — gzip para cache em disco
//
// Reduz o espaço usado pelo cache em ~60-80% para JSON
// (dados de busca e episódios são altamente compressíveis).
// Reservado para uso futuro na compressão do DiskCache.
// ══════════════════════════════════════════════════════════

// CompressJSON serializa + comprime com gzip.
func CompressJSON(data interface{}) ([]byte, error) {
	raw, err := json.Marshal(data)
	if err != nil {
		return nil, fmt.Errorf("marshal: %w", err)
	}
	var buf bytes.Buffer
	gz := gzip.NewWriter(&buf)
	if _, err := gz.Write(raw); err != nil {
		return nil, fmt.Errorf("gzip write: %w", err)
	}
	if err := gz.Close(); err != nil {
		return nil, fmt.Errorf("gzip close: %w", err)
	}
	return buf.Bytes(), nil
}

// DecompressJSON descomprime gzip + deserializa para target.
func DecompressJSON(compressed []byte, target interface{}) error {
	r, err := gzip.NewReader(bytes.NewReader(compressed))
	if err != nil {
		return fmt.Errorf("gzip reader: %w", err)
	}
	defer r.Close()
	raw, err := io.ReadAll(r)
	if err != nil {
		return fmt.Errorf("gzip read: %w", err)
	}
	return json.Unmarshal(raw, target)
}

// CompressString comprime uma string e retorna bytes gzip.
func CompressString(s string) ([]byte, error) {
	var buf bytes.Buffer
	gz := gzip.NewWriter(&buf)
	if _, err := gz.Write([]byte(s)); err != nil {
		return nil, err
	}
	if err := gz.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// DecompressString descomprime bytes gzip para string.
func DecompressString(compressed []byte) (string, error) {
	r, err := gzip.NewReader(bytes.NewReader(compressed))
	if err != nil {
		return "", err
	}
	defer r.Close()
	raw, err := io.ReadAll(r)
	if err != nil {
		return "", err
	}
	return string(raw), nil
}
