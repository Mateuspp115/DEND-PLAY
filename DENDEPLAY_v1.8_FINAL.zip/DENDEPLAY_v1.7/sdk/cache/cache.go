// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

package cache

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type entry struct {
	Value   string    `json:"v"`
	Expires time.Time `json:"e"`
}

type DiskCache struct {
	mu     sync.RWMutex
	mem    map[string]*entry
	dir    string
	maxMem int
}

func NewDiskCache(dir string) (*DiskCache, error) {
	if err := os.MkdirAll(dir, 0750); err != nil {
		return nil, err
	}
	return &DiskCache{mem: make(map[string]*entry), dir: dir, maxMem: 500}, nil
}

func (c *DiskCache) Get(key string) string {
	c.mu.RLock()
	e, ok := c.mem[key]
	c.mu.RUnlock()
	if ok {
		if time.Now().Before(e.Expires) { return e.Value }
		c.del(key); return ""
	}
	// Tenta o path novo (SHA256) e depois o legado para compatibilidade
	data, err := os.ReadFile(c.path(key))
	if err != nil {
		data, err = os.ReadFile(c.legacyPath(key))
		if err != nil { return "" }
	}
	var de entry
	if json.Unmarshal(data, &de) != nil { return "" }
	if time.Now().After(de.Expires) { os.Remove(c.path(key)); return "" }
	c.mu.Lock()
	if len(c.mem) < c.maxMem { c.mem[key] = &de }
	c.mu.Unlock()
	return de.Value
}

func (c *DiskCache) Set(key, value string, ttl time.Duration) {
	e := &entry{Value: value, Expires: time.Now().Add(ttl)}
	c.mu.Lock()
	if len(c.mem) >= c.maxMem { for k := range c.mem { delete(c.mem, k); break } }
	c.mem[key] = e
	c.mu.Unlock()
	go func() {
		b, _ := json.Marshal(e)
		os.WriteFile(c.path(key), b, 0600)
	}()
}

func (c *DiskCache) Clear() {
	c.mu.Lock(); c.mem = make(map[string]*entry); c.mu.Unlock()
	os.RemoveAll(c.dir); os.MkdirAll(c.dir, 0750)
}

func (c *DiskCache) Size() int64 {
	var total int64
	filepath.Walk(c.dir, func(_ string, info os.FileInfo, err error) error {
		if err == nil && !info.IsDir() { total += info.Size() }
		return nil
	})
	return total
}

func (c *DiskCache) del(key string) {
	c.mu.Lock(); delete(c.mem, key); c.mu.Unlock()
	os.Remove(c.path(key))
}

func (c *DiskCache) path(key string) string {
	// Usa SHA256 para gerar nome de arquivo único — elimina colisões
	// que ocorriam ao sanitizar caracteres especiais para '_'
	h := sha256.Sum256([]byte(key))
	return filepath.Join(c.dir, hex.EncodeToString(h[:])+".cache")
}

// legacyPath retorna o caminho antigo (sanitização simples) — usado apenas
// para migração transparente de entradas gravadas antes desta versão.
func (c *DiskCache) legacyPath(key string) string {
	safe := strings.Map(func(r rune) rune {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '_' || r == '-' {
			return r
		}
		return '_'
	}, key)
	if len(safe) > 120 { safe = safe[:120] }
	return filepath.Join(c.dir, safe+".cache")
}
