// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

package download

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type Status string

const (
	StatusQueued    Status = "queued"
	StatusActive    Status = "active"
	StatusPaused    Status = "paused"
	StatusCompleted Status = "completed"
	StatusFailed    Status = "failed"
	StatusCancelled Status = "cancelled"
)

type Request struct {
	MediaID    string
	EpisodeURL string
	Quality    string
	Title      string
	Episode    int
}

type Download struct {
	ID         string    `json:"id"`
	MediaID    string    `json:"media_id"`
	Title      string    `json:"title"`
	Episode    int       `json:"episode"`
	Status     Status    `json:"status"`
	Progress   int       `json:"progress"`
	FilePath   string    `json:"file_path,omitempty"`
	FileSize   int64     `json:"file_size"`
	Downloaded int64     `json:"downloaded"`
	Speed      string    `json:"speed,omitempty"`
	ETA        string    `json:"eta,omitempty"`
	Error      string    `json:"error,omitempty"`
	CreatedAt  time.Time `json:"created_at"`
}

type active struct {
	dl     *Download
	cancel context.CancelFunc
	mu     sync.Mutex
	url    string // URL original do episódio, necessária para retomar o download
}

type Manager struct {
	mu        sync.RWMutex
	downloads map[string]*active
	outputDir string
	client    *http.Client
}

func NewManager(outputDir string) *Manager {
	return &Manager{
		downloads: make(map[string]*active),
		outputDir: outputDir,
		client:    &http.Client{Timeout: 0},
	}
}

func (m *Manager) Start(req Request) (string, error) {
	id := fmt.Sprintf("%d", time.Now().UnixNano())[:8]
	os.MkdirAll(m.outputDir, 0750)
	safe  := sanitize(req.Title)
	fpath := filepath.Join(m.outputDir, safe, fmt.Sprintf("ep%02d.mp4", req.Episode))
	dl    := &Download{ID: id, MediaID: req.MediaID, Title: req.Title, Episode: req.Episode,
		Status: StatusQueued, FilePath: fpath, CreatedAt: time.Now()}
	ctx, cancel := context.WithCancel(context.Background())
	ad := &active{dl: dl, cancel: cancel, url: req.EpisodeURL}
	m.mu.Lock(); m.downloads[id] = ad; m.mu.Unlock()
	go m.run(ctx, ad, req.EpisodeURL)
	return id, nil
}

func (m *Manager) run(ctx context.Context, ad *active, videoURL string) {
	ad.mu.Lock(); ad.dl.Status = StatusActive; ad.mu.Unlock()
	os.MkdirAll(filepath.Dir(ad.dl.FilePath), 0750)
	req, err := http.NewRequestWithContext(ctx, "GET", videoURL, nil)
	if err != nil { m.setErr(ad, err); return }
	resp, err := m.client.Do(req)
	if err != nil { m.setErr(ad, err); return }
	defer resp.Body.Close()
	total := resp.ContentLength
	ad.mu.Lock(); ad.dl.FileSize = total; ad.mu.Unlock()
	f, err := os.Create(ad.dl.FilePath)
	if err != nil { m.setErr(ad, err); return }
	defer f.Close()
	buf := make([]byte, 32*1024)
	var dl int64
	start := time.Now()
	for {
		select { case <-ctx.Done(): return; default: }
		n, err := resp.Body.Read(buf)
		if n > 0 {
			f.Write(buf[:n]); dl += int64(n)
			elapsed := time.Since(start).Seconds()
			speed   := float64(dl) / elapsed
			prog    := 0
			eta     := ""
			if total > 0 {
				prog = int(float64(dl) / float64(total) * 100)
				remaining := float64(total-dl) / speed
				if remaining > 0 && speed > 0 {
					eta = fmtETA(remaining)
				}
			}
			ad.mu.Lock()
			ad.dl.Downloaded = dl; ad.dl.Progress = prog
			ad.dl.Speed = fmtSpeed(speed); ad.dl.ETA = eta
			ad.mu.Unlock()
		}
		if err != nil {
			if err == io.EOF { break }
			m.setErr(ad, err); return
		}
	}
	ad.mu.Lock(); ad.dl.Status = StatusCompleted; ad.dl.Progress = 100; ad.mu.Unlock()
}

func (m *Manager) Pause(id string) error {
	m.mu.RLock(); ad, ok := m.downloads[id]; m.mu.RUnlock()
	if !ok { return fmt.Errorf("not found") }
	ad.mu.Lock(); ad.dl.Status = StatusPaused; ad.mu.Unlock()
	ad.cancel(); return nil
}
func (m *Manager) Resume(id string) error {
	m.mu.RLock(); ad, ok := m.downloads[id]; m.mu.RUnlock()
	if !ok { return fmt.Errorf("not found") }
	ctx, cancel := context.WithCancel(context.Background())
	ad.cancel = cancel
	go m.run(ctx, ad, ad.url) // usa a URL original armazenada no Start()
	return nil
}
func (m *Manager) Cancel(id string) {
	m.mu.Lock(); ad, ok := m.downloads[id]; if ok { delete(m.downloads, id) }; m.mu.Unlock()
	if ok { ad.cancel(); os.Remove(ad.dl.FilePath) }
}
func (m *Manager) List() []*Download {
	m.mu.RLock(); defer m.mu.RUnlock()
	var list []*Download
	for _, ad := range m.downloads { ad.mu.Lock(); cp := *ad.dl; ad.mu.Unlock(); list = append(list, &cp) }
	return list
}
func (m *Manager) GetProgress(id string) int {
	m.mu.RLock(); ad, ok := m.downloads[id]; m.mu.RUnlock()
	if !ok { return -1 }; ad.mu.Lock(); defer ad.mu.Unlock(); return ad.dl.Progress
}
func (m *Manager) GetFilePath(id string) string {
	m.mu.RLock(); ad, ok := m.downloads[id]; m.mu.RUnlock()
	if !ok { return "" }; ad.mu.Lock(); defer ad.mu.Unlock()
	if ad.dl.Status == StatusCompleted { return ad.dl.FilePath }; return ""
}
func (m *Manager) setErr(ad *active, err error) {
	ad.mu.Lock(); ad.dl.Status = StatusFailed; ad.dl.Error = err.Error(); ad.mu.Unlock()
}
func sanitize(s string) string {
	return strings.Map(func(r rune) rune {
		if r == '/' || r == '\\' || r == ':' || r == '*' || r == '?' || r == '"' || r == '<' || r == '>' || r == '|' { return '_' }
		return r
	}, s)
}
func fmtSpeed(bps float64) string {
	if bps < 1024 { return fmt.Sprintf("%.0fB/s", bps) }
	if bps < 1024*1024 { return fmt.Sprintf("%.1fKB/s", bps/1024) }
	return fmt.Sprintf("%.1fMB/s", bps/(1024*1024))
}

func fmtETA(secs float64) string {
	s := int(secs)
	if s < 60  { return fmt.Sprintf("%ds", s) }
	if s < 3600 { return fmt.Sprintf("%dm%02ds", s/60, s%60) }
	return fmt.Sprintf("%dh%02dm", s/3600, (s%3600)/60)
}
