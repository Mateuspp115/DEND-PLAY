// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

package userdata

import (
	"encoding/json"
	"os"
	"strconv"
	"sync"
	"time"
)

type WatchedMedia struct {
	MediaID   string    `json:"media_id"`
	Title     string    `json:"title"`
	Episode   int       `json:"episode"`
	Provider  string    `json:"provider"`
	ImageURL  string    `json:"image_url"`
	WatchedAt time.Time `json:"watched_at"`
	Duration  int       `json:"duration"`
	Position  int       `json:"position"`
	Completed bool      `json:"completed"`
}

type FavoriteMedia struct {
	MediaID   string    `json:"media_id"`
	Title     string    `json:"title"`
	Provider  string    `json:"provider"`
	ImageURL  string    `json:"image_url"`
	MediaType string    `json:"media_type"`
	AddedAt   time.Time `json:"added_at"`
}

type WatchProgress struct {
	MediaID  string    `json:"media_id"`
	Episode  int       `json:"episode"`
	Position int       `json:"position"`
	Duration int       `json:"duration"`
	Percent  int       `json:"percent"`
	Updated  time.Time `json:"updated_at"`
}

type storeData struct {
	History   []WatchedMedia          `json:"history"`
	Favorites []FavoriteMedia         `json:"favorites"`
	Progress  map[string]WatchProgress `json:"progress"`
}

type Store struct {
	mu   sync.RWMutex
	path string
	data storeData
}

func NewStore(path string) (*Store, error) {
	s := &Store{path: path, data: storeData{Progress: make(map[string]WatchProgress)}}
	if raw, err := os.ReadFile(path); err == nil { json.Unmarshal(raw, &s.data) }
	if s.data.Progress == nil { s.data.Progress = make(map[string]WatchProgress) }
	return s, nil
}

func (s *Store) AddToHistory(wm WatchedMedia) {
	s.mu.Lock(); defer s.mu.Unlock()
	wm.WatchedAt = time.Now()
	for i, h := range s.data.History {
		if h.MediaID == wm.MediaID && h.Episode == wm.Episode { s.data.History[i] = wm; s.save(); return }
	}
	s.data.History = append([]WatchedMedia{wm}, s.data.History...)
	if len(s.data.History) > 500 { s.data.History = s.data.History[:500] }
	s.save()
}

func (s *Store) GetHistory() []WatchedMedia {
	s.mu.RLock(); defer s.mu.RUnlock()
	r := make([]WatchedMedia, len(s.data.History)); copy(r, s.data.History); return r
}

func (s *Store) AddToFavorites(fm FavoriteMedia) {
	s.mu.Lock(); defer s.mu.Unlock()
	fm.AddedAt = time.Now()
	for _, f := range s.data.Favorites { if f.MediaID == fm.MediaID { return } }
	s.data.Favorites = append(s.data.Favorites, fm); s.save()
}

func (s *Store) RemoveFromFavorites(id string) {
	s.mu.Lock(); defer s.mu.Unlock()
	var f []FavoriteMedia
	for _, fav := range s.data.Favorites { if fav.MediaID != id { f = append(f, fav) } }
	s.data.Favorites = f; s.save()
}

func (s *Store) GetFavorites() []FavoriteMedia {
	s.mu.RLock(); defer s.mu.RUnlock()
	r := make([]FavoriteMedia, len(s.data.Favorites)); copy(r, s.data.Favorites); return r
}

func (s *Store) UpdateProgress(mediaID string, ep, pos, dur int) {
	s.mu.Lock(); defer s.mu.Unlock()
	pct := 0; if dur > 0 { pct = int(float64(pos) / float64(dur) * 100) }
	key := mediaID + ":" + strconv.Itoa(ep)
	s.data.Progress[key] = WatchProgress{
		MediaID: mediaID, Episode: ep, Position: pos, Duration: dur, Percent: pct, Updated: time.Now(),
	}; s.save()
}

func (s *Store) GetProgress(mediaID string, ep int) WatchProgress {
	s.mu.RLock(); defer s.mu.RUnlock()
	return s.data.Progress[mediaID+":"+strconv.Itoa(ep)]
}

func (s *Store) save() {
	b, _ := json.Marshal(s.data); os.WriteFile(s.path, b, 0600)
}
