// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package sdk

import (
	"context"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// ══════════════════════════════════════════════════════════
// SearchWithContext — busca paralela com cancelamento
//
// Melhorias em relação ao Manager base:
//   - Context propagado para cada provider
//   - Early return configurável (padrão: 8 resultados em 1.2s)
//   - Cancelamento automático quando suficiente
//   - Deduplicação por título normalizado
// ══════════════════════════════════════════════════════════

// SearchProvider interface mínima para a busca contextual
type SearchProvider interface {
	ID() string
	Search(ctx context.Context, query string) ([]SearchResultItem, error)
}

type SearchResultItem struct {
	ID        string  `json:"id"`
	Title     string  `json:"title"`
	ImageURL  string  `json:"image_url"`
	URL       string  `json:"url"`
	Provider  string  `json:"provider"`
	MediaType string  `json:"media_type"`
	Year      string  `json:"year,omitempty"`
	Rating    float64 `json:"rating,omitempty"`
	Language  string  `json:"language,omitempty"`
}

type SearchOptions struct {
	Timeout        time.Duration // timeout total (padrão: 12s)
	EarlyReturnN   int           // retorna cedo se >= N resultados (padrão: 8)
	EarlyReturnMs  int           // milissegundos para early return (padrão: 1200)
	DeduplicateBy  string        // "id" ou "title" (padrão: "id")
}

var DefaultSearchOptions = SearchOptions{
	Timeout:       12 * time.Second,
	EarlyReturnN:  8,
	EarlyReturnMs: 1200,
	DeduplicateBy: "id",
}

// ParallelSearch executa busca paralela em todos os providers
// com cancelamento de context quando temos resultados suficientes.
func ParallelSearch(
	ctx       context.Context,
	query     string,
	providers []SearchProvider,
	opts      SearchOptions,
) []SearchResultItem {
	if opts.Timeout == 0 { opts = DefaultSearchOptions }

	ctx, cancel := context.WithTimeout(ctx, opts.Timeout)
	defer cancel()

	type result struct {
		items []SearchResultItem
		err   error
	}

	ch          := make(chan result, len(providers))
	var count   atomic.Int64
	earlyReturn := time.After(time.Duration(opts.EarlyReturnMs) * time.Millisecond)

	for _, p := range providers {
		go func(prov SearchProvider) {
			pCtx, pCancel := context.WithTimeout(ctx, opts.Timeout-time.Second)
			defer pCancel()

			items, err := prov.Search(pCtx, query)
			if err == nil {
				count.Add(int64(len(items)))
			}
			select {
			case ch <- result{items, err}:
			case <-ctx.Done():
			}
		}(p)
	}

	var all   []SearchResultItem
	received := 0
	total    := len(providers)

loop:
	for received < total {
		select {
		case r := <-ch:
			if r.err == nil {
				all = append(all, r.items...)
			}
			received++
		case <-earlyReturn:
			if count.Load() >= int64(opts.EarlyReturnN) {
				cancel() // cancela providers restantes
				break loop
			}
		case <-ctx.Done():
			break loop
		}
	}

	return deduplicateResults(all, opts.DeduplicateBy)
}

func deduplicateResults(items []SearchResultItem, by string) []SearchResultItem {
	seen := make(map[string]bool)
	out  := make([]SearchResultItem, 0, len(items))
	for _, item := range items {
		var key string
		if by == "title" {
			key = normalizeTitle(item.Title)
		} else {
			key = item.Provider + ":" + item.ID
		}
		if !seen[key] {
			seen[key] = true
			out = append(out, item)
		}
	}
	return out
}

func normalizeTitle(t string) string {
	// Remove espaços extras e converte para minúsculo para deduplicação correta
	re := regexp.MustCompile(`\s+`)
	return strings.ToLower(strings.TrimSpace(re.ReplaceAllString(t, " ")))
}

// ══════════════════════════════════════════════════════════
// VideoExtractor — extração universal com múltiplos fallbacks
//
// Suporta 20+ padrões em paralelo.
// Retorna o primeiro match válido ou vazio se nenhum encontrado.
// ══════════════════════════════════════════════════════════

type ExtractionPattern struct {
	Name    string
	Pattern *regexp.Regexp
	Extract func(match string) string // pós-processamento
}

// Padrões compilados uma única vez (performance)
var videoPatterns = buildVideoPatterns()

func buildVideoPatterns() []ExtractionPattern {
	make := func(name, pat string, extract func(string) string) ExtractionPattern {
		if extract == nil {
			extract = func(s string) string { return s }
		}
		return ExtractionPattern{
			Name:    name,
			Pattern: regexp.MustCompile(pat),
			Extract: extract,
		}
	}

	return []ExtractionPattern{
		make("videoUrl_json",    `"videoUrl"\s*:\s*"([^"]+)"`,                nil),
		make("file_json",        `"file"\s*:\s*"([^"]+)"`,                    nil),
		make("hls_json",         `"hls"\s*:\s*"([^"]+)"`,                     nil),
		make("file_js_sq",       `file\s*:\s*'([^']+)'`,                      nil),
		make("file_js_dq",       `file\s*:\s*"([^"]+)"`,                      nil),
		make("source_src",       `<source[^>]+src=["']([^"']+\.(?:mp4|m3u8)[^"']*)["']`, nil),
		make("jwplayer_file",    `jwplayer\([^)]+\)\.setup\(\{[^}]*file\s*:\s*["']([^"']+)["']`, nil),
		make("playerjs_file",    `new\s+Playerjs\(\{[^}]*file\s*:\s*["']([^"']+)["']`, nil),
		make("m3u8_bare",        `["']([^"']+\.m3u8[^"'?]*)["']`,             nil),
		make("mp4_bare",         `["']([^"']+\.mp4[^"'?]*)["']`,              nil),
		make("player_src",       `player\.src\(\{src\s*:\s*["']([^"']+)["']`, nil),
		make("hlsMaster",        `hlsMasterPlaylistUrl["']\s*:\s*["']([^"']+)["']`, nil),
		make("videoSource_var",  `var\s+videoSource\s*=\s*["']([^"']+)["']`,  nil),
		make("dataSrc",          `data-src=["']([^"']+\.(?:mp4|m3u8)[^"']*)["']`, nil),
		make("mediaURL",         `mediaUrl\s*=\s*["']([^"']+)["']`,           nil),
		make("embed_iframe",     `<iframe[^>]+src=["']([^"']+)["']`,          func(s string) string {
			// Iframes são links de embed, não diretos — marca como tipo embed
			if len(s) > 0 && s[0] != 'h' { return "" }
			return s
		}),
	}
}

type VideoURLResult struct {
	URL      string
	Format   string // "hls", "mp4", "embed"
	Pattern  string // nome do padrão que encontrou
}

// ExtractVideoURLs tenta todos os padrões em paralelo e
// retorna todos os matches válidos, deduplicados.
func ExtractVideoURLs(html string) []VideoURLResult {
	type hit struct {
		url     string
		format  string
		pattern string
	}

	results := make(chan hit, len(videoPatterns))
	var wg sync.WaitGroup

	for _, pat := range videoPatterns {
		wg.Add(1)
		go func(p ExtractionPattern) {
			defer wg.Done()
			matches := p.Pattern.FindAllStringSubmatch(html, 5)
			for _, m := range matches {
				if len(m) < 2 { continue }
				raw := m[1]
				// Desfaz escaping comum
				raw = unescapeURL(raw)
				if p.Extract != nil {
					raw = p.Extract(raw)
				}
				if !isValidVideoURL(raw) { continue }
				select {
				case results <- hit{raw, detectVideoFormat(raw), p.Name}:
				default:
				}
			}
		}(pat)
	}

	wg.Wait()
	close(results)

	// Deduplicar e retornar
	seen := make(map[string]bool)
	var out []VideoURLResult
	for h := range results {
		if !seen[h.url] {
			seen[h.url] = true
			out = append(out, VideoURLResult{URL: h.url, Format: h.format, Pattern: h.pattern})
		}
	}
	return out
}

// ExtractFirstVideoURL retorna o primeiro URL válido encontrado.
// Mais rápido quando apenas 1 URL é necessário.
func ExtractFirstVideoURL(html string) string {
	done := make(chan string, 1)
	var once sync.Once

	for _, pat := range videoPatterns {
		go func(p ExtractionPattern) {
			m := p.Pattern.FindStringSubmatch(html)
			if len(m) < 2 { return }
			raw := unescapeURL(m[1])
			if p.Extract != nil { raw = p.Extract(raw) }
			if isValidVideoURL(raw) {
				once.Do(func() {
					select {
					case done <- raw:
					default:
					}
				})
			}
		}(pat)
	}

	select {
	case url := <-done:
		return url
	case <-time.After(3 * time.Second):
		return ""
	}
}

// ── helpers ───────────────────────────────────────────────

var (
	reEscapeSlash = regexp.MustCompile(`\\/`)
	reEscapeUni   = regexp.MustCompile(`\\u([0-9a-fA-F]{4})`)
)

func unescapeURL(s string) string {
	s = reEscapeSlash.ReplaceAllString(s, "/")
	return s
}

func isValidVideoURL(s string) bool {
	if len(s) < 10 { return false }
	if s[:4] != "http" { return false }
	// Exclui assets estáticos
	for _, ext := range []string{".css", ".js", ".png", ".jpg", ".gif", ".svg", ".ico", ".woff"} {
		if len(s) > len(ext) && s[len(s)-len(ext):] == ext { return false }
	}
	return true
}

func detectVideoFormat(url string) string {
	if len(url) > 5 {
		switch {
		case strings.Contains(url, ".m3u8"): return "hls"
		case strings.Contains(url, ".mpd"):  return "dash"
		case strings.Contains(url, ".mp4"):  return "mp4"
		}
	}
	return "hls"
}
