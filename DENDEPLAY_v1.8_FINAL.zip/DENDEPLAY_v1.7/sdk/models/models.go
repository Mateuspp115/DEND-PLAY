// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

package models

import "sort"

type MediaType string

const (
	MediaTypeAnime MediaType = "anime"
	MediaTypeMovie MediaType = "movie"
	MediaTypeTV    MediaType = "tv"
)

type SearchResult struct {
	ID        string    `json:"id"`
	Title     string    `json:"title"`
	TitleEN   string    `json:"title_en,omitempty"`
	ImageURL  string    `json:"image_url"`
	URL       string    `json:"url"`
	Provider  string    `json:"provider"`
	MediaType MediaType `json:"media_type"`
	Year      string    `json:"year,omitempty"`
	Rating    float64   `json:"rating,omitempty"`
	Episodes  int       `json:"episodes,omitempty"`
	Language  string    `json:"language,omitempty"`
	Quality   string    `json:"quality,omitempty"`
}

type MediaDetails struct {
	ID        string    `json:"id"`
	Title     string    `json:"title"`
	ImageURL  string    `json:"image_url"`
	BannerURL string    `json:"banner_url,omitempty"`
	URL       string    `json:"url"`
	Provider  string    `json:"provider"`
	MediaType MediaType `json:"media_type"`
	Overview  string    `json:"overview"`
	Genres    []string  `json:"genres,omitempty"`
	Year      string    `json:"year,omitempty"`
	Status    string    `json:"status,omitempty"`
	Rating    float64   `json:"rating,omitempty"`
	TotalEps  int       `json:"total_eps,omitempty"`
	AnilistID int       `json:"anilist_id,omitempty"`
	MalID     int       `json:"mal_id,omitempty"`
	TMDBID    int       `json:"tmdb_id,omitempty"`
	IMDBID    string    `json:"imdb_id,omitempty"`
	Seasons   []Season  `json:"seasons,omitempty"`
	Episodes  []Episode `json:"episodes,omitempty"`
	HasDub    bool      `json:"has_dub"`
	HasSub    bool      `json:"has_sub"`
	Language  string    `json:"language,omitempty"`
}

type Season struct {
	ID       string    `json:"id"`
	Number   int       `json:"number"`
	Title    string    `json:"title"`
	Episodes []Episode `json:"episodes,omitempty"`
}

type Episode struct {
	Number   int    `json:"number"`
	Title    string `json:"title,omitempty"`
	URL      string `json:"url"`
	DataID   string `json:"data_id,omitempty"`
	SeasonID string `json:"season_id,omitempty"`
	Duration int    `json:"duration,omitempty"`
	IsFiller bool   `json:"is_filler,omitempty"`
	Thumb    string `json:"thumbnail,omitempty"`
}

type VideoSource struct {
	URL      string            `json:"url"`
	Quality  string            `json:"quality"`
	Format   string            `json:"format"`
	Headers  map[string]string `json:"headers,omitempty"`
	Referer  string            `json:"referer,omitempty"`
	Provider string            `json:"provider"`
	Score    int               `json:"score"`
	Label    string            `json:"label,omitempty"`
}

type SkipTimes struct {
	Intro *TimeRange `json:"intro,omitempty"`
	Outro *TimeRange `json:"outro,omitempty"`
}

type TimeRange struct {
	Start float64 `json:"start"`
	End   float64 `json:"end"`
}

type ProviderInfo struct {
	ID       string   `json:"id"`
	Name     string   `json:"name"`
	Language string   `json:"language"`
	Types    []string `json:"types"`
	Active   bool     `json:"active"`
	Priority int      `json:"priority"`
}

func SelectBestSource(sources []VideoSource) VideoSource {
	if len(sources) == 0 { return VideoSource{} }
	q := map[string]int{"4k": 110, "2160p": 110, "1080p": 90, "720p": 70, "480p": 50, "360p": 30, "auto": 60}
	for i := range sources {
		if s, ok := q[sources[i].Quality]; ok { sources[i].Score = s }
	}
	sort.Slice(sources, func(i, j int) bool { return sources[i].Score > sources[j].Score })
	return sources[0]
}
