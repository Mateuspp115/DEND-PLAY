// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package sdk

import (
	"context"
	"fmt"
	"net/http"
	"sort"
	"sync"
	"time"
)

// ══════════════════════════════════════════════════════════
// ProviderHealth — health check com média móvel exponencial
//
// Funcionalidades:
//   - Ping periódico de cada provider
//   - Média móvel de SuccessRate (peso 90/10)
//   - Auto-disable após 3 falhas consecutivas
//   - Reativação automática após 5 minutos
//   - GetTopN — retorna os N providers mais saudáveis
// ══════════════════════════════════════════════════════════

type ProviderHealthStatus struct {
	Name             string
	SuccessRate      float64       // 0.0 – 1.0
	AvgResponseTime  time.Duration
	LastCheck        time.Time
	IsHealthy        bool
	ConsecutiveFails int
	DisabledAt       time.Time
}

type HealthChecker struct {
	mu         sync.RWMutex
	statuses   map[string]*ProviderHealthStatus
	pingURLs   map[string]string // provider → URL de ping
	httpClient *http.Client
	stopCh     chan struct{}
}

func NewHealthChecker() *HealthChecker {
	return &HealthChecker{
		statuses:   make(map[string]*ProviderHealthStatus),
		pingURLs:   make(map[string]string),
		httpClient: &http.Client{Timeout: 6 * time.Second},
		stopCh:     make(chan struct{}),
	}
}

// Register registra um provider e sua URL de ping.
func (hc *HealthChecker) Register(name, pingURL string) {
	hc.mu.Lock()
	defer hc.mu.Unlock()
	hc.statuses[name]  = &ProviderHealthStatus{Name: name, IsHealthy: true, SuccessRate: 1.0}
	hc.pingURLs[name]  = pingURL
}

// StartHealthCheck inicia health checks periódicos em background.
func (hc *HealthChecker) StartHealthCheck(interval time.Duration) {
	go func() {
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		// Check imediato ao iniciar
		hc.checkAll()
		for {
			select {
			case <-ticker.C:
				hc.checkAll()
			case <-hc.stopCh:
				return
			}
		}
	}()
}

func (hc *HealthChecker) Stop() {
	select {
	case hc.stopCh <- struct{}{}:
	default:
	}
}

func (hc *HealthChecker) checkAll() {
	hc.mu.RLock()
	names := make([]string, 0, len(hc.statuses))
	for n := range hc.statuses {
		names = append(names, n)
	}
	hc.mu.RUnlock()

	var wg sync.WaitGroup
	for _, name := range names {
		wg.Add(1)
		go func(n string) {
			defer wg.Done()
			hc.checkOne(n)
		}(name)
	}
	wg.Wait()
}

func (hc *HealthChecker) checkOne(name string) {
	hc.mu.RLock()
	pingURL, ok := hc.pingURLs[name]
	st, stok := hc.statuses[name]
	hc.mu.RUnlock()

	if !ok || !stok || pingURL == "" {
		return
	}

	// Tenta reativar provider desativado após 5 minutos
	hc.mu.Lock()
	if !st.IsHealthy && time.Since(st.DisabledAt) > 5*time.Minute {
		st.IsHealthy        = true
		st.ConsecutiveFails = 0
	}
	hc.mu.Unlock()

	// Ping
	start   := time.Now()
	success := hc.ping(pingURL)
	elapsed := time.Since(start)

	hc.mu.Lock()
	defer hc.mu.Unlock()

	st.LastCheck = time.Now()

	// Média móvel exponencial (90% histórico, 10% novo ponto)
	if success {
		st.SuccessRate      = st.SuccessRate*0.9 + 0.1
		st.AvgResponseTime  = (st.AvgResponseTime*9 + elapsed) / 10
		st.ConsecutiveFails = 0
		st.IsHealthy        = true
	} else {
		st.SuccessRate = st.SuccessRate*0.9 + 0.0
		st.ConsecutiveFails++
		if st.ConsecutiveFails >= 3 {
			st.IsHealthy  = false
			st.DisabledAt = time.Now()
		}
	}
}

func (hc *HealthChecker) ping(url string) bool {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "HEAD", url, nil)
	if err != nil {
		return false
	}
	req.Header.Set("User-Agent", "DENDÊPLAY-HealthCheck/1.4")
	resp, err := hc.httpClient.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode < 500
}

// IsHealthy retorna se um provider está saudável.
func (hc *HealthChecker) IsHealthy(name string) bool {
	hc.mu.RLock()
	defer hc.mu.RUnlock()
	s, ok := hc.statuses[name]
	if !ok { return true } // desconhecido = assume saudável
	return s.IsHealthy
}

// GetTopN retorna os N providers mais saudáveis ordenados por SuccessRate.
func (hc *HealthChecker) GetTopN(n int) []string {
	hc.mu.RLock()
	defer hc.mu.RUnlock()

	type ns struct{ name string; score float64 }
	var list []ns
	for name, s := range hc.statuses {
		if s.IsHealthy {
			list = append(list, ns{name, s.SuccessRate})
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].score > list[j].score })

	out := make([]string, 0, n)
	for i, item := range list {
		if i >= n { break }
		out = append(out, item.name)
	}
	return out
}

// GetReport retorna um relatório completo de saúde em JSON.
func (hc *HealthChecker) GetReport() []ProviderHealthStatus {
	hc.mu.RLock()
	defer hc.mu.RUnlock()

	var list []ProviderHealthStatus
	for _, s := range hc.statuses {
		list = append(list, *s)
	}
	sort.Slice(list, func(i, j int) bool { return list[i].SuccessRate > list[j].SuccessRate })
	return list
}

// RecordResult registra manualmente um resultado (usado pelo Manager).
func (hc *HealthChecker) RecordResult(name string, success bool, elapsed time.Duration) {
	hc.mu.Lock()
	defer hc.mu.Unlock()

	s, ok := hc.statuses[name]
	if !ok {
		s = &ProviderHealthStatus{Name: name, IsHealthy: true, SuccessRate: 1.0}
		hc.statuses[name] = s
	}

	if success {
		s.SuccessRate      = s.SuccessRate*0.9 + 0.1
		s.AvgResponseTime  = (s.AvgResponseTime*9 + elapsed) / 10
		s.ConsecutiveFails = 0
		s.IsHealthy        = true
	} else {
		s.SuccessRate = s.SuccessRate * 0.9
		s.ConsecutiveFails++
		if s.ConsecutiveFails >= 3 {
			s.IsHealthy  = false
			s.DisabledAt = time.Now()
		}
	}
}

// Summary retorna um resumo legível.
func (hc *HealthChecker) Summary() string {
	hc.mu.RLock()
	defer hc.mu.RUnlock()

	healthy := 0
	for _, s := range hc.statuses {
		if s.IsHealthy { healthy++ }
	}
	return fmt.Sprintf("%d/%d providers saudáveis", healthy, len(hc.statuses))
}
