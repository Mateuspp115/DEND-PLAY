// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package sdk

import (
	"fmt"
	"sync"
	"time"
)

// ══════════════════════════════════════════════════════════
// RateLimiter — limita requests por provider
//
// Evita sobrecarregar um único provider com muitas requests
// simultâneas, o que levaria a bloqueio de IP.
// Usa janela deslizante de 1 minuto.
// ══════════════════════════════════════════════════════════

type ProviderLimit struct {
	RequestsPerMinute int
	mu                sync.RWMutex
	requests          []time.Time // timestamps das últimas requests
}

type RateLimiter struct {
	mu     sync.RWMutex
	limits map[string]*ProviderLimit
}

// NewRateLimiter cria o limiter com configurações padrão por tipo de provider.
func NewRateLimiter() *RateLimiter {
	rl := &RateLimiter{limits: make(map[string]*ProviderLimit)}

	// Configurações conservadoras para não ser banido
	defaultLimits := map[string]int{
		"animefire":    30,
		"goanimes":     25,
		"anitube":      20,
		"animesonline": 20,
		"hinatasoul":   20,
		"animeshouse":  20,
		"goyabu":       20,
		"animeking":    20,
		"animesdigital": 15,
		"betteranime":  20,
		"animesorion":  15,
		"animeszone":   15,
		"pobreflix":    30,
		"topflix":      30,
		"megaflix":     25,
		"superflix":    25,
		"tugaflix":     20,
		"megafilmeshd": 20,
		"doflix":       20,
		"redecanais":   20,
		"maxfilmes":    15,
		"allanime":     60, // API — mais permissivo
		"flixhq":       25,
		"animekisa":    20,
		"gogoanime":    20,
		"9anime":       20,
	}

	for name, rpm := range defaultLimits {
		rl.limits[name] = &ProviderLimit{RequestsPerMinute: rpm}
	}
	return rl
}

// Allow verifica se um request é permitido para o provider.
// Retorna true se abaixo do limite, false se deve ser throttled.
func (rl *RateLimiter) Allow(providerName string) bool {
	rl.mu.RLock()
	limit, exists := rl.limits[providerName]
	rl.mu.RUnlock()

	if !exists {
		return true // sem limite configurado = permitir
	}

	limit.mu.Lock()
	defer limit.mu.Unlock()

	// Remove timestamps mais antigos que 1 minuto (janela deslizante)
	cutoff := time.Now().Add(-time.Minute)
	valid  := limit.requests[:0]
	for _, t := range limit.requests {
		if t.After(cutoff) {
			valid = append(valid, t)
		}
	}
	limit.requests = valid

	if len(limit.requests) >= limit.RequestsPerMinute {
		return false // throttle
	}

	limit.requests = append(limit.requests, time.Now())
	return true
}

// WaitIfNeeded bloqueia até que um slot esteja disponível.
// Máximo de espera: 10 segundos.
func (rl *RateLimiter) WaitIfNeeded(providerName string) error {
	deadline := time.Now().Add(10 * time.Second)
	for {
		if rl.Allow(providerName) {
			return nil
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("rate limit timeout para provider %q", providerName)
		}
		time.Sleep(200 * time.Millisecond)
	}
}

// CurrentRate retorna quantas requests foram feitas no último minuto.
func (rl *RateLimiter) CurrentRate(providerName string) int {
	rl.mu.RLock()
	limit, exists := rl.limits[providerName]
	rl.mu.RUnlock()
	if !exists { return 0 }

	limit.mu.Lock()
	defer limit.mu.Unlock()

	cutoff := time.Now().Add(-time.Minute)
	count  := 0
	for _, t := range limit.requests {
		if t.After(cutoff) { count++ }
	}
	return count
}
