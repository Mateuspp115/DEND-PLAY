module github.com/dendeplay/sdk

go 1.21

require (
	github.com/PuerkitoBio/goquery v1.11.0
	github.com/google/uuid        v1.6.0
	golang.org/x/net              v0.35.0
	golang.org/x/time             v0.10.0
)

require (
	github.com/andybalholm/cascadia v1.3.3 // indirect
	golang.org/x/text              v0.22.0 // indirect
)
