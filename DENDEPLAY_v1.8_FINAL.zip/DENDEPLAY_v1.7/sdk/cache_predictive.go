// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package sdk

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

// ══════════════════════════════════════════════════════════
// PredictiveCache — cache com ML leve
//
// Aprende padrões de uso do usuário:
//   - Gêneros mais assistidos
//   - Horários de uso
//   - Séries em andamento (pré-carrega próximo episódio)
//   - Trending por hora do dia
// ══════════════════════════════════════════════════════════

type WatchedItem struct {
	MediaID   string    `json:"media_id"`
	Provider  string    `json:"provider"`
	Episode   int       `json:"episode"`
	Genre     string    `json:"genre,omitempty"`
	Timestamp time.Time `json:"timestamp"`
}

type CachedEntry struct {
	Data        string    `json:"data"`
	ExpiresAt   time.Time `json:"expires_at"`
	AccessCount int       `json:"access_count"`
	LastAccess  time.Time `json:"last_access"`
}

type PredictiveCache struct {
	mu          sync.RWMutex
	entries     map[string]*CachedEntry
	history     []WatchedItem
	genreCount  map[string]int // freq por gênero
	hourCount   map[int]int    // freq por hora
	activeKeys  map[string]bool
	dataDir     string
	maxEntries  int
}

func NewPredictiveCache(dataDir string) *PredictiveCache {
	pc := &PredictiveCache{
		entries:    make(map[string]*CachedEntry),
		genreCount: make(map[string]int),
		hourCount:  make(map[int]int),
		activeKeys: make(map[string]bool),
		dataDir:    dataDir,
		maxEntries: 300,
	}
	pc.loadFromDisk()
	return pc
}

// Get recupera um item do cache. Atualiza AccessCount.
func (pc *PredictiveCache) Get(key string) string {
	pc.mu.Lock()
	defer pc.mu.Unlock()

	e, ok := pc.entries[key]
	if !ok {
		return ""
	}
	if time.Now().After(e.ExpiresAt) {
		delete(pc.entries, key)
		return ""
	}
	e.AccessCount++
	e.LastAccess = time.Now()
	return e.Data
}

// Set armazena com TTL. Remove itens mais antigos se cheio.
func (pc *PredictiveCache) Set(key, data string, ttl time.Duration) {
	pc.mu.Lock()
	defer pc.mu.Unlock()

	// Evict LRU se necessário
	if len(pc.entries) >= pc.maxEntries {
		pc.evictLRU()
	}

	pc.entries[key] = &CachedEntry{
		Data:        data,
		ExpiresAt:   time.Now().Add(ttl),
		AccessCount: 1,
		LastAccess:  time.Now(),
	}
}

// RecordWatch aprende o padrão de um item assistido.
func (pc *PredictiveCache) RecordWatch(item WatchedItem) {
	if item.Timestamp.IsZero() {
		item.Timestamp = time.Now()
	}
	pc.mu.Lock()
	pc.history = append(pc.history, item)
	if len(pc.history) > 500 {
		pc.history = pc.history[len(pc.history)-500:]
	}
	if item.Genre != "" {
		pc.genreCount[item.Genre]++
	}
	pc.hourCount[item.Timestamp.Hour()]++
	pc.mu.Unlock()

	// Pré-carrega próximos episódios em background
	go pc.maybePreload(item)

	// Salva em disco assincronamente
	go pc.saveToDisk()
}

// PreloadNext pré-carrega o próximo episódio de forma assíncrona.
// fetchFn deve realizar a chamada de rede e retornar JSON.
func (pc *PredictiveCache) PreloadNext(
	mediaID, provider string, nextEp int,
	fetchFn func(ctx context.Context) (string, error),
) {
	key := fmt.Sprintf("eps:%s:%s:ep%d", provider, mediaID, nextEp)
	if pc.Get(key) != "" {
		return // já em cache
	}
	pc.mu.Lock()
	if pc.activeKeys[key] {
		pc.mu.Unlock()
		return
	}
	pc.activeKeys[key] = true
	pc.mu.Unlock()

	go func() {
		defer func() {
			pc.mu.Lock()
			delete(pc.activeKeys, key)
			pc.mu.Unlock()
		}()

		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()

		data, err := fetchFn(ctx)
		if err != nil || data == "" || data == "[]" || data == "{}" {
			return
		}
		pc.Set(key, data, 25*time.Minute)
	}()
}

// TopGenres retorna os N gêneros mais assistidos.
func (pc *PredictiveCache) TopGenres(n int) []string {
	pc.mu.RLock()
	defer pc.mu.RUnlock()

	type gs struct{ g string; c int }
	var list []gs
	for g, c := range pc.genreCount {
		list = append(list, gs{g, c})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].c > list[j].c })

	out := make([]string, 0, n)
	for i, g := range list {
		if i >= n { break }
		out = append(out, g.g)
	}
	return out
}

// BestMediaTypForNow retorna o tipo de conteúdo recomendado
// para o horário atual baseado nos padrões do usuário.
func (pc *PredictiveCache) BestMediaTypeForNow() string {
	pc.mu.RLock()
	defer pc.mu.RUnlock()

	hour    := time.Now().Hour()
	weekday := time.Now().Weekday()

	// Regras base (podem ser sobrepostas pelo histórico)
	switch {
	case weekday == time.Saturday || weekday == time.Sunday:
		return "movie"
	case hour >= 18 && hour <= 23:
		return "anime"
	case hour >= 14 && hour <= 17:
		return "tv"
	default:
		return "all"
	}
}

// ── helpers internos ──────────────────────────────────────

func (pc *PredictiveCache) evictLRU() {
	// Remove o 20% mais antigo sem acessos recentes
	type kv struct{ k string; t time.Time }
	var list []kv
	for k, e := range pc.entries {
		list = append(list, kv{k, e.LastAccess})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].t.Before(list[j].t) })
	remove := len(list) / 5
	for i := 0; i < remove; i++ {
		delete(pc.entries, list[i].k)
	}
}

func (pc *PredictiveCache) maybePreload(item WatchedItem) {
	// Pré-carrega próximos 3 episódios se o usuário está num padrão regular
	pc.mu.RLock()
	count := 0
	for _, h := range pc.history {
		if h.MediaID == item.MediaID {
			count++
		}
	}
	pc.mu.RUnlock()

	// Só pré-carrega a partir do 2º episódio (padrão confirmado)
	if count < 2 {
		return
	}
	// Marca próximos 3 episódios para pré-carga (fetchFn injetada pelo caller)
	for i := 1; i <= 3; i++ {
		key := fmt.Sprintf("preload_hint:%s:%s:ep%d", item.Provider, item.MediaID, item.Episode+i)
		pc.Set(key, "pending", 10*time.Minute)
	}
}

type diskData struct {
	History    []WatchedItem `json:"history"`
	GenreCount map[string]int `json:"genre_count"`
	HourCount  map[int]int    `json:"hour_count"`
}

func (pc *PredictiveCache) saveToDisk() {
	if pc.dataDir == "" {
		return
	}
	pc.mu.RLock()
	d := diskData{
		History:    pc.history,
		GenreCount: pc.genreCount,
		HourCount:  pc.hourCount,
	}
	pc.mu.RUnlock()

	b, err := json.Marshal(d)
	if err != nil {
		return
	}
	os.MkdirAll(pc.dataDir, 0750)
	os.WriteFile(filepath.Join(pc.dataDir, "patterns.json"), b, 0600)
}

func (pc *PredictiveCache) loadFromDisk() {
	if pc.dataDir == "" {
		return
	}
	b, err := os.ReadFile(filepath.Join(pc.dataDir, "patterns.json"))
	if err != nil {
		return
	}
	var d diskData
	if json.Unmarshal(b, &d) != nil {
		return
	}
	pc.mu.Lock()
	defer pc.mu.Unlock()
	if d.History    != nil { pc.history    = d.History }
	if d.GenreCount != nil { pc.genreCount = d.GenreCount }
	if d.HourCount  != nil { pc.hourCount  = d.HourCount }
}

func (pc *PredictiveCache) Clear() {
	pc.mu.Lock()
	defer pc.mu.Unlock()
	pc.entries = make(map[string]*CachedEntry)
}

func (pc *PredictiveCache) Size() int {
	pc.mu.RLock()
	defer pc.mu.RUnlock()
	return len(pc.entries)
}
