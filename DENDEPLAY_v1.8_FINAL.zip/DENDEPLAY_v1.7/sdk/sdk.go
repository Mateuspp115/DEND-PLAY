// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

// Package sdk — DENDÊPLAY v1.7 SDK
// Compilado via gomobile para Android.
package sdk

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/dendeplay/sdk/cache"
	"github.com/dendeplay/sdk/download"
	"github.com/dendeplay/sdk/models"
	"github.com/dendeplay/sdk/providers"
	"github.com/dendeplay/sdk/userdata"
)

const Version = "1.7.0"

// GoAnimeSDK é o ponto de entrada exportado pelo gomobile.
type GoAnimeSDK struct {
	manager      *providers.Manager
	cache        *cache.DiskCache
	predCache    *PredictiveCache
	healthCheck  *HealthChecker
	rateLimiter  *RateLimiter
	userData     *userdata.Store
	dlManager    *download.Manager
}

// NewGoAnimeSDK cria a instância do SDK.
// dataDir = context.filesDir no Android.
func NewGoAnimeSDK(dataDir string) (*GoAnimeSDK, error) {
	c, err := cache.NewDiskCache(dataDir + "/cache")
	if err != nil {
		return nil, fmt.Errorf("cache: %w", err)
	}
	ud, err := userdata.NewStore(dataDir + "/userdata.json")
	if err != nil {
		return nil, fmt.Errorf("userdata: %w", err)
	}

	// Cache preditivo — aprende padrões do usuário
	pc := NewPredictiveCache(dataDir + "/patterns")

	// Rate limiter — evita sobrecarga dos providers
	rl := NewRateLimiter()

	// Health checker — monitora disponibilidade dos providers
	hc := NewHealthChecker()
	hc.StartHealthCheck(3 * time.Minute)

	sdk := &GoAnimeSDK{
		manager:     providers.NewManager(),
		cache:       c,
		predCache:   pc,
		healthCheck: hc,
		rateLimiter: rl,
		userData:    ud,
		dlManager:   download.NewManager(dataDir + "/downloads"),
	}
	return sdk, nil
}

// GetVersion retorna a versão do SDK.
func (s *GoAnimeSDK) GetVersion() string { return Version }

// GetProviderCount retorna o número de providers registrados.
func (s *GoAnimeSDK) GetProviderCount() int { return s.manager.ProviderCount() }

// GetHealthReport retorna JSON com status de saúde dos providers.
func (s *GoAnimeSDK) GetHealthReport() string {
	report := s.healthCheck.GetReport()
	b, _ := json.Marshal(report)
	return string(b)
}

// ── Busca ─────────────────────────────────────────────────

// SearchUniversal busca em todos os 26 providers com rate limiting.
func (s *GoAnimeSDK) SearchUniversal(query string) string {
	key := "search:" + query
	if v := s.predCache.Get(key); v != "" { return v }
	if v := s.cache.Get(key); v != "" { return v }

	results, err := s.manager.SearchAll(query)
	if err != nil || len(results) == 0 { return "[]" }

	b, _ := json.Marshal(results)
	res := string(b)
	s.cache.Set(key, res, 8*time.Minute)
	s.predCache.Set(key, res, 10*time.Minute)
	return res
}

// SearchByType busca por tipo: "anime" | "movie" | "tv"
func (s *GoAnimeSDK) SearchByType(query, mediaType string) string {
	key := "st:" + mediaType + ":" + query
	if v := s.cache.Get(key); v != "" { return v }

	results, err := s.manager.SearchByType(query, mediaType)
	if err != nil || len(results) == 0 { return "[]" }

	b, _ := json.Marshal(results)
	s.cache.Set(key, string(b), 8*time.Minute)
	return string(b)
}

// SearchByProvider busca em um único provider pelo ID.
func (s *GoAnimeSDK) SearchByProvider(query, providerID string) string {
	// Aplica rate limit por provider
	if !s.rateLimiter.Allow(providerID) {
		return "[]"
	}
	results, err := s.manager.SearchByProvider(query, providerID)
	if err != nil { return "[]" }
	b, _ := json.Marshal(results)
	return string(b)
}

// ── Detalhes & Episódios ──────────────────────────────────

func (s *GoAnimeSDK) GetMediaDetails(id, providerID string) string {
	key := "det:" + providerID + ":" + id
	if v := s.cache.Get(key); v != "" { return v }

	// Verifica saúde do provider antes de tentar
	if !s.healthCheck.IsHealthy(providerID) {
		// Provider doente — tenta retornar do cache mesmo expirado
		if v := s.cache.Get(key + ":stale"); v != "" { return v }
	}

	start := time.Now()
	d, err := s.manager.GetDetails(id, providerID)
	elapsed := time.Since(start)
	s.healthCheck.RecordResult(providerID, err == nil, elapsed)

	if err != nil { return "{}" }
	b, _ := json.Marshal(d)
	res := string(b)
	s.cache.Set(key, res, 30*time.Minute)
	s.cache.Set(key+":stale", res, 6*time.Hour) // stale cache
	return res
}

func (s *GoAnimeSDK) GetEpisodes(mediaURL, providerID string) string {
	key := "eps:" + providerID + ":" + mediaURL
	if v := s.predCache.Get(key); v != "" { return v }
	if v := s.cache.Get(key); v != "" { return v }

	eps, err := s.manager.GetEpisodes(mediaURL, providerID)
	if err != nil { return "[]" }

	b, _ := json.Marshal(eps)
	res := string(b)
	s.cache.Set(key, res, 15*time.Minute)
	s.predCache.Set(key, res, 20*time.Minute)
	return res
}

// ── Vídeo ─────────────────────────────────────────────────

// GetVideoSources retorna fontes com rate limiting por provider.
func (s *GoAnimeSDK) GetVideoSources(episodeURL, providerID string, epNum int) string {
	if !s.rateLimiter.Allow(providerID) {
		// Throttled — pequena espera e tenta uma vez
		select {
		case <-time.After(500 * time.Millisecond):
		}
		if !s.rateLimiter.Allow(providerID) { return "[]" }
	}

	start := time.Now()
	srcs, err := s.manager.GetVideoSources(episodeURL, providerID, epNum)
	s.healthCheck.RecordResult(providerID, err == nil, time.Since(start))

	if err != nil || len(srcs) == 0 { return "[]" }
	b, _ := json.Marshal(srcs)
	return string(b)
}

// GetBestSource retorna a melhor fonte disponível.
func (s *GoAnimeSDK) GetBestSource(episodeURL, providerID string, epNum int) string {
	srcs, err := s.manager.GetVideoSources(episodeURL, providerID, epNum)
	if err != nil || len(srcs) == 0 { return "{}" }
	b, _ := json.Marshal(models.SelectBestSource(srcs))
	return string(b)
}

// ── Trending ──────────────────────────────────────────────

func (s *GoAnimeSDK) GetTrending(mediaType string) string {
	key := "trend:" + mediaType
	if v := s.cache.Get(key); v != "" { return v }
	items, err := s.manager.GetTrending(mediaType)
	if err != nil { return "[]" }
	b, _ := json.Marshal(items)
	s.cache.Set(key, string(b), 20*time.Minute)
	return string(b)
}

func (s *GoAnimeSDK) GetLatestEpisodes() string {
	key := "latest"
	if v := s.cache.Get(key); v != "" { return v }
	items, err := s.manager.GetLatestEpisodes()
	if err != nil { return "[]" }
	b, _ := json.Marshal(items)
	s.cache.Set(key, string(b), 10*time.Minute)
	return string(b)
}

// ── Providers ─────────────────────────────────────────────

func (s *GoAnimeSDK) GetAvailableProviders() string {
	b, _ := json.Marshal(s.manager.AvailableProviders())
	return string(b)
}

// GetTopProviders retorna os N providers mais saudáveis.
func (s *GoAnimeSDK) GetTopProviders(n int) string {
	top := s.healthCheck.GetTopN(n)
	b, _ := json.Marshal(top)
	return string(b)
}

// ── Skip Times (AniSkip) ──────────────────────────────────

func (s *GoAnimeSDK) GetSkipTimes(malID, epNum int) string {
	key := fmt.Sprintf("skip:%d:%d", malID, epNum)
	if v := s.cache.Get(key); v != "" { return v }
	st := fetchAniSkip(malID, epNum)
	b, _ := json.Marshal(st)
	res := string(b)
	s.cache.Set(key, res, 24*time.Hour)
	return res
}

// ── Downloads ─────────────────────────────────────────────

func (s *GoAnimeSDK) StartDownload(mediaID, epURL, quality, title string, ep int) string {
	id, err := s.dlManager.Start(download.Request{
		MediaID: mediaID, EpisodeURL: epURL,
		Quality: quality, Title: title, Episode: ep,
	})
	if err != nil { return `{"error":"` + err.Error() + `"}` }
	return `{"id":"` + id + `"}`
}
func (s *GoAnimeSDK) PauseDownload(id string) string {
	if err := s.dlManager.Pause(id); err != nil { return `{"ok":false}` }
	return `{"ok":true}`
}
func (s *GoAnimeSDK) ResumeDownload(id string) string {
	if err := s.dlManager.Resume(id); err != nil { return `{"ok":false}` }
	return `{"ok":true}`
}
func (s *GoAnimeSDK) CancelDownload(id string)  { s.dlManager.Cancel(id) }
func (s *GoAnimeSDK) GetDownloads() string {
	b, _ := json.Marshal(s.dlManager.List())
	return string(b)
}
func (s *GoAnimeSDK) GetDownloadProgress(id string) int    { return s.dlManager.GetProgress(id) }
func (s *GoAnimeSDK) GetDownloadPath(id string) string     { return s.dlManager.GetFilePath(id) }

// ── User Data ─────────────────────────────────────────────

func (s *GoAnimeSDK) AddToHistory(j string) string {
	var wm userdata.WatchedMedia
	if json.Unmarshal([]byte(j), &wm) != nil { return `{"ok":false}` }
	s.userData.AddToHistory(wm)
	// Registra padrão no cache preditivo
	s.predCache.RecordWatch(WatchedItem{
		MediaID:   wm.MediaID,
		Provider:  wm.Provider,
		Episode:   wm.Episode,
		Timestamp: time.Now(),
	})
	return `{"ok":true}`
}
func (s *GoAnimeSDK) GetHistory() string {
	b, _ := json.Marshal(s.userData.GetHistory())
	return string(b)
}
func (s *GoAnimeSDK) AddToFavorites(j string) string {
	var fm userdata.FavoriteMedia
	if json.Unmarshal([]byte(j), &fm) != nil { return `{"ok":false}` }
	s.userData.AddToFavorites(fm)
	return `{"ok":true}`
}
func (s *GoAnimeSDK) RemoveFromFavorites(id string) string {
	s.userData.RemoveFromFavorites(id)
	return `{"ok":true}`
}
func (s *GoAnimeSDK) GetFavorites() string {
	b, _ := json.Marshal(s.userData.GetFavorites())
	return string(b)
}
func (s *GoAnimeSDK) UpdateProgress(mediaID string, ep, pos, dur int) string {
	s.userData.UpdateProgress(mediaID, ep, pos, dur)
	return `{"ok":true}`
}
func (s *GoAnimeSDK) GetProgress(mediaID string, ep int) string {
	b, _ := json.Marshal(s.userData.GetProgress(mediaID, ep))
	return string(b)
}

// ── Preditivo ─────────────────────────────────────────────

// GetRecommendedType retorna o tipo de conteúdo recomendado para agora.
func (s *GoAnimeSDK) GetRecommendedType() string {
	return s.predCache.BestMediaTypeForNow()
}

// GetTopGenres retorna JSON com os gêneros mais assistidos.
func (s *GoAnimeSDK) GetTopGenres(n int) string {
	b, _ := json.Marshal(s.predCache.TopGenres(n))
	return string(b)
}

// GetCacheStats retorna estatísticas do cache preditivo.
func (s *GoAnimeSDK) GetCacheStats() string {
	return fmt.Sprintf(`{"predictive":%d,"health":"%s"}`,
		s.predCache.Size(), s.healthCheck.Summary())
}

// ── Cache ─────────────────────────────────────────────────

func (s *GoAnimeSDK) ClearCache() {
	s.cache.Clear()
	s.predCache.Clear()
}
func (s *GoAnimeSDK) GetCacheSize() int64 { return s.cache.Size() }

// ─ AniSkip helper ─────────────────────────────────────────

var skipClient = &http.Client{Timeout: 6 * time.Second}

func fetchAniSkip(malID, epNum int) *models.SkipTimes {
	resp, err := skipClient.Get(fmt.Sprintf(
		"https://api.aniskip.com/v2/skip-times/%d/%d?types[]=op&types[]=ed",
		malID, epNum,
	))
	if err != nil { return &models.SkipTimes{} }
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	var data struct {
		Found   bool `json:"found"`
		Results []struct {
			SkipType string `json:"skipType"`
			Interval struct {
				StartTime float64 `json:"startTime"`
				EndTime   float64 `json:"endTime"`
			} `json:"interval"`
		} `json:"results"`
	}
	if json.Unmarshal(body, &data) != nil || !data.Found { return &models.SkipTimes{} }

	st := &models.SkipTimes{}
	for _, r := range data.Results {
		tr := &models.TimeRange{Start: r.Interval.StartTime, End: r.Interval.EndTime}
		if r.SkipType == "op" { st.Intro = tr } else { st.Outro = tr }
	}
	return st
}
