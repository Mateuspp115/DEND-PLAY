// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

// Package providers — DENDÊPLAY v1.7
// 26 sites suportados:
//   Anime PT-BR (12): AnimeFire, GoAnimes, AniTube, AnimesOnline, HinataSoul,
//                     AnimesHouse, Goyabu, AnimeKing, AnimesDigital,
//                     BetterAnime, AnimesOrion, AnimesZone
//   Filmes/Séries PT-BR (9): Pobreflix, TopFlix, MegaFlix, SuperFlix,
//                              Tugaflix, MegaFilmesHD, DoFlix, RedeCanais, MaxFilmes
//   Universal EN (5): AllAnime, FlixHQ, AnimeKisa, Gogoanime, 9Anime
package providers

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"
	"github.com/dendeplay/sdk/models"
)

// ─────────────────────────────────────────────────────────
// Tabela de todos os 26 sites suportados
// ─────────────────────────────────────────────────────────

type SiteInfo struct {
	ID         string
	Name       string
	BaseURL    string
	Language   string
	Types      []string
	Priority   int
	SearchFmt  string // formato de URL de busca (%s = query)
	Selectors  siteSelectors
}

type siteSelectors struct {
	Card    []string // seletores de card de resultado
	Title   []string // seletores de título dentro do card
	Image   []string // seletores de thumbnail
	Link    []string // seletores de link
	Episode []string // seletores de episódios
	Video   []string // seletores/padrões de vídeo
}

var AllSites = []SiteInfo{
	// ══ ANIME PT-BR ══════════════════════════════════════

	{
		ID: "animefire", Name: "AnimeFire", BaseURL: "https://animefire.plus",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 100,
		SearchFmt: "%s/pesquisar/%s",
		Selectors: siteSelectors{
			Card:    []string{"article.card-anime", "div.card-anime", ".card"},
			Title:   []string{"h3.card-title", "h2.title-anime", ".title"},
			Image:   []string{"img[src]", "img[data-src]"},
			Episode: []string{"a.lEp", ".episode-list a"},
			Video:   []string{`"videoUrl":"`, `file: '`, `player_data`},
		},
	},
	{
		ID: "goanimes", Name: "GoAnimes", BaseURL: "https://goanimes.net",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 95,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".post", "article", ".item-thumb"},
			Title:   []string{"h2", "h3", ".entry-title"},
			Episode: []string{"a[href*='episodio']", ".episodios a"},
			Video:   []string{`"file":"`, `jwplayer`, `source src`},
		},
	},
	{
		ID: "anitube", Name: "AniTube", BaseURL: "https://www.anitube.vip",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 90,
		SearchFmt: "%s/busca.php?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".lista_anime li", ".film_list .flw-item", ".item"},
			Title:   []string{".film-name", "h3", ".title"},
			Episode: []string{"a[href*='episode']", ".ep-item a"},
			Video:   []string{`"hls":"`, `"file":"`, `playerInstance`},
		},
	},
	{
		ID: "animesonline", Name: "Animes Online", BaseURL: "https://animesonlinecc.to",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 88,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".card", ".item"},
			Episode: []string{"a.numerando", ".episodios li a"},
			Video:   []string{`"videoUrl":"`, `var video_link`, `iframe src`},
		},
	},
	{
		ID: "hinatasoul", Name: "Hinata Soul", BaseURL: "https://www.hinatasoul.com",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 85,
		SearchFmt: "%s/busca?q=%s",
		Selectors: siteSelectors{
			Card:    []string{".animeBox", "article", ".card-anime"},
			Episode: []string{".episodios a", "a[href*='episodio']"},
			Video:   []string{`"videoUrl":"`, `var _source`, `jwplayer`},
		},
	},
	{
		ID: "animeshouse", Name: "Animes House", BaseURL: "https://animeshouse.net",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 82,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".card", ".item-thumb"},
			Episode: []string{".episodios a", "a.btn-episodio"},
			Video:   []string{`"file":"`, `sources:`, `iframe src`},
		},
	},
	{
		ID: "goyabu", Name: "Goyabu", BaseURL: "https://goyabu.com",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 80,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".item", ".card"},
			Episode: []string{".episodios a", ".ep a", "a[href*='episodio']"},
			Video:   []string{`"videoUrl":"`, `var video`, `jwplayer`},
		},
	},
	{
		ID: "animeking", Name: "Anime King", BaseURL: "https://animeking.com.br",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 78,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".post", ".item-thumb"},
			Episode: []string{"a[href*='episodio']", ".episodios a"},
			Video:   []string{`"file":"`, `iframe src`, `player_source`},
		},
	},
	{
		ID: "animesdigital", Name: "Animes Digital", BaseURL: "https://animesdigital.org",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 75,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".item", ".card"},
			Episode: []string{".episodios a", "a[href*='episode']"},
			Video:   []string{`"file":"`, `"videoUrl":"`, `iframe src`},
		},
	},
	{
		ID: "betteranime", Name: "BetterAnime", BaseURL: "https://betteranime.net",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 86,
		SearchFmt: "%s/pesquisar?q=%s",
		Selectors: siteSelectors{
			Card:    []string{".card", ".anime-card", ".item"},
			Episode: []string{"a[href*='episodio']", ".episodios a", ".list-episodes a"},
			Video:   []string{`"file":"`, `var videosources`, `playerNative`},
		},
	},
	{
		ID: "animesorion", Name: "Animes Orion", BaseURL: "https://animesorion.net",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 72,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".card", ".anime-card"},
			Episode: []string{"a[href*='episodio']", ".episode-list a"},
			Video:   []string{`"file":"`, `iframe src`, `videoUrl`},
		},
	},
	{
		ID: "animeszone", Name: "Animes Zone", BaseURL: "https://animeszone.net",
		Language: "pt-BR", Types: []string{"anime"}, Priority: 70,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{"article", ".item", ".card"},
			Episode: []string{"a[href*='episodio']", ".episodios a"},
			Video:   []string{`"file":"`, `iframe src`, `player_source`},
		},
	},

	// ══ FILMES/SÉRIES PT-BR ══════════════════════════════

	{
		ID: "pobreflix", Name: "Pobreflix", BaseURL: "https://pobreflix.biz",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 100,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".flw-item", ".item", ".card", "article"},
			Episode: []string{"a[href*='episodio']", ".episode-list a", "a[href*='temporada']"},
			Video:   []string{`"file":"`, `iframe src`, `source src`},
		},
	},
	{
		ID: "topflix", Name: "TopFlix", BaseURL: "https://topflix.cfd",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 98,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".flw-item", ".item", ".card"},
			Episode: []string{".ep-item a", ".episodios a"},
			Video:   []string{`"file":"`, `var playerSrc`, `iframe src`},
		},
	},
	{
		ID: "megaflix", Name: "MegaFlix", BaseURL: "https://megaflix.co",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 96,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{"a[href*='episodio']", ".episodios a"},
			Video:   []string{`"file":"`, `iframe src`, `playerSource`},
		},
	},
	{
		ID: "superflix", Name: "SuperFlix", BaseURL: "https://superflixhd.com",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 94,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{"a[href*='temporada']", ".episodios a"},
			Video:   []string{`"file":"`, `iframe src`, `sources`},
		},
	},
	{
		ID: "tugaflix", Name: "Tugaflix", BaseURL: "https://tugaflix.best",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 88,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{".ep-item a", "a[href*='episodio']"},
			Video:   []string{`"file":"`, `iframe src`, `"url":`},
		},
	},
	{
		ID: "megafilmeshd", Name: "Mega Filmes HD", BaseURL: "https://megafilmeshd.io",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 86,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{".episodios a", "a[href*='temporada']"},
			Video:   []string{`"file":"`, `iframe src`, `videoSource`},
		},
	},
	{
		ID: "doflix", Name: "Do Flix", BaseURL: "https://doflix.cc",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 84,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{"a[href*='episodio']", ".ep-item a"},
			Video:   []string{`"file":"`, `iframe src`, `jwplayer`},
		},
	},
	{
		ID: "redecanais", Name: "Rede Canais", BaseURL: "https://redecanais.ms",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 82,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{".episode-list a", "a[href*='episodio']"},
			Video:   []string{`"file":"`, `iframe src`, `source src`},
		},
	},
	{
		ID: "maxfilmes", Name: "MaxFilmes", BaseURL: "https://maxfilmes.art",
		Language: "pt-BR", Types: []string{"movie", "tv"}, Priority: 80,
		SearchFmt: "%s/?s=%s",
		Selectors: siteSelectors{
			Card:    []string{".item", ".card", "article"},
			Episode: []string{"a[href*='episodio']", ".ep-item a"},
			Video:   []string{`"file":"`, `iframe src`, `sources`},
		},
	},

	// ══ UNIVERSAL EN ══════════════════════════════════════

	{
		ID: "allanime", Name: "AllAnime", BaseURL: "https://api.allanime.day",
		Language: "en", Types: []string{"anime"}, Priority: 92,
		SearchFmt: "%s/api?query={shows(search:{query:\"%s\"},limit:20){edges{_id name thumbnail}}}",
	},
	{
		ID: "flixhq", Name: "FlixHQ", BaseURL: "https://flixhq.to",
		Language: "en", Types: []string{"movie", "tv"}, Priority: 85,
		SearchFmt: "%s/search/%s",
		Selectors: siteSelectors{
			Card:    []string{".flw-item"},
			Title:   []string{".film-name"},
			Episode: []string{".eps-item"},
			Video:   []string{`"link":`, `"sources":`},
		},
	},
	{
		ID: "animekisa", Name: "AnimeKisa", BaseURL: "https://animekisa.tv",
		Language: "en", Types: []string{"anime"}, Priority: 74,
		SearchFmt: "%s/search/?q=%s",
		Selectors: siteSelectors{
			Card:    []string{".AniItem", ".card"},
			Episode: []string{"a[href*='episode']"},
			Video:   []string{`"file":"`, `sSource`},
		},
	},
	{
		ID: "gogoanime", Name: "Gogoanime", BaseURL: "https://gogoanime3.cc",
		Language: "en", Types: []string{"anime"}, Priority: 78,
		SearchFmt: "%s/search.html?keyword=%s",
		Selectors: siteSelectors{
			Card:    []string{".items li", ".item"},
			Episode: []string{"a[href*='episode']", "#episode_page a"},
			Video:   []string{`"file":"`, `sources`, `encrypt-ajax`},
		},
	},
	{
		ID: "9anime", Name: "9Anime", BaseURL: "https://9animetv.to",
		Language: "en", Types: []string{"anime"}, Priority: 76,
		SearchFmt: "%s/search?keyword=%s",
		Selectors: siteSelectors{
			Card:    []string{".film-detail", ".flw-item"},
			Episode: []string{".ep-item a", "a[href*='episode']"},
			Video:   []string{`"link":`, `sources`},
		},
	},
}

// ─────────────────────────────────────────────────────────
// UniversalScraper — scraper genérico guiado pela SiteInfo
// ─────────────────────────────────────────────────────────

type UniversalScraper struct {
	info   SiteInfo
	client *http.Client
}

func NewUniversalScraper(info SiteInfo) *UniversalScraper {
	return &UniversalScraper{
		info:   info,
		client: newHTTPClient(12 * time.Second),
	}
}

func newHTTPClient(timeout time.Duration) *http.Client {
	return &http.Client{
		Timeout: timeout,
		Transport: &http.Transport{
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 20,
			IdleConnTimeout:     90 * time.Second,
		},
	}
}

// Implement Provider interface
func (s *UniversalScraper) ID() string               { return s.info.ID }
func (s *UniversalScraper) Name() string             { return s.info.Name }
func (s *UniversalScraper) Language() string         { return s.info.Language }
func (s *UniversalScraper) SupportedTypes() []string { return s.info.Types }
func (s *UniversalScraper) IsActive() bool           { return true }
func (s *UniversalScraper) Priority() int            { return s.info.Priority }

func (s *UniversalScraper) Search(ctx context.Context, query string) ([]*models.SearchResult, error) {
	// AllAnime tem API especial
	if s.info.ID == "allanime" {
		return s.searchAllAnime(ctx, query)
	}

	searchURL := fmt.Sprintf(s.info.SearchFmt, s.info.BaseURL, url.QueryEscape(normalizeQuery(query)))
	body, err := s.get(ctx, searchURL)
	if err != nil {
		return nil, err
	}

	doc, err := goquery.NewDocumentFromReader(strings.NewReader(string(body)))
	if err != nil {
		return nil, err
	}

	var results []*models.SearchResult
	cardSels := s.info.Selectors.Card
	if len(cardSels) == 0 {
		cardSels = []string{"article", ".item", ".card", ".film-detail"}
	}

	for _, sel := range cardSels {
		doc.Find(sel).Each(func(_ int, node *goquery.Selection) {
			r := s.parseCard(node)
			if r != nil {
				results = append(results, r)
			}
		})
		if len(results) > 0 {
			break
		}
	}
	return results, nil
}

func (s *UniversalScraper) parseCard(node *goquery.Selection) *models.SearchResult {
	// Pega link
	link := node.Find("a").First()
	href, _ := link.Attr("href")
	if href == "" {
		href, _ = node.Attr("href")
	}
	if href == "" {
		return nil
	}
	if !strings.HasPrefix(href, "http") {
		href = s.info.BaseURL + href
	}

	// Pega título (tenta múltiplos seletores)
	title := ""
	titleSels := append(s.info.Selectors.Title,
		".film-name", "h2", "h3", ".title", ".name", "a.title", "span.title")
	for _, ts := range titleSels {
		if t := strings.TrimSpace(node.Find(ts).First().Text()); t != "" {
			title = t
			break
		}
	}
	if title == "" {
		title = func() string { val, _ := link.Attr("title"); return strings.TrimSpace(val) }()
	}
	if title == "" {
		return nil
	}

	// Pega imagem
	img := ""
	for _, attr := range []string{"src", "data-src", "data-lazy-src", "data-original"} {
		if i, ok := node.Find("img").First().Attr(attr); ok && i != "" {
			img = i
			break
		}
	}
	if img != "" && !strings.HasPrefix(img, "http") {
		img = s.info.BaseURL + img
	}

	// Detecta tipo
	mt := models.MediaTypeAnime
	if len(s.info.Types) > 0 {
		switch s.info.Types[0] {
		case "movie":
			mt = models.MediaTypeMovie
		case "tv":
			mt = models.MediaTypeTV
		}
	}
	// Refina por URL
	lhref := strings.ToLower(href)
	if strings.Contains(lhref, "/serie") || strings.Contains(lhref, "/tv/") {
		mt = models.MediaTypeTV
	} else if strings.Contains(lhref, "/movie") || strings.Contains(lhref, "/filme") {
		mt = models.MediaTypeMovie
	}

	year := strings.TrimSpace(node.Find(".year, time, .date, .fdi-item").First().Text())
	qual := strings.TrimSpace(node.Find(".quality, .res, .badge-hd").First().Text())

	return &models.SearchResult{
		ID:        strings.TrimPrefix(href, s.info.BaseURL+"/"),
		Title:     title,
		ImageURL:  img,
		URL:       href,
		Provider:  s.info.ID,
		MediaType: mt,
		Year:      year,
		Quality:   qual,
		Language:  s.info.Language,
	}
}

func (s *UniversalScraper) GetDetails(ctx context.Context, id string) (*models.MediaDetails, error) {
	mediaURL := id
	if !strings.HasPrefix(id, "http") {
		mediaURL = s.info.BaseURL + "/" + strings.TrimPrefix(id, "/")
	}
	body, err := s.get(ctx, mediaURL)
	if err != nil {
		return nil, err
	}
	doc, err := goquery.NewDocumentFromReader(strings.NewReader(string(body)))
	if err != nil {
		return nil, err
	}

	title := strings.TrimSpace(doc.Find("h1, h2.film-name, .heading-name, .anime-name").First().Text())
	img, _ := doc.Find(".film-poster img, .cover img, .anime-cover img").First().Attr("src")
	overview := strings.TrimSpace(doc.Find(".description, .film-description .text, .sinopse, .overview").First().Text())

	var genres []string
	doc.Find("a[href*='genre'], .genres a, .genre a").Each(func(_ int, s *goquery.Selection) {
		if g := strings.TrimSpace(s.Text()); g != "" {
			genres = append(genres, g)
		}
	})

	mt := models.MediaTypeAnime
	if len(s.info.Types) > 0 && s.info.Types[0] == "movie" {
		mt = models.MediaTypeMovie
	}

	return &models.MediaDetails{
		ID:        id,
		Title:     title,
		ImageURL:  img,
		URL:       mediaURL,
		Provider:  s.info.ID,
		MediaType: mt,
		Overview:  overview,
		Genres:    genres,
		Language:  s.info.Language,
		HasSub:    true,
	}, nil
}

func (s *UniversalScraper) GetEpisodes(ctx context.Context, mediaURL string) ([]models.Episode, error) {
	if !strings.HasPrefix(mediaURL, "http") {
		mediaURL = s.info.BaseURL + "/" + strings.TrimPrefix(mediaURL, "/")
	}
	body, err := s.get(ctx, mediaURL)
	if err != nil {
		return nil, err
	}
	doc, err := goquery.NewDocumentFromReader(strings.NewReader(string(body)))
	if err != nil {
		return nil, err
	}

	epSels := s.info.Selectors.Episode
	if len(epSels) == 0 {
		epSels = []string{
			"a[href*='episodio']", "a[href*='episode']",
			".episodios a", ".ep-item a", ".episodes a",
			"ul.episodios li a", ".listEp a",
		}
	}

	var eps []models.Episode
	for _, sel := range epSels {
		doc.Find(sel).Each(func(i int, node *goquery.Selection) {
			href, _ := node.Attr("href")
			title := strings.TrimSpace(node.Text())
			if !strings.HasPrefix(href, "http") {
				href = s.info.BaseURL + href
			}
			if href != "" {
				eps = append(eps, models.Episode{Number: i + 1, Title: title, URL: href})
			}
		})
		if len(eps) > 0 {
			break
		}
	}
	return eps, nil
}

func (s *UniversalScraper) GetVideoSources(ctx context.Context, episodeURL string, _ int) ([]models.VideoSource, error) {
	if !strings.HasPrefix(episodeURL, "http") {
		episodeURL = s.info.BaseURL + "/" + strings.TrimPrefix(episodeURL, "/")
	}
	body, err := s.get(ctx, episodeURL)
	if err != nil {
		return nil, err
	}
	content := string(body)

	var sources []models.VideoSource

	// Padrões de extração de URL de vídeo
	patterns := []string{
		`"videoUrl":"([^"]+)"`,
		`"file":"([^"]+)"`,
		`file:\s*["']([^"']+)["']`,
		`src:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']`,
		`source\s+src="([^"]+\.(?:m3u8|mp4)[^"]*)"`,
		`["']([^"']*\.m3u8[^"']*)["']`,
		`["']([^"']*\.mp4[^"']*)["']`,
		`hlsMasterPlaylistUrl["']:\s*["']([^"']+)["']`,
		`jwplayer\([^)]+\)\.setup\(\{[^}]*file:\s*["']([^"']+)["']`,
	}

	for _, pat := range patterns {
		re := regexp.MustCompile(pat)
		for _, m := range re.FindAllStringSubmatch(content, 5) {
			if len(m) > 1 {
				vURL := strings.ReplaceAll(m[1], `\/`, `/`)
				if !strings.HasPrefix(vURL, "http") {
					continue
				}
				if isAssetURL(vURL) {
					continue
				}
				sources = append(sources, models.VideoSource{
					URL:      vURL,
					Quality:  detectQuality(vURL),
					Format:   detectFormat(vURL),
					Provider: s.info.ID,
					Referer:  s.info.BaseURL,
					Headers: map[string]string{
						"Referer":    s.info.BaseURL,
						"User-Agent": defaultUA,
					},
				})
			}
		}
	}

	// Iframes como fallback
	doc, _ := goquery.NewDocumentFromReader(strings.NewReader(content))
	if doc != nil {
		doc.Find("iframe[src], iframe[data-src]").Each(func(_ int, node *goquery.Selection) {
			src := node.AttrOr("src", node.AttrOr("data-src", ""))
			if strings.HasPrefix(src, "http") && src != episodeURL {
				sources = append(sources, models.VideoSource{
					URL: src, Quality: "auto", Format: "embed",
					Provider: s.info.ID, Referer: s.info.BaseURL,
				})
			}
		})
	}

	if len(sources) == 0 {
		return nil, fmt.Errorf("[%s] nenhuma fonte encontrada em %s", s.info.ID, episodeURL)
	}

	return deduplicateSources(sources), nil
}

// ─ AllAnime API especial (GraphQL) ────────────────────────

func (s *UniversalScraper) searchAllAnime(ctx context.Context, query string) ([]*models.SearchResult, error) {
	gql := fmt.Sprintf(`{shows(search:{query:%q,allowAdult:false},limit:26,page:1){edges{_id name englishName thumbnail availableEpisodes{sub dub}}}}`, query)
	apiURL := fmt.Sprintf("https://api.allanime.day/api?query=%s", url.QueryEscape(gql))

	body, err := s.get(ctx, apiURL)
	if err != nil {
		return nil, err
	}

	var resp struct {
		Data struct {
			Shows struct {
				Edges []struct {
					ID           string `json:"_id"`
					Name         string `json:"name"`
					EnglishName  string `json:"englishName"`
					Thumbnail    string `json:"thumbnail"`
					AvailableEps struct {
						Sub int `json:"sub"`
						Dub int `json:"dub"`
					} `json:"availableEpisodes"`
				} `json:"edges"`
			} `json:"shows"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, err
	}

	var results []*models.SearchResult
	for _, e := range resp.Data.Shows.Edges {
		title := e.Name
		if title == "" {
			title = e.EnglishName
		}
		results = append(results, &models.SearchResult{
			ID: e.ID, Title: title, ImageURL: e.Thumbnail,
			URL: e.ID, Provider: "allanime",
			MediaType: models.MediaTypeAnime, Language: "en",
			Episodes: e.AvailableEps.Sub,
		})
	}
	return results, nil
}

// ─ HTTP helper ────────────────────────────────────────────

const defaultUA = "Mozilla/5.0 (Linux; Android 15; moto g35) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

func (s *UniversalScraper) get(ctx context.Context, rawURL string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", rawURL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", defaultUA)
	req.Header.Set("Accept-Language", "pt-BR,pt;q=0.9,en;q=0.7")
	req.Header.Set("Referer", s.info.BaseURL)

	resp, err := s.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("[%s] HTTP %d", s.info.ID, resp.StatusCode)
	}
	// Limita a 2MB para não causar OOM com páginas anômalas
	return io.ReadAll(io.LimitReader(resp.Body, 2<<20))
}

// ─ Helpers ────────────────────────────────────────────────

func normalizeQuery(q string) string {
	return strings.ReplaceAll(strings.TrimSpace(q), " ", "+")
}

func detectFormat(u string) string {
	u = strings.ToLower(u)
	if strings.Contains(u, ".m3u8") {
		return "hls"
	}
	if strings.Contains(u, ".mpd") {
		return "dash"
	}
	if strings.Contains(u, ".mp4") {
		return "mp4"
	}
	return "hls"
}

func detectQuality(u string) string {
	for _, q := range []string{"4k", "2160p", "1080p", "720p", "480p", "360p"} {
		if strings.Contains(strings.ToLower(u), q) {
			return q
		}
	}
	return "auto"
}

func isAssetURL(u string) bool {
	for _, ext := range []string{".css", ".js", ".png", ".jpg", ".gif", ".svg", ".ico", ".woff"} {
		if strings.HasSuffix(strings.ToLower(u), ext) {
			return true
		}
	}
	return false
}

func deduplicateSources(sources []models.VideoSource) []models.VideoSource {
	seen := map[string]bool{}
	var out []models.VideoSource
	for _, s := range sources {
		if !seen[s.URL] {
			seen[s.URL] = true
			out = append(out, s)
		}
	}
	return out
}
