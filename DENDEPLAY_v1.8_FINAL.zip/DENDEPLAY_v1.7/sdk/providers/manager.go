// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

// Package providers — Manager principal do DENDÊPLAY SDK
package providers

import (
	"context"
	"fmt"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/dendeplay/sdk/models"
)

const (
	searchTimeout    = 14 * time.Second
	providerTimeout  = 10 * time.Second
	earlyReturnDelay = 1200 * time.Millisecond
	minResultsEarly  = 5
)

// ─────────────────────────────────────────────────────────
// providerStats — estatísticas adaptativas por provider
// ─────────────────────────────────────────────────────────

type providerStats struct {
	mu           sync.RWMutex
	successCount int64
	failCount    int64
	consecutive  int   // falhas consecutivas
	avgLatencyMs int64 // média móvel exponencial
	disabled     bool
	disabledAt   time.Time
}

func (s *providerStats) recordOK(lat time.Duration) {
	s.mu.Lock()
	defer s.mu.Unlock()
	atomic.AddInt64(&s.successCount, 1)
	s.consecutive = 0
	s.disabled    = false
	ms := lat.Milliseconds()
	if s.avgLatencyMs == 0 { s.avgLatencyMs = ms } else { s.avgLatencyMs = (s.avgLatencyMs*7 + ms*3) / 10 }
}

func (s *providerStats) recordFail() {
	s.mu.Lock()
	defer s.mu.Unlock()
	atomic.AddInt64(&s.failCount, 1)
	s.consecutive++
	if s.consecutive >= 3 { s.disabled = true; s.disabledAt = time.Now() }
}

func (s *providerStats) available() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if !s.disabled { return true }
	if time.Since(s.disabledAt) > 5*time.Minute { s.disabled = false; s.consecutive = 0; return true }
	return false
}

func (s *providerStats) score(basePriority int) float64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	total := s.successCount + s.failCount
	if total == 0 { return float64(basePriority) }
	sr := float64(s.successCount) / float64(total)
	ls := 1.0 - float64(s.avgLatencyMs)/8000.0
	if ls < 0 { ls = 0 }
	return (sr*0.6 + ls*0.2) * 100 + float64(basePriority)*0.2
}

// ─────────────────────────────────────────────────────────
// Manager — orquestra todos os 26 providers
// ─────────────────────────────────────────────────────────

type Manager struct {
	mu        sync.RWMutex
	providers map[string]Provider
	stats     map[string]*providerStats
}

func NewManager() *Manager {
	m := &Manager{
		providers: make(map[string]Provider),
		stats:     make(map[string]*providerStats),
	}

	// Registra TODOS os 26 sites
	for _, info := range AllSites {
		p := NewUniversalScraper(info)
		m.providers[p.ID()] = p
		m.stats[p.ID()] = &providerStats{}
	}

	return m
}

// ─── Busca em todos simultaneamente ──────────────────────

func (m *Manager) SearchAll(query string) ([]*models.SearchResult, error) {
	active := m.sorted()

	ctx, cancel := context.WithTimeout(context.Background(), searchTimeout)
	defer cancel()

	type res struct {
		items []*models.SearchResult
		id    string
		lat   time.Duration
	}
	ch := make(chan res, len(active))
	var count atomic.Int32

	for _, p := range active {
		go func(prov Provider) {
			pCtx, pCancel := context.WithTimeout(ctx, providerTimeout)
			defer pCancel()
			start := time.Now()
			items, err := prov.Search(pCtx, query)
			lat := time.Since(start)
			if err != nil || len(items) == 0 {
				m.fail(prov.ID())
				ch <- res{id: prov.ID()}
				return
			}
			m.ok(prov.ID(), lat)
			count.Add(int32(len(items)))
			ch <- res{items: items, id: prov.ID(), lat: lat}
		}(p)
	}

	var all []*models.SearchResult
	rcv  := 0
	dl   := time.After(searchTimeout)
	early := time.After(earlyReturnDelay)

loop:
	for rcv < len(active) {
		select {
		case r := <-ch:
			all = append(all, r.items...)
			rcv++
			if rcv == len(active) { break loop }
		case <-early:
			if count.Load() >= minResultsEarly { break loop }
		case <-dl:
			break loop
		}
	}

	return dedup(rank(all, query)), nil
}

// ─── Busca por tipo ───────────────────────────────────────

func (m *Manager) SearchByType(query, mediaType string) ([]*models.SearchResult, error) {
	m.mu.RLock()
	var filtered []Provider
	for _, p := range m.providers {
		if !p.IsActive() { continue }
		for _, t := range p.SupportedTypes() {
			if t == mediaType { filtered = append(filtered, p); break }
		}
	}
	m.mu.RUnlock()

	ctx, cancel := context.WithTimeout(context.Background(), searchTimeout)
	defer cancel()

	type res struct{ items []*models.SearchResult }
	ch := make(chan res, len(filtered))
	for _, p := range filtered {
		go func(prov Provider) {
			items, _ := prov.Search(ctx, query)
			ch <- res{items}
		}(p)
	}
	var all []*models.SearchResult
	for range filtered {
		r := <-ch
		all = append(all, r.items...)
	}
	return dedup(rank(all, query)), nil
}

// ─── Provider específico ──────────────────────────────────

func (m *Manager) SearchByProvider(query, id string) ([]*models.SearchResult, error) {
	m.mu.RLock()
	p, ok := m.providers[id]
	m.mu.RUnlock()
	if !ok { return nil, fmt.Errorf("provider %q não encontrado", id) }
	ctx, cancel := context.WithTimeout(context.Background(), providerTimeout)
	defer cancel()
	return p.Search(ctx, query)
}

func (m *Manager) GetDetails(id, providerID string) (*models.MediaDetails, error) {
	m.mu.RLock()
	p, ok := m.providers[providerID]
	m.mu.RUnlock()
	if !ok { return nil, fmt.Errorf("provider %q não encontrado", providerID) }
	ctx, cancel := context.WithTimeout(context.Background(), providerTimeout)
	defer cancel()
	return p.GetDetails(ctx, id)
}

func (m *Manager) GetEpisodes(mediaURL, providerID string) ([]models.Episode, error) {
	m.mu.RLock()
	p, ok := m.providers[providerID]
	m.mu.RUnlock()
	if !ok { return nil, fmt.Errorf("provider %q não encontrado", providerID) }
	ctx, cancel := context.WithTimeout(context.Background(), providerTimeout)
	defer cancel()
	return p.GetEpisodes(ctx, mediaURL)
}

// ─── Fontes de vídeo com fallback em cadeia ───────────────

func (m *Manager) GetVideoSources(episodeURL, providerID string, epNum int) ([]models.VideoSource, error) {
	// 1. Tenta provider primário
	m.mu.RLock()
	primary, ok := m.providers[providerID]
	m.mu.RUnlock()

	if ok {
		ctx1, c1 := context.WithTimeout(context.Background(), providerTimeout)
		t := time.Now()
		srcs, err := primary.GetVideoSources(ctx1, episodeURL, epNum)
		c1()
		if err == nil && len(srcs) > 0 {
			m.ok(providerID, time.Since(t))
			return srcs, nil
		}
		m.fail(providerID)
	}

	// 2. Fallback em cadeia pelo score
	m.mu.RLock()
	type sp struct{ p Provider; s float64 }
	var cands []sp
	for id, p := range m.providers {
		if id == providerID || !p.IsActive() { continue }
		if st := m.stats[id]; st != nil && !st.available() { continue }
		sc := float64(p.Priority())
		if st := m.stats[id]; st != nil { sc = st.score(p.Priority()) }
		cands = append(cands, sp{p, sc})
	}
	m.mu.RUnlock()

	sort.Slice(cands, func(i, j int) bool { return cands[i].s > cands[j].s })

	for _, c := range cands {
		ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
		srcs, err := c.p.GetVideoSources(ctx, episodeURL, epNum)
		cancel()
		if err == nil && len(srcs) > 0 {
			m.ok(c.p.ID(), 0)
			return srcs, nil
		}
		m.fail(c.p.ID())
	}

	return nil, fmt.Errorf("nenhuma fonte de vídeo encontrada em nenhum dos %d providers", len(cands)+1)
}

// ─── Info dos providers ───────────────────────────────────

func (m *Manager) AvailableProviders() []models.ProviderInfo {
	m.mu.RLock()
	defer m.mu.RUnlock()
	var list []models.ProviderInfo
	for _, p := range m.providers {
		list = append(list, models.ProviderInfo{
			ID: p.ID(), Name: p.Name(), Language: p.Language(),
			Types: p.SupportedTypes(), Active: p.IsActive(), Priority: p.Priority(),
		})
	}
	sort.Slice(list, func(i, j int) bool { return list[i].Priority > list[j].Priority })
	return list
}

func (m *Manager) ProviderCount() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.providers)
}

// ─── Trending / Latest ────────────────────────────────────

func (m *Manager) GetTrending(mediaType string) ([]*models.SearchResult, error) {
	year := time.Now().Year()
	queries := map[string][]string{
		"anime": {fmt.Sprintf("anime popular %d", year), "anime trending"},
		"movie": {fmt.Sprintf("filmes lançamentos %d", year), "melhores filmes"},
		"tv":    {fmt.Sprintf("series populares %d", year)},
		"all":   {fmt.Sprintf("popular %d", year), "lançamentos"},
	}
	q := queries[mediaType]
	if q == nil { q = queries["all"] }

	if mediaType == "all" || mediaType == "anime" {
		return m.SearchByType(q[0], "anime")
	}
	return m.SearchByType(q[0], mediaType)
}

func (m *Manager) GetLatestEpisodes() ([]*models.SearchResult, error) {
	return m.GetTrending("anime")
}

// ─── helpers ─────────────────────────────────────────────

func (m *Manager) sorted() []Provider {
	m.mu.RLock()
	defer m.mu.RUnlock()
	var list []Provider
	for id, p := range m.providers {
		if !p.IsActive() { continue }
		if st := m.stats[id]; st != nil && !st.available() { continue }
		list = append(list, p)
	}
	sort.Slice(list, func(i, j int) bool {
		si, sj := m.stats[list[i].ID()], m.stats[list[j].ID()]
		vi, vj := float64(list[i].Priority()), float64(list[j].Priority())
		if si != nil { vi = si.score(list[i].Priority()) }
		if sj != nil { vj = sj.score(list[j].Priority()) }
		return vi > vj
	})
	return list
}

func (m *Manager) ok(id string, lat time.Duration) {
	m.mu.RLock(); s, ok := m.stats[id]; m.mu.RUnlock()
	if ok { s.recordOK(lat) }
}

func (m *Manager) fail(id string) {
	m.mu.RLock(); s, ok := m.stats[id]; m.mu.RUnlock()
	if ok { s.recordFail() }
}

func dedup(items []*models.SearchResult) []*models.SearchResult {
	seen := map[string]bool{}
	var out []*models.SearchResult
	for _, it := range items {
		k := it.Provider + ":" + it.ID
		if !seen[k] { seen[k] = true; out = append(out, it) }
	}
	return out
}

func rank(items []*models.SearchResult, query string) []*models.SearchResult {
	qLower := strings.ToLower(strings.TrimSpace(query))
	sort.SliceStable(items, func(i, j int) bool {
		a, b := items[i], items[j]
		// Prioridade 1: PT-BR primeiro
		if (a.Language == "pt-BR") != (b.Language == "pt-BR") {
			return a.Language == "pt-BR"
		}
		// Prioridade 2: título contém a query
		aMatch := strings.Contains(strings.ToLower(a.Title), qLower)
		bMatch := strings.Contains(strings.ToLower(b.Title), qLower)
		if aMatch != bMatch {
			return aMatch
		}
		// Prioridade 3: rating
		return a.Rating > b.Rating
	})
	return items
}
