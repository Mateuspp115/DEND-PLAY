// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime

package providers

import "context"
import "github.com/dendeplay/sdk/models"

// Provider é a interface que todo scraper implementa.
type Provider interface {
	ID() string
	Name() string
	Language() string
	SupportedTypes() []string
	IsActive() bool
	Priority() int
	Search(ctx context.Context, query string) ([]*models.SearchResult, error)
	GetDetails(ctx context.Context, id string) (*models.MediaDetails, error)
	GetEpisodes(ctx context.Context, mediaURL string) ([]models.Episode, error)
	GetVideoSources(ctx context.Context, episodeURL string, epNum int) ([]models.VideoSource, error)
}
