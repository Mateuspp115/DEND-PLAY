# DENDÊPLAY — Relatório Técnico Completo
## Análise de Progresso, Bugs, Otimizações e Roadmap
**Versão:** v1.7.0 | **Data:** Março 2026 | **Autor:** Mateus "TinkWink"

---

## Índice

1. [Visão Geral do Projeto](#1-visão-geral)
2. [O que está Completo](#2-completo)
3. [Bugs Encontrados e Corrigidos](#3-bugs-corrigidos)
4. [Problemas Restantes](#4-problemas-restantes)
5. [Análise de Compatibilidade por Dispositivo](#5-compatibilidade)
6. [Análise de Performance](#6-performance)
7. [O que ainda Falta Implementar](#7-falta-implementar)
8. [O que ainda dá para Melhorar](#8-melhorias-possíveis)
9. [Roadmap Sugerido (v1.6 em diante)](#9-roadmap)
10. [Nota Final — Maturidade do Projeto](#10-nota-final)

---

## 1. Visão Geral

O DENDÊPLAY é um app Android de streaming de animes, filmes e séries em PT-BR, construído sobre o GoAnime (Krone, 2023) com profundas modificações e um sistema de cast que rivaliza com soluções comerciais.

| Item | Valor |
|---|---|
| Versão atual | 1.7.0 |
| Arquivos Kotlin | 43 |
| Arquivos Go (SDK) | 12 |
| Total de arquivos | 89 |
| Providers de conteúdo | 26 |
| Plataformas de Cast | 6 |
| Android mínimo | 8.0 (API 26) |
| Android alvo | 15 (API 35) |
| Arquiteturas suportadas | arm64-v8a, armeabi-v7a, x86_64 |
| Versões anteriores | v1.0 → v1.5 (evolução documentada) |

---

## 2. O que está Completo

### 2.1 Infraestrutura

| Componente | Status | Qualidade |
|---|---|---|
| Go SDK com 26 providers | Completo | Excelente |
| gomobile bind (AAR) | Completo | Excelente |
| Hilt DI em todo o projeto | Completo | Excelente |
| GitHub Actions CI/CD (5 jobs) | Completo | Excelente |
| ProGuard + minify + shrink | Completo | Excelente |
| Dual License (MIT + DENDEPLAY) | Completo | Excelente |
| go.sum com todas as hashes | Completo | Excelente |
| Wrapper JAR download automático no CI | Completo | Bom |

### 2.2 Funcionalidades de Conteúdo

| Funcionalidade | Status |
|---|---|
| Busca universal (26 providers em paralelo) | Completo |
| Busca por tipo (anime / filme / série) | Completo |
| Busca por provider específico | Completo |
| Detalhes de mídia com episódios | Completo |
| Trending por tipo | Completo |
| Últimos episódios | Completo |
| Skip abertura/encerramento (AniSkip) | Completo |
| Rate limiting por provider | Completo |
| Health checker com média móvel | Completo |
| Cache preditivo com aprendizado | Completo |

### 2.3 Player de Vídeo

| Funcionalidade | Status |
|---|---|
| ExoPlayer com HLS/DASH/MP4 | Completo |
| Gestos (seek, volume, brilho) | Completo |
| Picture-in-Picture | Completo |
| Botão pular abertura/encerramento | Completo |
| Controles com overlay animado | Completo |
| Próximo episódio | Estrutura pronta |
| Modo Rádio (áudio apenas) | Estrutura pronta |

### 2.4 Sistema de Cast

| Plataforma | Descoberta | Controle | Qualidade |
|---|---|---|---|
| Chromecast | MediaRouter | Google Cast SDK | Excelente |
| DLNA genérico | NSD + SSDP | SOAP/UPnP | Bom |
| Samsung Tizen | SSDP M-SEARCH | REST API :8001 | Bom |
| LG webOS | SSDP M-SEARCH | WebSocket JSON | Bom |
| Roku TV | SSDP M-SEARCH | ECP HTTP :8060 | Bom |
| Android TV | SSDP DIAL | HTTP :9080 | Básico |
| Desativar economia de energia | WakeLock | PowerManager | Completo |
| CastRemoteControl | BottomSheet | Play/Pause/Seek/Vol/Speed | Completo |

### 2.5 Funcionalidades do Usuário

| Funcionalidade | Status |
|---|---|
| Histórico de episódios | Completo |
| Progresso por episódio | Completo |
| Favoritos | Completo |
| Downloads offline (pause/resume) | Completo |
| Download Foreground Service | Completo |
| Assistente de voz offline | Completo |
| Watch Party (criação/entrada) | Básico (sem servidor) |
| Modo Viagem | Completo |
| Modo Surpresa inteligente | Completo (v1.5) |
| Chat por série/anime | Completo (local, v1.5) |
| Conta Google | Estrutura pronta (v1.5) |
| Preferência áudio (dub/leg) | Completo (v1.5) |

### 2.6 UI / UX

| Tela | Status |
|---|---|
| Splash animado (canvas fireball) | Completo |
| Home com 5 seções | Completo |
| Busca com filtros e suggestions | Completo |
| Detalhe com episódios | Completo |
| Abas por gênero (11 abas) | Completo (v1.5) |
| Downloads com progresso | Completo |
| Perfil com conta Google | Completo (v1.5) |
| Créditos com dual license | Completo |
| Modo escuro (100%) | Completo |
| Animações e transições | Completo |
| Bottom navigation com 5 abas | Completo (v1.5) |

### 2.7 API Unificada (ARUAN)

| Componente | Status |
|---|---|
| Interface DataProvider | Completo |
| LocalDataProvider (offline) | Completo |
| CloudSyncService (interface futura) | Estrutura pronta |
| DendeAPI.kt (ponto central) | Completo |
| Recomendações por gênero | Completo |
| Recomendação simulada por IA | Completo |
| setAruanEndpoint() | Pronto para usar |
| sendUserBehavior() | Completo |
| Análise legal para Play Store | Completo (docs/) |

---

## 3. Bugs Encontrados e Corrigidos nesta Auditoria

### 3.1 Bugs Críticos (todos corrigidos)

**Bug: `sync.Mutex` com `RLock()` em `manager.go` e `rate_limiter.go`**
- **Problema:** `sync.Mutex` não tem `RLock()`. Usar `RLock()` em `sync.Mutex` causa panic em runtime no Go.
- **Impacto:** Crash garantido ao fazer busca concorrente (situação normal de uso).
- **Correção:** Substituído por `sync.RWMutex` nos dois arquivos.
- **Status:** ✅ Corrigido

### 3.2 Bugs de Alta Prioridade (todos corrigidos)

**Bug: `CoroutineScope` ad-hoc dentro de `@Composable`**
- **Problema:** `GenreTabsScreen` criava `CoroutineScope(Dispatchers.Main)` dentro do onClick do Tab. Cada recomposição criava um novo scope não gerenciado, causando memory leak progressivo.
- **Impacto:** Consumo de memória crescendo com o uso das abas de gênero.
- **Correção:** Substituído por `scope.launch { }` usando o `rememberCoroutineScope()` já existente.
- **Status:** ✅ Corrigido

**Bug: `LocalDataProvider` sem `@Singleton`**
- **Problema:** Sem a annotation, o Hilt criava uma nova instância a cada injeção, perdendo o estado das preferências aprendidas e zerando os contadores de gênero.
- **Impacto:** Modo Surpresa nunca aprendia os gostos do usuário — sempre voltava ao estado inicial.
- **Correção:** Adicionado `@Singleton` e import `javax.inject.Singleton`.
- **Status:** ✅ Corrigido

### 3.3 Bugs de Média Prioridade (corrigidos)

**Bug: Rota `TravelModeScreen` não registrada no NavGraph**
- **Problema:** A tela de Modo Viagem foi implementada na v1.1 mas nunca recebeu rota no `NavHost`. Era inacessível ao usuário.
- **Correção:** Adicionados `Screen.Travel` e `Screen.Voice` com composables no NavHost.
- **Status:** ✅ Corrigido

**Bug: `android.R.drawable.stat_sys_download` pode não existir**
- **Problema:** Drawable do sistema não garantido em todas as versões e fabricantes Android.
- **Correção:** Substituído por `R.drawable.ic_logo` (drawable próprio do app).
- **Status:** ✅ Corrigido

**Bug: HomeViewModel sem timeout por seção**
- **Problema:** 5 `async{}` sem timeout individual. Se `getTrending()` travasse, toda a tela Home ficava em loading infinito.
- **Correção:** Adicionado `withTimeoutOrNull(10_000)` na chamada de trending.
- **Status:** ✅ Corrigido

---

## 4. Problemas Restantes

### 4.1 Requerem Servidor (por design)

| Problema | Razão | Solução Futura |
|---|---|---|
| Google Sign-In não autentica | `WEB_CLIENT_ID` = placeholder | Criar projeto Firebase + google-services.json |
| Watch Party sem backend | Precisa de WebSocket real | Servidor ARUAN |
| Chat apenas local | Sem sincronia entre usuários | API REST no servidor |
| Sync de histórico entre dispositivos | Sem cloud | CloudSyncService |
| ARUAN IA sem endpoint | Sem servidor | `setAruanEndpoint(url)` |

### 4.2 Comportamento em Dispositivos Específicos

| Dispositivo / OS | Problema | Impacto |
|---|---|---|
| Android 13+ | `SpeechRecognizer` pode exigir permissão pós-`onResume` (mudança de API) | Assistente de voz pode não funcionar na primeira chamada |
| Roteadores empresariais | SSDP/NSD bloqueado por firewall | Cast não encontra TVs — precisa de fallback manual de IP |
| Algumas TVs Samsung 2018-2020 | API `MultiScreen` descontinuada, usa nova API SmartView | Samsung Tizen manager pode não conectar |
| Android TV com Leanback UI | DIAL na porta 9080 depende do modelo | Cast para AndroidTV pode falhar em aparelhos genéricos |
| Dispositivos com 1GB RAM | ExoPlayer + HLS + Coil cache simultâneos | OOM possível em animes com alta resolução |

### 4.3 Problemas de UX

| Problema | Localização | Severidade |
|---|---|---|
| Sem mensagem quando providers falham silenciosamente | SearchViewModel | Média |
| Sem retry automático em `DetailScreen` após erro | DetailViewModel | Baixa |
| Paginação ausente — carrega 60 items de uma vez nas abas | GenreTabsViewModel | Média |
| AsyncImage sem placeholder/error state | HomeScreen, GenreCard | Baixa |
| Slider do player sem contentDescription (TalkBack) | PlayerScreenV11 | Baixa (acessibilidade) |

---

## 5. Análise de Compatibilidade por Dispositivo

### 5.1 Matrix de Suporte

| Android Version | API | Suporte | Observações |
|---|---|---|---|
| Android 8.0 (Oreo) | 26 | Mínimo suportado | PiP, Foreground Service funcionais |
| Android 9 (Pie) | 28 | Completo | Sem problemas conhecidos |
| Android 10 | 29 | Completo | Dark mode nativo |
| Android 11 | 30 | Completo | Scoped Storage compatível |
| Android 12 | 31 | Completo | Splash Screen API melhorada |
| Android 13 | 33 | Atenção | RECORD_AUDIO exige verificação extra |
| Android 14 | 34 | Completo | Media3 otimizado |
| Android 15 | 35 | Testado | Moto G35 — referência de testes |

### 5.2 Dispositivos de Baixo Custo

O app foi desenvolvido tendo o **Moto G35 (Android 15)** como referência. Dispositivos com especificações similares ou inferiores:

**Pontos de atenção para 1-2GB RAM:**
- ExoPlayer HLS com qualidade Auto pode selecionar resoluções altas demais
- Cache de imagens Coil sem limite explícito pode crescer
- 11 abas de gênero com cache em memória no `GenreTabsViewModel`
- `AdvancedCastManager` com scan de 254 IPs (port scan fallback) é intenso

**Recomendação:** Implementar `LowMemoryWatcher` usando `ComponentCallbacks2.onTrimMemory()` para liberar cache de imagens e de gêneros quando o sistema sinalizar pressão de memória.

### 5.3 Coil em Conexões Lentas (3G/2G)

O app não exibe estado de carregamento nas imagens dos cards de gênero e home. Em conexões lentas, o usuário vê espaços em branco por vários segundos. Solução: adicionar `placeholder(R.drawable.ic_logo)` e `error(R.drawable.ic_logo)` no `AsyncImage`.

---

## 6. Análise de Performance

### 6.1 O que está Bem

| Aspecto | Implementação | Qualidade |
|---|---|---|
| Cache duplo (disco + preditivo) | `DiskCache` + `PredictiveCache` | Excelente |
| Busca paralela com early-return | `ParallelSearch` com `atomic.Int64` | Excelente |
| Rate limiting por provider | Janela deslizante 1 minuto | Excelente |
| Health checker em background | Ticker a cada 3 minutos | Excelente |
| Coroutines com IO dispatcher | Todos os managers de cast | Excelente |
| ProGuard + R8 no release | shrinkResources + minify | Excelente |
| Deduplicação de resultados de busca | `distinctBy` por título | Bom |

### 6.2 Gargalos Identificados

**GenreTabsViewModel — Busca sem limite**
```
Problema: Busca todos os termos + await() de todos antes de mostrar resultado
Impacto: Até 5-8 segundos para carregar aba de gênero pela primeira vez
Solução: Mostrar resultados conforme chegam (Flow<List>) + timeout de 5s total
```

**DendeLogo Canvas — Recomposição**
```
Problema: Canvas com 11 paths complexos redesenhado em toda recomposição
Impacto: Jank na animação de seleção do bottom navigation
Solução: Mover para Modifier.graphicsLayer{} + drawBehind{} ou usar PNG vetorial
```

**DownloadsViewModel — Polling**
```
Problema: while(true) { delay(2000); refresh() } para verificar progresso
Impacto: CPU ativa a cada 2s mesmo quando app está em background
Solução: Substituir por StateFlow emitido pelo DownloadService via BroadcastReceiver
```

**HomeViewModel — Sem timeout individual**
```
Problema: Uma seção lenta (ex: getLatestEpisodes()) pode atrasar as outras 4
Impacto: Tela de home pode ficar loading até 12s em conexões lentas
Solução: withTimeoutOrNull(8_000) em cada seção (parcialmente corrigido no getTrending)
```

---

## 7. O que ainda Falta Implementar

### 7.1 Prioridade Alta — Funcionalidade Core

| Funcionalidade | Por quê é importante |
|---|---|
| **Paginação (Paging3)** | Sem paginação, carregar 60+ resultados por vez é lento e consome memória |
| **Room Database** | SharedPreferences tem limite de tamanho e não é consultável. Chat com 200 msgs por série vai crescer |
| **Notificações de novo episódio** | WorkManager que verifica providers periódicamente e notifica quando sai novo ep |
| **DRM Support** | Alguns providers têm conteúdo protegido (Widevine L3 no mínimo) |
| **Qualidade selecionável no player** | Hoje só funciona com "auto" — usuário não escolhe 1080p/720p/480p |
| **Legendas SRT/VTT no player** | ExoPlayer suporta, só falta implementar `SubtitleConfiguration` |

### 7.2 Prioridade Média — UX e Robustez

| Funcionalidade | Descrição |
|---|---|
| **Placeholder e ErrorState nas imagens** | `AsyncImage` sem feedback visual em loading/erro |
| **Modo offline completo** | Detectar conexão e mostrar apenas conteúdo baixado quando offline |
| **Deep links** | `dendeplay://anime/naruto` para compartilhar via link |
| **Atalhos de app** | Long-press no ícone → "Continuar Assistindo", "Buscar" |
| **Android TV Layout** | Tela dedicada para Leanback UI (D-pad navigation) |
| **Tela de erro de rede** | Tela genérica quando todas as buscas falham por falta de internet |
| **Feedback háptico consistente** | Alguns elementos têm, outros não |

### 7.3 Prioridade Baixa — Acessibilidade

| Item | Descrição |
|---|---|
| contentDescription nos Sliders | TalkBack não funciona bem no player |
| Tamanho mínimo de toque | Alguns botões pequenos (< 48dp) |
| Contraste de cores | Verificar WCAG 2.1 nas cores de texto secundário |
| Suporte a fontes grandes | Texto pode sobrepor em configurações de fonte grande do sistema |

### 7.4 Infraestrutura Futura (quando servidor existir)

| Componente | Função |
|---|---|
| `CloudSyncService` impl | Implementar interface já definida |
| `google-services.json` | Firebase config para Google Sign-In real |
| WebSocket server | Watch Party funcional com múltiplos usuários |
| ARUAN endpoint | Conectar `setAruanEndpoint()` à IA real |
| Analytics (opcional) | Entender quais providers falham mais |

---

## 8. O que ainda dá para Melhorar

### 8.1 SDK Go

```
AGORA (v1.5):          Busca paralela → early return → cache disco + preditivo
PODE MELHORAR:         Adicionar bloom filter para deduplicação mais rápida
                       Implementar streaming de resultados via channel
                       Compressão gzip no cache de disco (já implementado mas não integrado)
                       Warm-up do SDK ao iniciar (pre-fetch trending em background)
```

### 8.2 Sistema de Cast

```
AGORA (v1.5):          6 plataformas, WebSocket LG, ECP Roku, SOAP DLNA
PODE MELHORAR:         Samsung 2022+ usa API SmartThings (diferente da MultiScreen)
                       AirPlay2 para iOS/MacOS (requer biblioteca terceira)
                       Miracast/WiDi via MediaProjection API
                       Controle de volume nativo do dispositivo via AudioManager
                       Reconexão automática após queda de Wi-Fi
```

### 8.3 Player

```
AGORA (v1.5):          ExoPlayer HLS/DASH, gestos, PiP, skip intro
PODE MELHORAR:         Seletor de qualidade em tempo real (track selection)
                       Legenda externa (arrastar arquivo SRT)
                       Speed control mais granular (0.5, 0.75, 1.0, 1.25, 1.5, 2.0)
                       Equalizer de áudio (grave/agudo)
                       Lock de orientação por gesto
                       Miniatura de preview ao arrastar o slider (thumbnail sprite)
```

### 8.4 Modo Surpresa

```
AGORA (v1.5):          70/20/10 com pesos por gênero, 3 modos
PODE MELHORAR:         Filtrar por duração (30min vs 2h)
                       Excluir séries longas (> 100 episódios) opcionalmente
                       Baseado em dia da semana (terror às sextas)
                       "Não mostrar de novo" por item
```

### 8.5 Chat por Série

```
AGORA (v1.5):          Local por mediaId, likes, 200 msgs/série
PODE MELHORAR:         Quando servidor existir: chat real entre usuários
                       Spoiler tags (ocultar texto até clicar)
                       Reações por emoji
                       Replies encadeados
                       Marcação de episódio ("assistindo ep 12")
                       Moderação básica
```

### 8.6 Abas de Gênero

```
AGORA (v1.5):          11 gêneros, filtro por tipo, cache por aba
PODE MELHORAR:         Abas personalizáveis (reordenar, ocultar)
                       Scroll infinito com Paging3
                       Seção "Novo nesta semana" por gênero
                       Layout alternativo (lista vs grid)
```

---

## 9. Roadmap Sugerido (v1.6 em diante)

### v1.6 — Robustez
- [ ] Room Database substituindo SharedPreferences para chat e histórico
- [ ] Paging3 nas abas de gênero e resultados de busca
- [ ] Qualidade selecionável no player
- [ ] Notificações de novos episódios via WorkManager
- [ ] Placeholder e error state em todas as imagens
- [ ] Modo offline completo com detecção de rede
- [ ] withTimeoutOrNull em todas as seções do HomeViewModel

### v1.7 — Servidor & Conta
- [ ] Implementar backend mínimo (Node.js ou Go)
- [ ] google-services.json + Firebase real
- [ ] CloudSyncService implementado
- [ ] Chat real entre usuários via WebSocket
- [ ] Watch Party funcional
- [ ] ARUAN IA endpoint configurável pela UI de ajustes

### v1.8 — TV & Acessibilidade
- [ ] Layout Leanback para Android TV
- [ ] D-pad navigation em todas as telas
- [ ] contentDescription completo (TalkBack)
- [ ] Suporte a fontes grandes do sistema
- [ ] Legenda externa SRT/VTT

### v1.9 — Premium Features
- [ ] AirPlay2 (se viável)
- [ ] Equalizer de áudio
- [ ] Preview de thumbnail ao arrastar slider
- [ ] Deep links compartilháveis
- [ ] Atalhos de app (long-press ícone)
- [ ] Widget de "Continue Assistindo"

### v2.0 — Plataforma
- [ ] Testes unitários (meta: 60% cobertura)
- [ ] CI com lint automatizado
- [ ] Documentação de API interna
- [ ] ARUAN IA totalmente integrada com recomendações reais
- [ ] Publicação via GitHub Releases (estratégia recomendada)

---

## 10. Nota Final — Maturidade do Projeto

### O app está completo para uso pessoal?

**Sim**, para uso como app de streaming pessoal no seu dispositivo, o DENDÊPLAY v1.5 está funcional e bem construído. O core (busca, player, cast) funciona. As funcionalidades sociais (chat, conta, watch party) estão com estrutura pronta mas precisam de servidor para funcionar entre pessoas.

### Está pronto para a Play Store?

**Não diretamente.** Os principais bloqueios são:
1. A natureza do conteúdo (scraping de sites de terceiros) viola as políticas do Google Play
2. Falta `google-services.json` para Google Sign-In funcionar
3. Zero testes automatizados (Play Store exige testes básicos para algumas aprovações)
4. A estratégia recomendada continua sendo **GitHub Releases + sideload** (documentada em `docs/PLAYSTORE_LEGAL_ANALYSIS.md`)

### Em que percentual de completude está?

| Área | Completude |
|---|---|
| Core de conteúdo (busca + player) | 88% |
| Sistema de Cast | 80% |
| Funcionalidades do usuário | 75% |
| UI/UX | 82% |
| Infraestrutura (SDK Go + CI) | 90% |
| Social (chat, conta, watch party) | 40% (precisa servidor) |
| Acessibilidade | 45% |
| Testes | 5% |
| **TOTAL ESTIMADO** | **72%** |

O projeto está em ponto de inflexão: tecnicamente sólido, com as bases corretas, mas faltando principalmente a camada de servidor e alguns polimentos de UX para ser considerado completo em todos os sentidos.

---

## Resumo dos Bugs Corrigidos nesta Auditoria

| # | Bug | Severidade | Arquivo | Status |
|---|---|---|---|---|
| 1 | `sync.Mutex` + `RLock()` em `manager.go` | CRÍTICO | sdk/providers/manager.go | ✅ |
| 2 | `sync.Mutex` + `RLock()` em `rate_limiter.go` | CRÍTICO | sdk/rate_limiter.go | ✅ |
| 3 | `CoroutineScope` ad-hoc em Composable | ALTO | GenreTabsScreen.kt | ✅ |
| 4 | `LocalDataProvider` sem `@Singleton` | ALTO | LocalDataProvider.kt | ✅ |
| 5 | Rota `TravelModeScreen` ausente no NavGraph | ALTO | MainActivity.kt | ✅ |
| 6 | `android.R.drawable` não garantido | MÉDIO | DownloadForegroundService.kt | ✅ |
| 7 | `HomeViewModel.getTrending` sem timeout | MÉDIO | HomeViewModel.kt | ✅ |

---

*DENDÊPLAY v1.5.0 — Relatório gerado em Março 2026*
*© 2026 Mateus "TinkWink" | Baseado no GoAnime © 2023 Krone — MIT License*
