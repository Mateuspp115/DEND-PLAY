# DENDÊPLAY — Análise Legal e Estratégia para Play Store
## Documento Confidencial | Mateus "TinkWink" | 2026

---

## SUMÁRIO EXECUTIVO

Este documento analisa as implicações jurídicas de publicar o DENDÊPLAY na
Google Play Store, estratégias para minimizar riscos, jurisdição aplicável
e caminhos legais viáveis. A análise considera especificamente o ecossistema
brasileiro e as políticas do Google Play.

**Conclusão antecipada:** Publicação é tecnicamente possível, mas envolve
riscos jurídicos reais que podem ser mitigados com as estratégias certas.

---

## PARTE 1 — ANÁLISE DO CONTEÚDO

### O que o app faz

O DENDÊPLAY é um **agregador de links** que:

1. Faz scraping de sites de terceiros (AnimeFire, GoAnimes, etc.)
2. Extrai e exibe links de vídeo hospedados nesses sites
3. NÃO hospeda nenhum conteúdo de vídeo próprio
4. NÃO armazena conteúdo protegido por direitos autorais em seus servidores

### Analogia legal

O DENDÊPLAY funciona de forma análoga a:
- **Google Search** — indexa e apresenta links de terceiros
- **VLC Media Player** — reproduz qualquer URL fornecida
- **Web Video Cast** — transmite conteúdo de URLs para TVs

Essa distinção é crucial: o app é um **player/agregador**, não um distribuidor
de conteúdo.

---

## PARTE 2 — RISCOS JURÍDICOS

### 2.1 Direitos Autorais (Copyright)

**Risco: ALTO**

Os sites scraped (AnimeFire, Pobreflix, etc.) distribuem conteúdo protegido
sem licença adequada. Ao agregar links para esse conteúdo:

- Você pode ser considerado **facilitador de infração de direitos autorais**
- Isso se enquadra no conceito de *contributory infringement* (EUA) ou
  "violação indireta" no direito brasileiro

**Mitigação:**
- O app acessa apenas URLs públicas (sem bypass de DRM)
- Não hospeda conteúdo
- Inclui aviso de que usuários devem respeitar direitos autorais
- Inclui mecanismo de denuncia de conteúdo
- Não facilita download de conteúdo protegido por padrão

**Base legal favorável (Brasil):**
- Art. 107 da Lei 9.610/98 — limitações ao direito autoral
- O acesso pessoal e privado a conteúdo disponível publicamente não é
  tipificado como infração penal pelo Marco Civil da Internet (Lei 12.965/14)

---

### 2.2 Políticas do Google Play

**Risco: MUITO ALTO (para ban da conta)**

O Google Play tem políticas explícitas contra:

- Apps que "facilitam pirataria" (seção de Propriedade Intelectual)
- Apps de scraping de sites sem autorização
- Apps que acessam conteúdo pago gratuitamente

**Histórico:** Apps similares (Exodus, Popcorn Time, Kodi com addons pirata)
foram repetidamente removidos da Play Store.

---

### 2.3 Responsabilidade Civil

**Risco: MÉDIO**

Produtoras e distribuidoras (Netflix, Crunchyroll, etc.) poderiam entrar
com ação civil por:
- Interferência em relação comercial
- Concorrência desleal

Em geral, ações são direcionadas aos próprios sites (AnimeFire, etc.), não
aos apps que os linkam.

---

## PARTE 3 — JURISDIÇÃO

### 3.1 Lei Aplicável (Brasil)

- **Lei 9.610/98** — Lei de Direitos Autorais
- **Lei 12.965/14** — Marco Civil da Internet
- **Lei 13.709/18** — LGPD (dados do usuário)
- **Lei 9.605/98** — Art. 184 do Código Penal (violação de direito autoral)

### 3.2 Responsabilidade do Desenvolvedor

Segundo o **Marco Civil da Internet (Art. 18 e 19)**:

> "O provedor de conexão à internet não será responsabilizado civilmente por
> danos decorrentes de conteúdo gerado por terceiros."

Embora o DENDÊPLAY não seja exatamente um "provedor de conexão", o princípio
de que intermediários não são responsáveis pelo conteúdo de terceiros pode
ser aplicável por analogia.

---

## PARTE 4 — ESTRATÉGIAS PARA PLAY STORE

### Estratégia A — Publicar como "Media Player" (Baixo Risco de Bloqueio)

**Como funcionar:**
- Descreva o app como "reprodutor de mídia que aceita URLs"
- NÃO mencione sites de anime ou filmes na descrição
- Remova os providers pré-configurados do build da Play Store
- Permita que usuários adicionem URLs manualmente (como VLC)
- Use o nome neutro, sem referência a conteúdo

**Resultado esperado:** Aprovação provável, funcionalidade reduzida

---

### Estratégia B — Publicar via Google Play para Apps Fechados

**Como funcionar:**
- Use **Google Play** com perfil de desenvolvedor *testador*
- Distribua apenas via **teste interno** (Internal Testing Track)
- Até 100 testadores sem revisão pública completa
- Não fica listado publicamente

**Vantagem:** Sem revisão pública, sem denúncias de terceiros
**Desvantagem:** Limitado a 100 usuários

---

### Estratégia C — Sideload Direto via GitHub Releases (RECOMENDADO)

**Como funcionar:**
- Distribua via **GitHub Releases** (como já está configurado no CI/CD)
- APK assinado disponível gratuitamente
- Usuários baixam e instalam manualmente (sideload)
- Sem intermediário do Google

**Vantagens:**
- Zero risco de ban pelo Google
- Controle total da distribuição
- Não viola políticas de nenhuma plataforma
- Repositório pode ser privado (código protegido)

**Desvantagens:**
- Menor alcance (menos descoberta orgânica)
- Usuários precisam habilitar "Fontes Desconhecidas"

---

### Estratégia D — Amazon Appstore / Aptoide / F-Droid

**Alternativas à Play Store:**

| Loja | Curadoria | Facilidade |
|------|-----------|------------|
| **Amazon Appstore** | Moderada | Fácil |
| **Aptoide** | Mínima | Muito fácil |
| **APKPure** | Mínima | Muito fácil |
| **F-Droid** | Alta (open source) | Complexa |
| **Samsung Galaxy Store** | Moderada | Médio |

A **Amazon Appstore** tem políticas mais permissivas que o Google Play e
aceita apps de reprodução de mídia sem scraping visível.

---

### Estratégia E — PWA (Progressive Web App)

**Pensando fora da caixa:**

Converter o DENDÊPLAY em um PWA (site instalável como app):

- Hospede o frontend em Vercel/Netlify
- Backend Go em servidor privado ou VPS
- Usuários instalam via "Adicionar à tela inicial" no Chrome
- **Zero risco de ban** — não está em nenhuma loja
- Funciona em Android, iOS e Desktop

**Limitações:** Cast e algumas funcionalidades nativas são restritas em PWA.

---

## PARTE 5 — PROTEÇÃO CONTRA ROUBO DO PROJETO

### 5.1 Proteções Técnicas

| Medida | Efetividade |
|--------|-------------|
| ProGuard/R8 obfuscação | Alta — dificulta engenharia reversa |
| Validação de assinatura APK | Média — detecta modificações |
| Certificado SSL pinning nas APIs | Alta — previne interceptação |
| Repositório privado | Alta — código não exposto |
| Remover URLs em runtime | Alta — strings não ficam no APK |

### 5.2 Proteções Legais

1. **Registre o nome "DENDÊPLAY"** como marca no INPI (Instituto Nacional
   de Propriedade Industrial). Custo: ~R$ 355 por classe.
   Link: inpi.gov.br

2. **Licença clara no código** — a LICENSE_DENDEPLAY já proíbe uso comercial.

3. **Repositório privado** no GitHub — não exponha o código fonte completo.

4. **Controle de versão + timestamps** — commits datados provam autoria original.

### 5.3 Se alguém copiar seu app

**Opções legais:**
- Notificação DMCA para a plataforma (GitHub, Play Store, etc.)
- Ação de infração de marca (se registrada no INPI)
- Ação de concorrência desleal (Lei 9.279/96, Art. 195)
- Notificação extrajudicial via carta registrada

---

## PARTE 6 — ESTRATÉGIA RECOMENDADA

### Para uso pessoal e comunidade:

```
GITHUB RELEASES + SIDELOAD
         ↓
Máximo controle, zero risco de ban,
APK assinado, CI/CD automático
```

### Se quiser alcance maior:

```
AMAZON APPSTORE
    ↓
Menos burocracia, políticas mais permissivas,
boa cobertura no Brasil
```

### Se quiser Play Store a qualquer custo:

```
1. Crie conta de desenvolvedor separada (R$ 100 taxa única)
2. Publique como "Media Player"
3. Remova os providers pré-configurados
4. Aceite que pode ser removido a qualquer momento
5. Mantenha backup via GitHub Releases
```

---

## PARTE 7 — AVISO LEGAL

Este documento é uma análise de boas práticas e estratégias, não constitui
aconselhamento jurídico formal. Para decisões legais relevantes, consulte
um advogado especializado em direito digital ou propriedade intelectual.

---

*Documento produzido para uso interno.*
*DENDÊPLAY © 2026 Mateus "TinkWink"*
*Análise baseada na legislação brasileira vigente em 2026.*
