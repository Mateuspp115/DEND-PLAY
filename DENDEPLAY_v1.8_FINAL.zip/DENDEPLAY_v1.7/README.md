# DENDÊPLAY v1.6.0

App Android de streaming de animes, filmes e series em PT-BR.
Go SDK com 26 providers. Cast avancado para 6 plataformas de TV.

> Para documentacao completa, consulte: **PROJECT_STATUS.md**

---

## Build rapido

```bash
cd sdk && gomobile bind -target=android/arm64,android/arm,android/amd64 \
  -androidapi=26 -o ../app/libs/dendeplay_sdk.aar .
cd .. && ./gradlew assembleDebug
```

CI/CD: push para `main` gera APK debug. Tag `v*` gera release assinado.

---

## 26 Providers

**Anime PT-BR (12):** AnimeFire · GoAnimes · AniTube · AnimesOnline · HinataSoul · AnimesHouse · Goyabu · AnimeKing · AnimesDigital · BetterAnime · AnimesOrion · AnimesZone

**Filmes/Series PT-BR (9):** Pobreflix · TopFlix · MegaFlix · SuperFlix · Tugaflix · MegaFilmesHD · DoFlix · RedeCanais · MaxFilmes

**Universal EN (5):** AllAnime · FlixHQ · AnimeKisa · Gogoanime · 9Anime

---

## Cast: 6 plataformas

Chromecast · Samsung Tizen (2016–2024+) · LG webOS · Roku TV · Android TV · DLNA

---

Android 8.0+ (API 26) | arm64, armv7, x86_64 | Testado: Moto G35

DENDEPLAY (c) 2026 Mateus "TinkWink" | GoAnime (c) 2023 Krone — MIT License
