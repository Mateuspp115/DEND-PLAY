# 🔥 DENDÊPLAY — Setup Completo

## ⚡ Build em 3 passos (local)

### 1. Baixar gradle-wrapper.jar (apenas na primeira vez)
```bash
# Dentro da pasta do projeto:
wget -q "https://raw.githubusercontent.com/gradle/gradle/v8.4.0/gradle/wrapper/gradle-wrapper.jar" \
  -O gradle/wrapper/gradle-wrapper.jar
# Verificar que não está vazio (deve ser ~64KB):
wc -c gradle/wrapper/gradle-wrapper.jar
```

### 2. Compilar o SDK Go → AAR
```bash
cd sdk
go mod download
go install golang.org/x/mobile/cmd/gomobile@latest
go install golang.org/x/mobile/cmd/gobind@latest
gomobile init
gomobile bind \
  -target=android/arm64,android/arm,android/amd64 \
  -androidapi=26 -trimpath \
  -o ../app/libs/dendeplay_sdk.aar .
cd ..
```

### 3. Compilar o APK
```bash
chmod +x gradlew
./gradlew assembleDebug   # APK debug
./gradlew assembleRelease # APK release
```

---

## 🚀 Build via GitHub Actions (recomendado)

1. **Fork** ou clone o repositório no GitHub
2. Faça um **push para `main`** → APK debug gerado automaticamente
3. Crie uma **tag `v1.1.0`** → APK release assinado + GitHub Release publicado

---

## 🔑 Secrets para APK assinado

| Secret | Como obter |
|--------|-----------|
| `KEYSTORE_BASE64` | `base64 -w 0 dendeplay.jks` |
| `KEY_ALIAS` | Alias usado ao criar o keystore |
| `KEYSTORE_PASSWORD` | Senha do keystore |
| `KEY_PASSWORD` | Senha da chave |

```bash
# Gerar keystore:
keytool -genkey -v -keystore dendeplay.jks -alias dendeplay \
  -keyalg RSA -keysize 2048 -validity 10000
# Exportar base64:
base64 -w 0 dendeplay.jks > dendeplay.jks.b64
```

---

## 📦 Sem SDK Go (modo dev rápido)

O `AppModule.kt` inclui um **stub** do SDK que permite compilar e rodar
o app sem o AAR do Go. As buscas retornarão listas vazias, mas toda a
UI funcionará normalmente para testes de layout.

Para ativar o SDK real, edite `AppModule.kt` seguindo as instruções nos comentários.
