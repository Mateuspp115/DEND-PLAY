package com.dendeplay.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val DendeTypography = Typography(
    displayLarge  = TextStyle(fontWeight = FontWeight.Black,     fontSize = 40.sp, letterSpacing = 5.sp),
    displayMedium = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, letterSpacing = 3.sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold,      fontSize = 22.sp),
    headlineMedium= TextStyle(fontWeight = FontWeight.SemiBold,  fontSize = 18.sp),
    titleLarge    = TextStyle(fontWeight = FontWeight.Bold,      fontSize = 16.sp),
    titleMedium   = TextStyle(fontWeight = FontWeight.Medium,    fontSize = 14.sp),
    bodyLarge     = TextStyle(fontWeight = FontWeight.Normal,    fontSize = 16.sp),
    bodyMedium    = TextStyle(fontWeight = FontWeight.Normal,    fontSize = 14.sp),
    labelLarge    = TextStyle(fontWeight = FontWeight.Medium,    fontSize = 13.sp, letterSpacing = 0.5.sp),
    labelSmall    = TextStyle(fontWeight = FontWeight.Medium,    fontSize = 10.sp, letterSpacing = 0.5.sp),
)
