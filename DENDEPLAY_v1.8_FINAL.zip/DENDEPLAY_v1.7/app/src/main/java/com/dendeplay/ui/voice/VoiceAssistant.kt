package com.dendeplay.ui.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import com.dendeplay.ui.theme.DendeColors

enum class PlayerCommand { NEXT, PREV, PAUSE, PLAY, SEEK_FWD, SEEK_BWD, SUBTITLE, RADIO, UNKNOWN }

class VoiceAssistant(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private var onCommand: ((PlayerCommand, String)->Unit)? = null

    fun init(cb: (PlayerCommand, String)->Unit) {
        onCommand = cb
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: return
                onCommand?.invoke(parse(text), text)
            }
            override fun onError(e: Int) {}
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
    }

    fun startListening() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(i)
    }

    fun stopListening() { recognizer?.stopListening() }
    fun destroy() { recognizer?.destroy(); recognizer = null }

    private fun parse(t: String) = when {
        t.contains("próximo")||t.contains("next")       -> PlayerCommand.NEXT
        t.contains("anterior")||t.contains("volta")     -> PlayerCommand.PREV
        t.contains("pausar")||t.contains("pausa")       -> PlayerCommand.PAUSE
        t.contains("continuar")||t.contains("play")     -> PlayerCommand.PLAY
        t.contains("avançar")||t.contains("pular")      -> PlayerCommand.SEEK_FWD
        t.contains("voltar")||t.contains("retroceder")  -> PlayerCommand.SEEK_BWD
        t.contains("legenda")                           -> PlayerCommand.SUBTITLE
        t.contains("rádio")||t.contains("radio")        -> PlayerCommand.RADIO
        else                                            -> PlayerCommand.UNKNOWN
    }
}

@Composable
fun VoiceAssistantUI(
    visible: Boolean, isListening: Boolean, lastCommand: String,
    onStart: ()->Unit, onStop: ()->Unit, onDismiss: ()->Unit,
) {
    AnimatedVisibility(visible, enter=slideInVertically{it}+fadeIn(), exit=slideOutVertically{it}+fadeOut()) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(.75f)).clickable(onClick=onDismiss), Alignment.BottomCenter) {
            Card(Modifier.fillMaxWidth().padding(16.dp), RoundedCornerShape(20.dp), CardDefaults.cardColors(DendeColors.Surface)) {
                Column(Modifier.padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Assistente de Voz",color=DendeColors.Text,fontSize=18.sp,fontWeight=FontWeight.Black)
                    Text("Comandos offline",color=DendeColors.TextSub,fontSize=12.sp)
                    Spacer(Modifier.height(22.dp))
                    // Mic button
                    val inf = rememberInfiniteTransition(label="mic")
                    val pulse by inf.animateFloat(.85f,1.15f,infiniteRepeatable(tween(700),RepeatMode.Reverse),label="mp")
                    Box(contentAlignment=Alignment.Center) {
                        if(isListening) Box(Modifier.size(120.dp).scale(pulse).background(DendeColors.Error.copy(.08f),CircleShape))
                        Box(Modifier.size(72.dp).background(if(isListening) Brush.radialGradient(listOf(DendeColors.Error,DendeColors.Error.copy(.7f)))
                            else Brush.radialGradient(listOf(DendeColors.Primary,DendeColors.Secondary)), CircleShape)
                            .clickable{if(isListening) onStop() else onStart()}, Alignment.Center) {
                            Icon(if(isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,null,tint=Color.Black,modifier=Modifier.size(34.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(if(isListening)"Ouvindo…" else "Toque para falar",color=if(isListening) DendeColors.Error else DendeColors.TextSub,fontSize=12.sp)
                    if(lastCommand.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.background(DendeColors.Primary.copy(.12f),RoundedCornerShape(8.dp)).padding(horizontal=12.dp,vertical=8.dp),
                            Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                            Icon(Icons.Rounded.RecordVoiceOver,null,tint=DendeColors.Primary,modifier=Modifier.size(15.dp))
                            Text("\"$lastCommand\"",color=DendeColors.Primary,fontSize=13.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    // Hints
                    val cmds = listOf("Pausar","Continuar","Próximo episódio","Avançar 30s","Modo rádio","Legenda")
                    val pairs = cmds.chunked(2)
                    pairs.forEach { pair ->
                        Row(Modifier.fillMaxWidth().padding(vertical=2.dp), Arrangement.spacedBy(8.dp)) {
                            pair.forEach { cmd ->
                                Box(Modifier.weight(1f).background(DendeColors.SurfaceVar,RoundedCornerShape(8.dp)).padding(horizontal=10.dp,vertical=7.dp)) {
                                    Text(cmd,color=DendeColors.TextSub,fontSize=10.5.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Wrapper de tela completa para navegação
@Composable
fun VoiceAssistantScreen(onBack: () -> Unit) {
    var isListening  by remember { mutableStateOf(false) }
    var lastCommand  by remember { mutableStateOf("") }
    var permDenied   by remember { mutableStateOf(false) }
    val ctx          = LocalContext.current

    // Cria e inicializa o VoiceAssistant com lifecycle correto
    val assistant = remember {
        VoiceAssistant(ctx).also { va ->
            va.init { _, text -> lastCommand = text }
        }
    }
    DisposableEffect(Unit) {
        onDispose { assistant.destroy() }
    }

    // Launcher de permissão RECORD_AUDIO
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            assistant.startListening()
            isListening = true
        } else {
            permDenied = true
        }
    }

    fun startListeningWithPermission() {
        when {
            ContextCompat.checkSelfPermission(
                ctx, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> {
                assistant.startListening()
                isListening = true
            }
            else -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Box(Modifier.fillMaxSize().background(DendeColors.Background)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp)) {
                IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "Voltar", tint=DendeColors.Text) }
                Text("Assistente de Voz", color=DendeColors.Text, fontSize=18.sp,
                    fontWeight=FontWeight.Bold,
                    modifier=Modifier.align(Alignment.CenterVertically).padding(start=8.dp))
            }
        }

        if (permDenied) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(Icons.Rounded.MicOff, null, tint=DendeColors.Error, modifier=Modifier.size(52.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Permissão de microfone negada", color=DendeColors.Text, fontSize=16.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Habilite nas configurações do sistema para usar o assistente de voz.",
                        color=DendeColors.TextSub, fontSize=13.sp, textAlign=TextAlign.Center)
                }
            }
        } else {
            VoiceAssistantUI(
                visible     = true,
                isListening = isListening,
                lastCommand = lastCommand,
                onStart     = { startListeningWithPermission() },
                onStop      = { assistant.stopListening(); isListening = false },
                onDismiss   = onBack,
            )
        }
    }
}

