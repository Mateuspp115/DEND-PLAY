package com.dendeplay.ui.search

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dendeplay.domain.model.SearchResult
import com.dendeplay.ui.components.DendeLoadingIndicator
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.components.shimmerBrush
import com.dendeplay.ui.theme.DendeColors

@Composable
fun SearchScreen(onMediaClick: (SearchResult)->Unit, onBack: ()->Unit, vm: SearchViewModel = hiltViewModel()) {
    val query  by vm.query.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val state  by vm.state.collectAsStateWithLifecycle()
    val fm = LocalFocusManager.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { fr.requestFocus() }

    Column(Modifier.fillMaxSize().background(DendeColors.Background).statusBarsPadding()) {
        // Search bar
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=10.dp),
            Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null, tint=DendeColors.Text) }
            OutlinedTextField(
                value=query, onValueChange=vm::onQueryChange,
                modifier=Modifier.weight(1f).focusRequester(fr),
                placeholder={ Text("Buscar anime, filme, série…", color=DendeColors.TextHint, fontSize=14.sp) },
                leadingIcon={ Icon(Icons.Rounded.Search, null, tint=DendeColors.TextSub, modifier=Modifier.size(20.dp)) },
                trailingIcon={ if(query.isNotEmpty()) IconButton({vm.onQueryChange("")}){Icon(Icons.Rounded.Close, null, tint=DendeColors.TextSub, modifier=Modifier.size(18.dp))} },
                singleLine=true, shape=RoundedCornerShape(14.dp),
                colors=OutlinedTextFieldDefaults.colors(
                    focusedBorderColor=DendeColors.Primary, unfocusedBorderColor=DendeColors.SurfaceVar,
                    focusedTextColor=DendeColors.Text, unfocusedTextColor=DendeColors.Text,
                    cursorColor=DendeColors.Primary, focusedContainerColor=DendeColors.Card, unfocusedContainerColor=DendeColors.Card),
                keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),
                keyboardActions=KeyboardActions(onSearch={fm.clearFocus();vm.search()})
            )
        }
        // Filtros
        LazyRow(contentPadding=PaddingValues(horizontal=12.dp,vertical=4.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            val filters = listOf("todos" to "Todos","anime" to "Anime","movie" to "Filmes","tv" to "Séries")
            items(filters) { (k,v) ->
                FilterChip(selected=filter==k, onClick={vm.setFilter(k)}, label={Text(v,fontSize=12.sp)},
                    shape=RoundedCornerShape(20.dp),
                    colors=FilterChipDefaults.filterChipColors(
                        selectedContainerColor=DendeColors.Primary, selectedLabelColor=Color.Black,
                        containerColor=DendeColors.Card, labelColor=DendeColors.TextSub),
                    border=FilterChipDefaults.filterChipBorder(enabled=true,selected=filter==k,
                        selectedBorderColor=DendeColors.Primary, borderColor=DendeColors.SurfaceVar))
            }
        }
        // Conteúdo
        when(val s = state) {
            is SearchUiState.Idle    -> SearchSuggestions(vm::onQueryChange)
            is SearchUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { DendeLoadingIndicator() }
            is SearchUiState.Empty   -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.SearchOff, null, tint=DendeColors.TextSub, modifier=Modifier.size(52.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Nenhum resultado para", color=DendeColors.TextSub, fontSize=14.sp)
                    Text("\"$query\"", color=DendeColors.Text, fontSize=16.sp, fontWeight=FontWeight.Bold)
                }
            }
            is SearchUiState.Error   -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Warning, null, tint=DendeColors.FlameOrange, modifier=Modifier.size(48.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(s.message, color=DendeColors.TextSub)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick=vm::search, colors=ButtonDefaults.buttonColors(DendeColors.Primary)){Text("Tentar novamente",color=Color.Black)}
                }
            }
            is SearchUiState.Results ->
                LazyVerticalGrid(GridCells.Fixed(3), contentPadding=PaddingValues(12.dp),
                    horizontalArrangement=Arrangement.spacedBy(8.dp), verticalArrangement=Arrangement.spacedBy(12.dp),
                    modifier=Modifier.fillMaxSize()) {
                    items(s.items, key={it.provider+":"+it.id}) { item ->
                        Column(Modifier.fillMaxWidth().dendeClickable{onMediaClick(item)}) {
                            Box(Modifier.fillMaxWidth().aspectRatio(.7f).clip(RoundedCornerShape(10.dp)).background(DendeColors.Card)) {
                                AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                                Box(Modifier.align(Alignment.TopEnd).padding(4.dp)
                                    .background(DendeColors.Surface.copy(.85f),RoundedCornerShape(4.dp)).padding(horizontal=4.dp,vertical=2.dp)) {
                                    Icon(when(item.mediaType){"movie"->Icons.Rounded.Movie;"tv"->Icons.Rounded.Tv;else->Icons.Rounded.Animation}, contentDescription=null, tint=DendeColors.TextSub, modifier=Modifier.size(10.dp))
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(item.title, color=DendeColors.Text, fontSize=10.5.sp, fontWeight=FontWeight.Medium, maxLines=2, overflow=TextOverflow.Ellipsis, lineHeight=13.sp)
                            if(item.year.isNotEmpty()) Text(item.year, color=DendeColors.TextSub, fontSize=9.5.sp)
                        }
                    }
                }
        }
    }
}

@Composable
private fun SearchSuggestions(onSugg: (String)->Unit) {
    val suggestions = listOf("Naruto","One Piece","Dragon Ball Z","Demon Slayer","Attack on Titan",
        "Jujutsu Kaisen","Hunter x Hunter","Fullmetal Alchemist","Bleach","Tokyo Ghoul","Death Note","Sword Art Online")
    Column(Modifier.fillMaxSize().padding(horizontal=14.dp, vertical=8.dp)) {
        Text("Populares", color=DendeColors.TextSub, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp, modifier=Modifier.padding(bottom=12.dp))
        LazyVerticalGrid(GridCells.Fixed(2), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(suggestions) { s ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(DendeColors.Card).dendeClickable{onSugg(s)}.padding(horizontal=12.dp,vertical=10.dp),
                    Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                    Icon(Icons.Rounded.TrendingUp, null, tint=DendeColors.Primary, modifier=Modifier.size(14.dp))
                    Text(s, color=DendeColors.Text, fontSize=12.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                }
            }
        }
    }
}
