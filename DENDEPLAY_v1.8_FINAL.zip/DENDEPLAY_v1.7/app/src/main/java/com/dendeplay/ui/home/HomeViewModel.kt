package com.dendeplay.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.SearchResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

sealed class HomeUiState {
    object Loading : HomeUiState()
    data class Success(
        val trending:         List<SearchResult> = emptyList(),
        val newEpisodes:      List<SearchResult> = emptyList(),
        val continueWatching: List<SearchResult> = emptyList(),
        val recentlyAdded:    List<SearchResult> = emptyList(),
        val recommended:      List<SearchResult> = emptyList(),
        val ultraHD:          List<SearchResult> = emptyList(),  // 4K/UHD
        val films:            List<SearchResult> = emptyList(),  // Filmes em destaque
        val series:           List<SearchResult> = emptyList(),  // Series em destaque
        val animes:           List<SearchResult> = emptyList(),  // Animes em destaque
    ) : HomeUiState()
    data class Error(val message: String) : HomeUiState()
}

@HiltViewModel
class HomeViewModel @Inject constructor(private val repo: MediaRepository) : ViewModel() {
    private val _state = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    private var loadJob: Job? = null

    init { load() }

    fun retry() { _state.value = HomeUiState.Loading; load() }

    private fun load() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            try {
                val a = async { withTimeoutOrNull(10_000) { repo.getTrending("anime").getOrElse { emptyList() } } ?: emptyList() }
                val b = async { withTimeoutOrNull(10_000) { repo.getLatestEpisodes().getOrElse { emptyList() } } ?: emptyList() }
                val c = async { withTimeoutOrNull(10_000) { repo.getContinueWatching().getOrElse { emptyList() } } ?: emptyList() }
                val d = async { withTimeoutOrNull(10_000) { repo.getRecentlyAdded().getOrElse { emptyList() } } ?: emptyList() }
                val e = async { withTimeoutOrNull(10_000) { repo.getRecommended().getOrElse { emptyList() } } ?: emptyList() }
                // Seções novas em paralelo — timeout menor pois são secundárias
                val f = async { withTimeoutOrNull(8_000) { repo.searchByType("4k ultra hd", "movie").getOrElse { emptyList() } } ?: emptyList() }
                val g = async { withTimeoutOrNull(8_000) { repo.searchByType("filmes", "movie").getOrElse { emptyList() } } ?: emptyList() }
                val h = async { withTimeoutOrNull(8_000) { repo.searchByType("series", "tv").getOrElse { emptyList() } } ?: emptyList() }
                val i = async { withTimeoutOrNull(8_000) { repo.searchByType("anime", "anime").getOrElse { emptyList() } } ?: emptyList() }

                _state.value = HomeUiState.Success(
                    trending         = a.await(),
                    newEpisodes      = b.await(),
                    continueWatching = c.await(),
                    recentlyAdded    = d.await(),
                    recommended      = e.await(),
                    ultraHD          = f.await(),
                    films            = g.await(),
                    series           = h.await(),
                    animes           = i.await(),
                )
            } catch (ex: Exception) {
                if (ex is CancellationException) throw ex
                _state.value = HomeUiState.Error(ex.message ?: "Erro ao carregar")
            }
        }
    }
}
