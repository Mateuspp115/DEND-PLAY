package com.dendeplay.ui.downloads

import android.content.Intent
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.dendeplay.domain.model.DownloadItem
import com.dendeplay.ui.player.PlayerActivity
import com.dendeplay.ui.theme.DendeColors

@Composable
fun DownloadsScreen(vm: DownloadsViewModel = hiltViewModel()) {
    val downloads   by vm.downloads.collectAsStateWithLifecycle()
    val storageUsed by vm.storageUsed.collectAsStateWithLifecycle()
    val context     = LocalContext.current

    Column(Modifier.fillMaxSize().background(DendeColors.Background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=14.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Downloads", color=DendeColors.Text, fontSize=22.sp, fontWeight=FontWeight.Black)
            Text(storageUsed, color=DendeColors.TextSub, fontSize=12.sp)
        }
        if(downloads.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.padding(32.dp)) {
                Icon(Icons.Rounded.Download, null, tint=DendeColors.SurfaceVar, modifier=Modifier.size(56.dp))
                Spacer(Modifier.height(14.dp))
                Text("Nenhum download ainda", color=DendeColors.Text, fontSize=17.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Baixe episódios para assistir sem internet", color=DendeColors.TextSub, fontSize=13.sp)
            }
        } else LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(downloads, key={it.id}) { item ->
                DownloadCard(
                    item      = item,
                    onPause   = { vm.pause(item.id) },
                    onResume  = { vm.resume(item.id) },
                    onCancel  = { vm.cancel(item.id) },
                    onPlayOffline = { filePath ->
                        // Abre o PlayerActivity com o arquivo local
                        context.startActivity(
                            Intent(context, PlayerActivity::class.java).apply {
                                putExtra(PlayerActivity.EXTRA_EPISODE_URL, "file://$filePath")
                                putExtra(PlayerActivity.EXTRA_TITLE,       item.title)
                                putExtra(PlayerActivity.EXTRA_EPISODE_NUM, item.episode)
                                putExtra(PlayerActivity.EXTRA_MEDIA_ID,    item.mediaId)
                                putExtra(PlayerActivity.EXTRA_PROVIDER,    "local")
                                putExtra(PlayerActivity.EXTRA_MEDIA_TYPE,  "anime")
                            }
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun DownloadCard(
    item:         DownloadItem,
    onPause:      () -> Unit,
    onResume:     () -> Unit,
    onCancel:     () -> Unit,
    onPlayOffline: (String) -> Unit,
) {
    val sc = when(item.status){"completed"->Color(0xFF4CAF50); "active"->DendeColors.Primary; "failed"->DendeColors.Error; else->DendeColors.TextSub}
    Card(Modifier.fillMaxWidth(), RoundedCornerShape(12.dp), CardDefaults.cardColors(DendeColors.Card)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.title, color=DendeColors.Text, fontSize=14.sp, fontWeight=FontWeight.Bold, maxLines=1, overflow=TextOverflow.Ellipsis)
                    Text("Episódio ${item.episode}", color=DendeColors.TextSub, fontSize=11.sp)
                }
                Box(Modifier.background(sc.copy(.16f),RoundedCornerShape(6.dp)).padding(horizontal=8.dp,vertical=4.dp)) {
                    Text(when(item.status){"completed"->"Concluído";"active"->"Baixando";"paused"->"Pausado";"failed"->"Falhou";else->item.status},
                        color=sc, fontSize=10.sp, fontWeight=FontWeight.Bold)
                }
            }
            if(item.status!="completed") {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("${item.progress}%", color=DendeColors.Primary, fontSize=11.sp, fontWeight=FontWeight.Bold)
                    Text(buildString{if(item.speed.isNotEmpty())append(item.speed); if(item.eta.isNotEmpty())append(" • ${item.eta}")}, color=DendeColors.TextSub, fontSize=10.sp)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(progress={item.progress/100f}, modifier=Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                    color=DendeColors.Primary, trackColor=DendeColors.SurfaceVar)
            } else {
                Spacer(Modifier.height(4.dp))
                Text("${item.fileSize/1024/1024} MB", color=DendeColors.TextHint, fontSize=10.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                when(item.status) {
                    "completed" -> Button(
                        onClick  = { if(item.filePath.isNotEmpty()) onPlayOffline(item.filePath) },
                        modifier = Modifier.weight(1f),
                        shape    = RoundedCornerShape(8.dp),
                        colors   = ButtonDefaults.buttonColors(DendeColors.Primary)
                    ) {
                        Icon(Icons.Rounded.PlayArrow,null,modifier=Modifier.size(16.dp),tint=Color.Black)
                        Spacer(Modifier.width(4.dp))
                        Text("Assistir Offline",color=Color.Black,fontSize=12.sp)
                    }
                    "active"    -> {
                        OutlinedButton(onClick=onPause, modifier=Modifier.weight(1f), shape=RoundedCornerShape(8.dp), border=BorderStroke(1.dp,DendeColors.SurfaceVar), colors=ButtonDefaults.outlinedButtonColors(contentColor=DendeColors.Text)){
                            Icon(Icons.Rounded.Pause,null,modifier=Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Pausar",fontSize=12.sp) }
                        IconButton(onClick=onCancel){Icon(Icons.Rounded.Close,null,tint=DendeColors.TextHint,modifier=Modifier.size(20.dp))} }
                    else        -> {
                        Button(onClick=onResume, modifier=Modifier.weight(1f), shape=RoundedCornerShape(8.dp), colors=ButtonDefaults.buttonColors(DendeColors.Primary)){
                            Icon(Icons.Rounded.PlayArrow,null,modifier=Modifier.size(16.dp),tint=Color.Black); Spacer(Modifier.width(4.dp)); Text("Retomar",color=Color.Black,fontSize=12.sp) }
                        IconButton(onClick=onCancel){Icon(Icons.Rounded.Delete,null,tint=DendeColors.TextHint,modifier=Modifier.size(20.dp))} }
                }
            }
        }
    }
}
