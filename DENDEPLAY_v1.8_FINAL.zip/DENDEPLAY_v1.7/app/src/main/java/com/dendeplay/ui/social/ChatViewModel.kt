package com.dendeplay.ui.social

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

// ══════════════════════════════════════════════════════════
// ChatViewModel — chat por série/anime
//
// Armazenamento: SharedPreferences local (por enquanto).
// Quando servidor estiver disponível: substituir por API calls.
//
// Mensagens são organizadas por mediaId — cada série/anime
// tem seu próprio canal de discussão.
// ══════════════════════════════════════════════════════════

data class ChatMessage(
    val id:         String  = UUID.randomUUID().toString(),
    val mediaId:    String  = "",
    val userId:     String  = "",
    val userName:   String  = "",
    val text:       String  = "",
    val timestamp:  Long    = System.currentTimeMillis(),
    val likes:      Int     = 0,
    val likedByMe:  Boolean = false,
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val gson: Gson,
) : ViewModel() {

    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("dendeplay_chat", Context.MODE_PRIVATE)

    private val _messages     = MutableStateFlow<List<ChatMessage>>(emptyList())
    private val _userDisplay  = MutableStateFlow(getDisplayName())

    val messages:    StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    val userDisplay: StateFlow<String>            = _userDisplay.asStateFlow()
    val currentUserId: String                     get() = getUserId()

    fun load(mediaId: String) {
        viewModelScope.launch {
            val saved = loadMessages(mediaId)
            _messages.value = saved.sortedBy { it.timestamp }
        }
    }

    fun send(mediaId: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val msg = ChatMessage(
                mediaId   = mediaId,
                userId    = getUserId(),
                userName  = getDisplayName(),
                text      = text.trim(),
            )
            val updated = (_messages.value + msg).sortedBy { it.timestamp }
            _messages.value = updated
            saveMessages(mediaId, updated)
        }
    }

    fun like(messageId: String) {
        viewModelScope.launch {
            val myId   = getUserId()
            val likedSet = getLikedSet().toMutableSet()
            val updated = _messages.value.map { msg ->
                if (msg.id == messageId) {
                    val alreadyLiked = messageId in likedSet
                    if (alreadyLiked) {
                        likedSet.remove(messageId)
                        msg.copy(likes = (msg.likes - 1).coerceAtLeast(0), likedByMe = false)
                    } else {
                        likedSet.add(messageId)
                        msg.copy(likes = msg.likes + 1, likedByMe = true)
                    }
                } else msg
            }
            saveLikedSet(likedSet)
            _messages.value = updated
            _messages.value.firstOrNull()?.mediaId?.let { mid ->
                saveMessages(mid, updated)
            }
        }
    }

    fun setDisplayName(name: String) {
        prefs.edit().putString("display_name", name.trim().take(30)).apply()
        _userDisplay.value = name.trim().take(30)
    }

    // ── Persistência ──────────────────────────────────────

    private fun loadMessages(mediaId: String): List<ChatMessage> {
        val json = prefs.getString("chat_$mediaId", null) ?: return emptyList()
        return runCatching {
            gson.fromJson<List<ChatMessage>>(json, object : TypeToken<List<ChatMessage>>(){}.type)
                ?: emptyList()
        }.getOrElse { emptyList() }
    }

    private fun saveMessages(mediaId: String, messages: List<ChatMessage>) {
        prefs.edit().putString("chat_$mediaId", gson.toJson(messages.takeLast(200))).apply()
    }

    private fun getUserId(): String {
        var id = prefs.getString("user_id", null)
        if (id == null) {
            id = "user_" + java.util.UUID.randomUUID().toString().take(8)
            prefs.edit().putString("user_id", id).apply()
        }
        return id
    }

    private fun getDisplayName(): String =
        prefs.getString("display_name", null) ?: "Usuario_${getUserId().takeLast(4)}"

    private fun getLikedSet(): Set<String> {
        val json = prefs.getString("liked_messages", null) ?: return emptySet()
        return runCatching {
            gson.fromJson<Set<String>>(json, object : TypeToken<Set<String>>(){}.type) ?: emptySet()
        }.getOrElse { emptySet() }
    }

    private fun saveLikedSet(set: Set<String>) {
        prefs.edit().putString("liked_messages", gson.toJson(set)).apply()
    }
}
