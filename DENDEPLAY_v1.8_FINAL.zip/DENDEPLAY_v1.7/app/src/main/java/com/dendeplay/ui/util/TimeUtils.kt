package com.dendeplay.ui.util

/**
 * Formata milissegundos para string de tempo legível.
 * Exemplos: 3_661_000ms → "1:01:01" | 125_000ms → "02:05"
 */
fun fmtMs(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
