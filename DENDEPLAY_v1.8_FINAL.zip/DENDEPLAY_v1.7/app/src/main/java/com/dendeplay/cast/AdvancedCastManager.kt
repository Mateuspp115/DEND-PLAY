package com.dendeplay.cast

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.util.Log
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.*
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.gms.common.images.WebImage
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.*
import java.net.*
import com.dendeplay.cast.platform.AndroidTVManager
import com.dendeplay.cast.platform.DLNAManager
import com.dendeplay.cast.platform.LGWebOSManager
import com.dendeplay.cast.platform.RokuManager
import com.dendeplay.cast.platform.SamsungTizenManager
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════
// Tipos de dispositivos suportados
// ══════════════════════════════════════════════════════════

enum class CastType {
    CHROMECAST,    // Google Cast SDK
    DLNA,          // UPnP/SSDP — LG/Samsung/Sony antigos
    SAMSUNG_TIZEN, // Samsung Smart TV moderna
    LG_WEBOS,      // LG Smart TV webOS
    ROKU,          // Roku TV (ECP)
    ANDROID_TV,    // Android TV / Google TV
}

data class CastDevice(
    val id:             String,
    val name:           String,
    val type:           CastType,
    val address:        String   = "",
    val port:           Int      = 0,
    val manufacturer:   String   = "",
    val model:          String   = "",
    val latencyMs:      Int      = 0,
    val signalStrength: Int      = 0,   // 0-100
    val isAvailable:    Boolean  = true,
)

data class CastPlaybackState(
    val isConnected:    Boolean  = false,
    val deviceName:     String   = "",
    val deviceType:     CastType? = null,
    val isPlaying:      Boolean  = false,
    val position:       Long     = 0L,
    val duration:       Long     = 0L,
    val volume:         Float    = 1f,
    val speed:          Float    = 1f,
    val currentTitle:   String   = "",
    val currentThumb:   String   = "",
    val isPowerSaveOff: Boolean  = false,
    val subtitleTrack:  String   = "",
    val audioTrack:     String   = "",
)

interface CastCallback {
    fun onConnected(device: CastDevice)
    fun onDisconnected()
    fun onError(message: String)
    fun onPlaybackStateChanged(state: CastPlaybackState)
}

// ══════════════════════════════════════════════════════════
// AdvancedCastManager — orquestrador central
// Nível Web Video Cast: descobre, conecta e controla
// qualquer TV na rede local em < 2 segundos
// ══════════════════════════════════════════════════════════

@Singleton
class AdvancedCastManager @Inject constructor(
    private val context: Context
) {
    private val TAG = "AdvancedCast"

    private val _devices    = MutableStateFlow<List<CastDevice>>(emptyList())
    private val _state      = MutableStateFlow(CastPlaybackState())
    private val _discovering = MutableStateFlow(false)
    private val scope        = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val devices:     StateFlow<List<CastDevice>>    = _devices.asStateFlow()
    val state:       StateFlow<CastPlaybackState>   = _state.asStateFlow()
    val discovering: StateFlow<Boolean>             = _discovering.asStateFlow()

    // Platform managers
    private val roku       = RokuManager(context)
    private val samsung    = SamsungTizenManager(context)
    private val lg         = LGWebOSManager(context)
    private val androidTv  = AndroidTVManager(context)
    private val dlna       = DLNAManager(context)

    // Chromecast
    private var sessionMgr:    SessionManager?    = null
    private var remoteClient:  RemoteMediaClient? = null
    private var nsdManager:    NsdManager?        = null

    // WakeLock (mantém tela/CPU ativa durante cast)
    private var wakeLock: PowerManager.WakeLock? = null
    // WiFi MulticastLock (necessário para SSDP/mDNS)
    private var multicastLock: WifiManager.MulticastLock? = null

    // Cache de dispositivos (expira em 5 minutos)
    private var deviceCacheTime = 0L
    private val CACHE_TTL = 5 * 60 * 1000L

    // ── Inicialização ──────────────────────────────────────

    fun init() {
        initChromecast()
        initWifiMulticast()
        startDiscovery()
    }

    private fun initChromecast() = runCatching {
        val castCtx = CastContext.getSharedInstance(context)
        sessionMgr = castCtx.sessionManager
        sessionMgr?.addSessionManagerListener(
            object : SessionManagerListener<CastSession> {
                override fun onSessionStarted(s: CastSession, id: String) {
                    remoteClient = s.remoteMediaClient
                    remoteClient?.addListener(castListener)
                    _state.value = CastPlaybackState(
                        isConnected = true,
                        deviceName  = s.castDevice?.friendlyName ?: "Chromecast",
                        deviceType  = CastType.CHROMECAST
                    )
                    Log.i(TAG, "Chromecast conectado: ${s.castDevice?.friendlyName}")
                }
                override fun onSessionEnded(s: CastSession, e: Int) {
                    remoteClient?.removeListener(castListener)
                    remoteClient = null
                    _state.update { it.copy(isConnected=false, deviceType=null) }
                    releaseWakeLock()
                }
                override fun onSessionStarting(p: CastSession) {}
                override fun onSessionStartFailed(p: CastSession, e: Int) {}
                override fun onSessionEnding(p: CastSession) {}
                override fun onSessionResumed(p: CastSession, w: Boolean) {}
                override fun onSessionResumeFailed(p: CastSession, e: Int) {}
                override fun onSessionResuming(p: CastSession, id: String) {}
                override fun onSessionSuspended(p: CastSession, r: Int) {}
            }, CastSession::class.java
        )

        val router = MediaRouter.getInstance(context)
        val sel = MediaRouteSelector.Builder()
            .addControlCategory(CastMediaControlIntent.categoryForCast(
                CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
            .build()
        router.addCallback(sel, object : MediaRouter.Callback() {
            override fun onRouteAdded(r: MediaRouter, route: MediaRouter.RouteInfo) {
                addDevice(CastDevice(route.id, route.name, CastType.CHROMECAST,
                    manufacturer = "Google"))
            }
            override fun onRouteRemoved(r: MediaRouter, route: MediaRouter.RouteInfo) {
                removeDevice(route.id)
            }
        }, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN)
    }.onFailure { Log.w(TAG, "Chromecast não disponível: ${it.message}") }

    private val castListener = object : RemoteMediaClient.Listener {
        override fun onStatusUpdated() {
            remoteClient?.let { c ->
                _state.update {
                    it.copy(isPlaying=c.isPlaying,
                            position=c.approximateStreamPosition,
                            duration=c.streamDuration)
                }
            }
        }
        override fun onMetadataUpdated() {}
        override fun onQueueStatusUpdated() {}
        override fun onPreloadStatusUpdated() {}
        override fun onSendingRemoteMediaRequest() {}
        override fun onAdBreakStatusUpdated() {}
    }

    private fun initWifiMulticast() = runCatching {
        val wm = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wm.createMulticastLock("dendeplay_cast").apply {
            setReferenceCounted(true)
            acquire()
        }
    }

    // ── Descoberta ─────────────────────────────────────────

    /**
     * startDiscovery — lança descoberta em todos os protocolos
     * em paralelo. Resultados chegam via Flow<List<CastDevice>>.
     * Timeout: 30 segundos. Cache: 5 minutos.
     */
    fun startDiscovery() {
        val now = System.currentTimeMillis()
        if (now - deviceCacheTime < CACHE_TTL && _devices.value.isNotEmpty()) {
            Log.d(TAG, "Usando cache de dispositivos (${_devices.value.size})")
            return
        }
        _discovering.value = true
        scope.launch {
            try {
                val jobs = listOf(
                    launch { discoverViaNSD() },          // DLNA + genérico
                    launch { discoverRoku() },            // Roku SSDP
                    launch { discoverSamsungTizen() },    // Samsung SSDP
                    launch { discoverLGWebOS() },         // LG mDNS
                    launch { discoverAndroidTV() },       // Android TV mDNS
                    launch { pingCommonPorts() },         // fallback scan
                )
                withTimeout(30_000) { jobs.forEach { it.join() } }
                deviceCacheTime = System.currentTimeMillis()
                Log.i(TAG, "Descoberta concluída. ${_devices.value.size} dispositivos")
            } catch (e: TimeoutCancellationException) {
                Log.d(TAG, "Descoberta expirou (30s). ${_devices.value.size} dispositivos")
            } finally {
                _discovering.value = false
            }
        }
    }

    fun stopDiscovery() {
        _discovering.value = false
    }

    fun refreshDevices() {
        deviceCacheTime = 0L
        _devices.value = emptyList()
        startDiscovery()
    }

    // ─── NSD (DLNA genérico + Samsung/LG antigos) ─────────

    private suspend fun discoverViaNSD() {
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
        val serviceTypes = listOf("_http._tcp", "_googlecast._tcp", "_androidtvremote2._tcp")

        for (serviceType in serviceTypes) {
            val latch = CompletableDeferred<Unit>()
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t: String) {}
                override fun onServiceFound(svc: NsdServiceInfo) {
                    val n = svc.serviceName.lowercase()
                    val type = when {
                        n.contains("roku")     -> CastType.ROKU
                        n.contains("samsung")  -> CastType.SAMSUNG_TIZEN
                        n.contains("lg")       -> CastType.LG_WEBOS
                        n.contains("androidtv")|| n.contains("google tv") -> CastType.ANDROID_TV
                        n.contains("googlecast") -> CastType.CHROMECAST
                        n.contains("dlna") || n.contains("mediarenderer") -> CastType.DLNA
                        else -> CastType.DLNA
                    }
                    resolveNSD(svc, type)
                }
                override fun onServiceLost(svc: NsdServiceInfo) {
                    removeDevice(svc.serviceName)
                }
                override fun onDiscoveryStopped(t: String) { latch.complete(Unit) }
                override fun onStartDiscoveryFailed(t: String, c: Int) { latch.complete(Unit) }
                override fun onStopDiscoveryFailed(t: String, c: Int) {}
            }
            runCatching { nsdManager?.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
            delay(4000)
            runCatching { nsdManager?.stopServiceDiscovery(listener) }
        }
    }

    private fun resolveNSD(svc: NsdServiceInfo, type: CastType) {
        nsdManager?.resolveService(svc, object : NsdManager.ResolveListener {
            override fun onResolved(info: NsdServiceInfo) {
                val d = CastDevice(
                    id           = info.serviceName,
                    name         = info.serviceName,
                    type         = type,
                    address      = info.host?.hostAddress ?: "",
                    port         = info.port,
                    manufacturer = when(type) {
                        CastType.SAMSUNG_TIZEN -> "Samsung"
                        CastType.LG_WEBOS      -> "LG"
                        CastType.ROKU          -> "Roku"
                        CastType.ANDROID_TV    -> "Google"
                        CastType.CHROMECAST    -> "Google"
                        else                   -> "DLNA"
                    }
                )
                if (d.address.isNotEmpty()) {
                    addDevice(d)
                    Log.d(TAG, "NSD: ${d.name} @ ${d.address}:${d.port} [${d.type}]")
                }
            }
            override fun onResolveFailed(info: NsdServiceInfo, code: Int) {}
        })
    }

    // ─── Roku ECP / SSDP ─────────────────────────────────

    private suspend fun discoverRoku() = roku.discover { addDevice(it) }

    // ─── Samsung Tizen SSDP ───────────────────────────────

    private suspend fun discoverSamsungTizen() = samsung.discover { addDevice(it) }

    // ─── LG webOS mDNS ────────────────────────────────────

    private suspend fun discoverLGWebOS() = lg.discover { addDevice(it) }

    // ─── Android TV mDNS ──────────────────────────────────

    private suspend fun discoverAndroidTV() = androidTv.discover { addDevice(it) }

    // ─── Fallback: scan de portas comuns na LAN ───────────

    // Limita a 40 conexões simultâneas para não causar OOM em dispositivos com pouca RAM
    private val scanSemaphore = Semaphore(40)

    private suspend fun pingCommonPorts() {
        val gateway = getGatewayPrefix() ?: return
        val portsToCheck = listOf(
            8060 to CastType.ROKU,
            8001 to CastType.SAMSUNG_TIZEN,
            3000 to CastType.LG_WEBOS,
            9080 to CastType.ANDROID_TV,
            1400 to CastType.DLNA,
        )
        for (i in 1..254) {
            val ip = "$gateway.$i"
            portsToCheck.forEach { (port, type) ->
                launch {
                    scanSemaphore.withPermit {
                        if (isPortOpen(ip, port, 300)) {
                            val name = resolveHostname(ip) ?: "$type-$ip"
                            addDevice(CastDevice("$ip:$port", name, type,
                                address=ip, port=port, latencyMs=300))
                            Log.d(TAG, "Port scan: $ip:$port [$type]")
                        }
                    }
                }
            }
            if (i % 32 == 0) delay(50) // throttle entre blocos
        }
    }

    private fun getGatewayPrefix(): String? {
        return runCatching {
            val wm = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val dhcp = wm.dhcpInfo
            val gw = dhcp.gateway
            val ip = intArrayOf(gw and 0xFF, (gw shr 8) and 0xFF, (gw shr 16) and 0xFF)
            "${ip[0]}.${ip[1]}.${ip[2]}"
        }.getOrNull()
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean =
        runCatching {
            Socket().use { sock ->
                sock.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        }.getOrElse { false }

    private fun resolveHostname(ip: String): String? =
        runCatching { InetAddress.getByName(ip).canonicalHostName.takeIf { it != ip } }.getOrNull()

    // ── Cast de mídia ──────────────────────────────────────

    /**
     * cast() — envia vídeo para o dispositivo ativo.
     * Escolhe o protocolo correto automaticamente.
     */
    fun cast(
        videoUrl:  String,
        title:     String,
        thumbUrl:  String    = "",
        position:  Long      = 0L,
        subtitles: List<Pair<String,String>> = emptyList(),
    ) {
        val cur = _state.value
        if (!cur.isConnected) {
            Log.w(TAG, "cast() chamado sem dispositivo conectado")
            return
        }
        _state.update { it.copy(currentTitle=title, currentThumb=thumbUrl) }

        scope.launch {
            when (cur.deviceType) {
                CastType.CHROMECAST    -> castToChromecast(videoUrl, title, thumbUrl, position)
                CastType.ROKU         -> roku.play(videoUrl, title, thumbUrl)
                CastType.SAMSUNG_TIZEN -> samsung.play(videoUrl, title, thumbUrl)
                CastType.LG_WEBOS     -> lg.play(videoUrl, title, thumbUrl)
                CastType.ANDROID_TV   -> androidTv.play(videoUrl, title, thumbUrl)
                CastType.DLNA         -> dlna.play(videoUrl, title)
                else                  -> {}
            }
        }
    }

    private fun castToChromecast(url: String, title: String, thumb: String, pos: Long) {
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
            if (thumb.isNotEmpty()) addImage(WebImage(android.net.Uri.parse(thumb)))
        }
        val info = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(if (url.contains(".m3u8")) "application/x-mpegURL" else "video/mp4")
            .setMetadata(meta)
            .build()
        remoteClient?.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(info)
                .setCurrentTime(pos)
                .setAutoplay(true)
                .build()
        )
    }

    // ── Conectar / Desconectar ─────────────────────────────

    /**
     * connect() — conecta a um dispositivo específico.
     * Para Chromecast, abre o selector nativo.
     * Para outros, estabelece conexão direta.
     */
    fun connect(device: CastDevice) {
        scope.launch {
            val start = System.currentTimeMillis()
            runCatching {
                when (device.type) {
                    CastType.ROKU          -> roku.connect(device)
                    CastType.SAMSUNG_TIZEN -> samsung.connect(device)
                    CastType.LG_WEBOS      -> lg.connect(device)
                    CastType.ANDROID_TV    -> androidTv.connect(device)
                    CastType.DLNA          -> dlna.connect(device)
                    CastType.CHROMECAST    -> {} // gerido pelo MediaRouter
                }
                val latency = (System.currentTimeMillis() - start).toInt()
                _state.value = CastPlaybackState(
                    isConnected = true,
                    deviceName  = device.name,
                    deviceType  = device.type,
                )
                Log.i(TAG, "Conectado a ${device.name} em ${latency}ms")
            }.onFailure {
                Log.e(TAG, "Falha ao conectar a ${device.name}: ${it.message}")
            }
        }
    }

    fun disconnect() {
        when (_state.value.deviceType) {
            CastType.CHROMECAST    -> sessionMgr?.endCurrentSession(true)
            CastType.ROKU          -> roku.disconnect()
            CastType.SAMSUNG_TIZEN -> samsung.disconnect()
            CastType.LG_WEBOS      -> lg.disconnect()
            CastType.ANDROID_TV    -> androidTv.disconnect()
            CastType.DLNA          -> dlna.disconnect()
            else                   -> {}
        }
        _state.value = CastPlaybackState()
        releaseWakeLock()
    }

    // ── Controles de reprodução ────────────────────────────

    fun play()         = doControl { play() }
    fun pause()        = doControl { pause() }
    fun stop()         = doControl { stop() }
    fun seekTo(ms: Long) {
        remoteClient?.seek(ms)
        roku.seekTo(ms); samsung.seekTo(ms); lg.seekTo(ms); androidTv.seekTo(ms); dlna.seekTo(ms)
    }
    fun setVolume(v: Float) {
        remoteClient?.setStreamVolume(v.toDouble())
        roku.setVolume(v); samsung.setVolume(v); lg.setVolume(v)
        _state.update { it.copy(volume=v) }
    }
    fun setSpeed(speed: Float) {
        roku.setSpeed(speed); samsung.setSpeed(speed); lg.setSpeed(speed); androidTv.setSpeed(speed)
        _state.update { it.copy(speed=speed) }
    }
    fun setSubtitle(track: String) { _state.update { it.copy(subtitleTrack=track) } }
    fun setAudioTrack(track: String) { _state.update { it.copy(audioTrack=track) } }

    private fun doControl(action: RemoteMediaClient.() -> Unit) {
        remoteClient?.action()
    }

    // ── Wake Lock / Economia de Energia ───────────────────

    /**
     * setPowerSave(false) — mantém CPU e tela ativas durante cast.
     * Equivalente a "Desativar Economia de Energia" do Web Video Cast.
     */
    fun setPowerSave(enabled: Boolean) {
        if (!enabled) {
            // Adquire WakeLock parcial (CPU ativa, tela pode apagar)
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "dendeplay:cast_wakelock"
            ).apply {
                acquire(3 * 60 * 60 * 1000L) // máximo 3 horas
            }
            Log.i(TAG, "WakeLock adquirido — economia de energia DESATIVADA")
        } else {
            releaseWakeLock()
            Log.i(TAG, "WakeLock liberado — economia de energia ATIVADA")
        }
        _state.update { it.copy(isPowerSaveOff = !enabled) }
    }

    private fun releaseWakeLock() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wakeLock = null
    }

    // ── Helpers internos ──────────────────────────────────

    private fun addDevice(d: CastDevice) {
        _devices.update { list ->
            if (list.none { it.id == d.id }) list + d
            else list.map { if (it.id == d.id) d else it }
        }
    }

    private fun removeDevice(id: String) {
        _devices.update { list -> list.filter { it.id != id } }
    }

    fun destroy() {
        scope.cancel()
        releaseWakeLock()
        multicastLock?.takeIf { it.isHeld }?.release()
        runCatching { nsdManager = null } // evita listeners órfãos
        dlna.destroy(); roku.destroy(); samsung.destroy(); lg.destroy(); androidTv.destroy()
    }
}
