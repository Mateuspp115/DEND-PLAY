package com.dendeplay.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.MediaDetails
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

sealed class DetailUiState {
    object Loading : DetailUiState()
    data class Success(val details: MediaDetails) : DetailUiState()
    data class Error(val message: String) : DetailUiState()
}

@HiltViewModel
class DetailViewModel @Inject constructor(private val repo: MediaRepository) : ViewModel() {
    private val _state  = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    private val _isFav  = MutableStateFlow(false)
    val state:  StateFlow<DetailUiState> = _state.asStateFlow()
    val isFav:  StateFlow<Boolean>       = _isFav.asStateFlow()

    private var mediaId = ""; private var provider = ""

    fun load(id: String, prov: String) {
        mediaId = id; provider = prov
        viewModelScope.launch {
            _state.value = DetailUiState.Loading
            withTimeoutOrNull(12_000) {
                repo.getMediaDetails(id, prov)
            }?.onSuccess { det ->
                    val eps = withTimeoutOrNull(8_000) {
                        repo.getEpisodes(id, prov)
                    }?.getOrElse { emptyList() } ?: emptyList()
                    _state.value = DetailUiState.Success(det.copy(episodes = eps.takeIf{it.isNotEmpty()} ?: det.episodes))
                    _isFav.value = repo.getFavorites().any { it.id == id }
                }
                ?.onFailure { _state.value = DetailUiState.Error(it.message ?: "Erro") }
                    ?: run { _state.value = DetailUiState.Error("Tempo esgotado. Tente novamente.") }
        }
    }

    fun toggleFav() {
        val s = _state.value as? DetailUiState.Success ?: return
        viewModelScope.launch {
            if (_isFav.value) { repo.removeFromFavorites(mediaId); _isFav.value = false }
            else {
                repo.addToFavorites(com.dendeplay.domain.model.SearchResult(
                    id=s.details.id, title=s.details.title, imageUrl=s.details.imageUrl,
                    url=s.details.url, provider=s.details.provider, mediaType=s.details.mediaType,
                    rating=s.details.rating, year=s.details.year))
                _isFav.value = true
            }
        }
    }
}
