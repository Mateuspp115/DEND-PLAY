package com.dendeplay.ui.credits

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.dendeplay.ui.components.DendeLogo
import com.dendeplay.ui.theme.DendeColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreditsScreen(onBack: () -> Unit) {
    val uri = LocalUriHandler.current

    Scaffold(
        containerColor = DendeColors.Background,
        topBar = {
            TopAppBar(
                title = { Text("Sobre e Créditos", color=DendeColors.Text, fontWeight=FontWeight.Bold) },
                navigationIcon = { IconButton(onBack){ Icon(Icons.Rounded.ArrowBack,"Voltar",tint=DendeColors.Text) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor=DendeColors.Background)
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
            .padding(horizontal=24.dp, vertical=16.dp), horizontalAlignment=Alignment.CenterHorizontally) {

            // ── Logo ──────────────────────────────────────
            Box(Modifier.size(100.dp).background(Brush.radialGradient(listOf(DendeColors.FlameOrange.copy(.15f),Color.Transparent)),CircleShape), Alignment.Center) {
                DendeLogo(80.dp)
            }
            Spacer(Modifier.height(12.dp))
            Text("DENDEPLAY", fontSize=26.sp, fontWeight=FontWeight.Black, color=DendeColors.Primary, letterSpacing=3.sp)
            Text("v1.8.0", fontSize=13.sp, color=DendeColors.TextSub)
            Text("Seu streaming universal", fontSize=12.sp, color=DendeColors.TextHint)

            Spacer(Modifier.height(22.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── Criador ───────────────────────────────────
            SectionLabel("CRIADOR")
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp), CardDefaults.cardColors(DendeColors.Surface)) {
                Row(Modifier.padding(16.dp), Arrangement.spacedBy(14.dp), Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).background(Brush.radialGradient(listOf(DendeColors.FlameOrange,DendeColors.PrimaryDark)),CircleShape), Alignment.Center) {
                        Text("M", color=Color.Black, fontSize=22.sp, fontWeight=FontWeight.Black)
                    }
                    Column {
                        Text("Mateus \"TinkWink\"", fontSize=17.sp, fontWeight=FontWeight.Bold, color=DendeColors.Text)
                        Text("Desenvolvimento, design e implementacao", fontSize=12.sp, color=DendeColors.TextSub)
                        Text("© 2026 DENDEPLAY", fontSize=11.sp, color=DendeColors.TextHint)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── Projeto Original ──────────────────────────
            SectionLabel("PROJETO ORIGINAL")
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp), CardDefaults.cardColors(DendeColors.Surface)) {
                Column(Modifier.padding(16.dp)) {
                    Row(Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Code, null, tint=Color(0xFF4285F4), modifier=Modifier.size(22.dp))
                        Column {
                            Text("GoAnime", fontSize=16.sp, fontWeight=FontWeight.Bold, color=DendeColors.Text)
                            Text("por Krone (alvarorichard)", fontSize=12.sp, color=DendeColors.TextSub)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    InfoRow("Licenca", "MIT License")
                    InfoRow("Copyright", "© 2023 Krone")
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF4285F4).copy(.1f))
                        .clickable{uri.openUri("https://github.com/alvarorichard/GoAnime")}.padding(horizontal=12.dp,vertical=8.dp),
                        Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
                        Icon(Icons.Rounded.OpenInNew, null, tint=Color(0xFF4285F4), modifier=Modifier.size(14.dp))
                        Text("github.com/alvarorichard/GoAnime", fontSize=12.sp, color=Color(0xFF4285F4), fontWeight=FontWeight.Medium)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── DUAL LICENSE — lado a lado ─────────────────
            SectionLabel("LICENCAS")
            Spacer(Modifier.height(10.dp))
            Text("Este aplicativo usa dois sistemas de licenca:", color=DendeColors.TextSub, fontSize=11.sp, textAlign=TextAlign.Center)
            Spacer(Modifier.height(10.dp))

            // MIT License (GoAnime)
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp),
                CardDefaults.cardColors(Color(0xFF0D1B2A))) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Row(Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(Color(0xFF4285F4), CircleShape))
                            Text("MIT License", fontSize=14.sp, fontWeight=FontWeight.Black, color=Color(0xFF4285F4))
                        }
                        Box(Modifier.background(Color(0xFF4285F4).copy(.15f), RoundedCornerShape(6.dp)).padding(horizontal=8.dp,vertical=3.dp)){
                            Text("GoAnime", fontSize=9.sp, color=Color(0xFF4285F4), fontWeight=FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Copyright © 2023 Krone", fontSize=10.sp, color=DendeColors.TextSub, fontWeight=FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text("Uso livre, inclusive comercial, para o codigo original do GoAnime. A permissao e concedida gratuitamente a qualquer pessoa que obtenha uma copia deste software.",
                        fontSize=9.sp, color=DendeColors.TextHint, lineHeight=14.sp)
                }
            }

            Spacer(Modifier.height(10.dp))

            // DENDÊPLAY License
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp),
                CardDefaults.cardColors(Color(0xFF1A1200))) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Row(Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(DendeColors.Primary, CircleShape))
                            Text("DENDEPLAY License", fontSize=14.sp, fontWeight=FontWeight.Black, color=DendeColors.Primary)
                        }
                        Box(Modifier.background(DendeColors.Primary.copy(.15f), RoundedCornerShape(6.dp)).padding(horizontal=8.dp,vertical=3.dp)){
                            Text("Modificacoes", fontSize=9.sp, color=DendeColors.Primary, fontWeight=FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Copyright © 2026 Mateus \"TinkWink\"", fontSize=10.sp, color=DendeColors.TextSub, fontWeight=FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text("Uso PESSOAL e NAO COMERCIAL. PROIBIDO: vender, inserir anuncios, distribuir comercialmente ou remover creditos sem autorizacao expressa do autor.",
                        fontSize=9.sp, color=DendeColors.TextHint, lineHeight=14.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth().background(DendeColors.Error.copy(.1f),RoundedCornerShape(6.dp)).padding(8.dp),
                        Arrangement.spacedBy(6.dp), Alignment.CenterVertically){
                        Icon(Icons.Rounded.Block,null,tint=DendeColors.Error,modifier=Modifier.size(12.dp))
                        Text("Proibida venda ou insercao de anuncios", color=DendeColors.Error, fontSize=9.sp, fontWeight=FontWeight.Medium)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── Tecnologias ───────────────────────────────
            SectionLabel("TECNOLOGIAS")
            Spacer(Modifier.height(10.dp))
            TechGrid()

            Spacer(Modifier.height(20.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── Providers ─────────────────────────────────
            SectionLabel("26 PROVIDERS DE CONTEUDO")
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp), CardDefaults.cardColors(DendeColors.Surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    ProviderGroup("Anime PT-BR (12)", listOf("AnimeFire","GoAnimes","AniTube","AnimesOnline","HinataSoul","AnimesHouse","Goyabu","AnimeKing","AnimesDigital","BetterAnime","AnimesOrion","AnimesZone"))
                    HorizontalDivider(color=DendeColors.SurfaceVar)
                    ProviderGroup("Filmes/Series PT-BR (9)", listOf("Pobreflix","TopFlix","MegaFlix","SuperFlix","Tugaflix","Mega Filmes HD","Do Flix","Rede Canais","MaxFilmes"))
                    HorizontalDivider(color=DendeColors.SurfaceVar)
                    ProviderGroup("Universal EN (5)", listOf("AllAnime","FlixHQ","AnimeKisa","Gogoanime","9Anime"))
                }
            }

            Spacer(Modifier.height(20.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(20.dp))

            // ── Cast suportado ────────────────────────────
            SectionLabel("CAST SUPORTADO")
            Spacer(Modifier.height(8.dp))
            val castPlatforms = listOf(
                Triple("Chromecast", "Google Cast SDK", Color(0xFF4285F4)),
                Triple("Samsung",    "MultiScreen + SmartThings", Color(0xFF1428A0)),
                Triple("LG",         "webOS 3-8 WebSocket", Color(0xFFC0392B)),
                Triple("Roku TV",    "ECP HTTP :8060", Color(0xFF662D8C)),
                Triple("Android TV", "DIAL :9080", Color(0xFF4CAF50)),
                Triple("DLNA",       "SOAP/UPnP genérico", DendeColors.Primary),
            )
            Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                castPlatforms.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                        pair.forEach { (name, proto, color) ->
                            Row(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(DendeColors.Surface).padding(10.dp),
                                Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                                Box(Modifier.size(8.dp).background(color,CircleShape))
                                Column {
                                    Text(name, fontSize=11.sp, fontWeight=FontWeight.Bold, color=DendeColors.Text)
                                    Text(proto, fontSize=9.sp, color=DendeColors.TextHint)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            // ── Footer ────────────────────────────────────
            Spacer(Modifier.height(24.dp))
            Text("DENDEPLAY v1.8.0", fontSize=12.sp, fontWeight=FontWeight.Bold, color=DendeColors.Primary)
            Text("© 2026 Mateus \"TinkWink\" — Todos os direitos reservados", fontSize=10.sp, color=DendeColors.TextHint, textAlign=TextAlign.Center)
            Text("Baseado no GoAnime © 2023 Krone — MIT License", fontSize=10.sp, color=DendeColors.TextHint, textAlign=TextAlign.Center)
            Text("Uso pessoal e nao comercial. Proibida venda ou insercao de anuncios.", fontSize=9.sp, color=DendeColors.TextHint, textAlign=TextAlign.Center)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable private fun SectionLabel(t: String) =
    Text(t, fontSize=11.sp, fontWeight=FontWeight.Black, color=DendeColors.Primary, letterSpacing=2.sp, modifier=Modifier.fillMaxWidth())

@Composable private fun InfoRow(l: String, v: String) =
    Row(Modifier.fillMaxWidth().padding(vertical=2.dp), Arrangement.SpaceBetween) {
        Text(l, fontSize=11.sp, color=DendeColors.TextSub)
        Text(v, fontSize=11.sp, color=DendeColors.Text, fontWeight=FontWeight.Medium)
    }

@Composable private fun TechGrid() {
    val techs = listOf(
        Icons.Rounded.Code to "Go 1.21",
        Icons.Rounded.Android to "Kotlin",
        Icons.Rounded.ViewQuilt to "Jetpack Compose",
        Icons.Rounded.PlayCircle to "ExoPlayer",
        Icons.Rounded.Cast to "Google Cast",
        Icons.Rounded.Tv to "DLNA/UPnP",
        Icons.Rounded.Storage to "Room DB",
        Icons.Rounded.AccountTree to "Hilt DI",
        Icons.Rounded.BuildCircle to "GitHub Actions",
        Icons.Rounded.PhoneAndroid to "Android 8.0+",
    )
    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        techs.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                row.forEach { (icon, label) ->
                    Row(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(DendeColors.Surface).padding(horizontal=10.dp,vertical=8.dp),
                        Arrangement.spacedBy(6.dp), Alignment.CenterVertically) {
                        Icon(icon, null, tint=DendeColors.Primary, modifier=Modifier.size(14.dp))
                        Text(label, fontSize=11.sp, color=DendeColors.Text)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable private fun ProviderGroup(n: String, ps: List<String>) = Column {
    Text(n, fontSize=11.sp, fontWeight=FontWeight.Bold, color=DendeColors.TextSub)
    Spacer(Modifier.height(4.dp))
    Text(ps.joinToString(" · "), fontSize=11.sp, color=DendeColors.TextHint, lineHeight=16.sp)
}
