package com.dendeplay.ui.detail

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dendeplay.domain.model.*
import com.dendeplay.ui.components.DendeLoadingIndicator
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.theme.DendeColors

@Composable
fun DetailScreen(
    mediaId:      String,
    provider:     String,
    onBack:       () -> Unit,
    onPlayEpisode: (Episode, MediaDetails) -> Unit,
    onOpenChat:   ((String, String) -> Unit)? = null,
    vm:           DetailViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val isFav by vm.isFav.collectAsStateWithLifecycle()
    LaunchedEffect(mediaId, provider) { vm.load(mediaId, provider) }

    when (val s = state) {
        is DetailUiState.Loading -> Box(Modifier.fillMaxSize().background(DendeColors.Background), Alignment.Center) { DendeLoadingIndicator() }
        is DetailUiState.Error   -> Box(Modifier.fillMaxSize().background(DendeColors.Background), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Rounded.WifiOff, null, tint=DendeColors.FlameOrange, modifier=Modifier.size(52.dp))
                Spacer(Modifier.height(12.dp))
                Text(s.message, color = DendeColors.TextSub, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick={ vm.load(mediaId, provider) }, colors=ButtonDefaults.buttonColors(DendeColors.Primary)) {
                    Icon(Icons.Rounded.Refresh, null, modifier=Modifier.size(16.dp), tint=Color.Black)
                    Spacer(Modifier.width(6.dp))
                    Text("Tentar novamente", color=Color.Black)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick=onBack) { Text("Voltar") }
            }
        }
        is DetailUiState.Success -> DetailContent(s.details, isFav, onBack, vm::toggleFav, onPlayEpisode, onOpenChat)
    }
}

@Composable
private fun DetailContent(
    det:          MediaDetails,
    isFav:        Boolean,
    onBack:       () -> Unit,
    onFav:        () -> Unit,
    onPlay:       (Episode, MediaDetails) -> Unit,
    onOpenChat:   ((String, String) -> Unit)?,
) {
    var selSeason by remember { mutableStateOf(0) }
    var expanded  by remember { mutableStateOf(false) }
    var dubFilter by remember { mutableStateOf("all") } // "all","dub","sub"

    LazyColumn(Modifier.fillMaxSize().background(DendeColors.Background)) {
        // Hero
        item {
            Box(Modifier.fillMaxWidth().height(290.dp)) {
                AsyncImage(det.bannerUrl.takeIf{it.isNotEmpty()}?:det.imageUrl, det.title,
                    Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(.3f), DendeColors.Background), startY=80f)))
                Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), Arrangement.SpaceBetween) {
                    IconButton(onBack, Modifier.background(Color.Black.copy(.5f),CircleShape)){Icon(Icons.Rounded.ArrowBack,null,tint=DendeColors.White)}
                    Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                        if (onOpenChat != null)
                            IconButton({onOpenChat(det.id, det.title)}, Modifier.background(Color.Black.copy(.5f),CircleShape)){
                                Icon(Icons.Rounded.Forum,null,tint=DendeColors.White)
                            }
                        IconButton(onFav, Modifier.background(Color.Black.copy(.5f),CircleShape)){
                            Icon(if(isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,null,
                                tint=if(isFav) DendeColors.Primary else DendeColors.White)
                        }
                    }
                }
                Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp), Arrangement.spacedBy(14.dp), Alignment.Bottom) {
                    Box(Modifier.width(88.dp).height(126.dp).clip(RoundedCornerShape(10.dp)).border(1.5.dp,DendeColors.Primary.copy(.4f),RoundedCornerShape(10.dp))) {
                        AsyncImage(det.imageUrl, null, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(det.title, color=DendeColors.White, fontSize=17.sp, fontWeight=FontWeight.Black, maxLines=2, overflow=TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            if(det.year.isNotEmpty()) Text(det.year, color=DendeColors.FlameGold, fontSize=11.sp, fontWeight=FontWeight.Bold)
                            if(det.rating>0) Text("%.1f".format(det.rating), color=DendeColors.FlameGold, fontSize=11.sp, fontWeight=FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        // Badges de idioma
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            if(det.hasDub)
                                LanguageBadge("DUBLADO", Icons.Rounded.Mic, Color(0xFF007A33))
                            if(det.hasSub)
                                LanguageBadge("LEGENDADO", Icons.Rounded.Subtitles, Color(0xFF1565C0))
                        }
                        Spacer(Modifier.height(8.dp))
                        Button(onClick={det.episodes.firstOrNull()?.let{onPlay(it,det)}},
                            modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(10.dp),
                            colors=ButtonDefaults.buttonColors(DendeColors.Primary)) {
                            Icon(Icons.Rounded.PlayArrow,null,modifier=Modifier.size(18.dp),tint=Color.Black)
                            Spacer(Modifier.width(6.dp))
                            Text("ASSISTIR", color=Color.Black, fontWeight=FontWeight.Black, fontSize=13.sp, letterSpacing=1.sp)
                        }
                    }
                }
            }
        }
        // Filtro dublado/legendado
        if(det.hasDub && det.hasSub) item {
            Row(Modifier.padding(horizontal=16.dp, vertical=4.dp), Arrangement.spacedBy(8.dp)) {
                listOf("all" to "Ambos", "dub" to "Dublado", "sub" to "Legendado").forEach { (k,v) ->
                    FilterChip(selected=dubFilter==k, onClick={dubFilter=k}, label={Text(v,fontSize=11.sp)}, shape=RoundedCornerShape(20.dp),
                        colors=FilterChipDefaults.filterChipColors(selectedContainerColor=DendeColors.Primary,selectedLabelColor=Color.Black,containerColor=DendeColors.Card,labelColor=DendeColors.TextSub))
                }
            }
        }
        // Gêneros
        item {
            LazyRow(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                items(det.genres) { g ->
                    Box(Modifier.background(DendeColors.SurfaceVar,RoundedCornerShape(20.dp)).padding(horizontal=10.dp,vertical=5.dp)){
                        Text(g, color=DendeColors.TextSub, fontSize=11.sp)
                    }
                }
            }
        }
        // Sinopse
        if(det.overview.isNotBlank()) item {
            Column(Modifier.padding(horizontal=16.dp,vertical=8.dp)) {
                Text("Sinopse", color=DendeColors.Text, fontWeight=FontWeight.Bold, fontSize=15.sp, modifier=Modifier.padding(bottom=6.dp))
                Text(det.overview, color=DendeColors.TextSub, fontSize=13.sp, maxLines=if(expanded) Int.MAX_VALUE else 3, overflow=TextOverflow.Ellipsis, lineHeight=18.sp)
                TextButton(onClick={expanded=!expanded}){Text(if(expanded)"Ver menos" else "Ver mais", color=DendeColors.Primary, fontSize=12.sp)}
            }
        }
        // Botão de Chat
        if(onOpenChat != null) item {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp).clip(RoundedCornerShape(12.dp))
                .background(DendeColors.Primary.copy(.08f)).clickable{onOpenChat(det.id,det.title)}.padding(14.dp),
                Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                Icon(Icons.Rounded.Forum,null,tint=DendeColors.Primary,modifier=Modifier.size(20.dp))
                Column(Modifier.weight(1f)) {
                    Text("Discussão da série", color=DendeColors.Text, fontSize=13.sp, fontWeight=FontWeight.SemiBold)
                    Text("Comente e veja o que outros usuarios acham", color=DendeColors.TextSub, fontSize=11.sp)
                }
                Icon(Icons.Rounded.ChevronRight,null,tint=DendeColors.Primary,modifier=Modifier.size(16.dp))
            }
        }
        // Temporadas
        if(det.seasons.isNotEmpty()) item {
            LazyRow(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                itemsIndexed(det.seasons) { i, season ->
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if(i==selSeason) DendeColors.Primary else DendeColors.Card)
                        .dendeClickable{selSeason=i}.padding(horizontal=14.dp,vertical=8.dp)) {
                        Text("Temporada ${season.number}", color=if(i==selSeason) Color.Black else DendeColors.TextSub, fontSize=12.sp, fontWeight=if(i==selSeason) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
        // Episódios
        val eps = (if(det.seasons.isNotEmpty()) det.seasons.getOrNull(selSeason)?.episodes else det.episodes) ?: emptyList()
        if(eps.isNotEmpty()) {
            item { Text("Episódios (${eps.size})", color=DendeColors.Text, fontWeight=FontWeight.Bold, fontSize=15.sp, modifier=Modifier.padding(horizontal=16.dp,vertical=8.dp)) }
            items(eps, key={it.number}) { ep ->
                Row(Modifier.fillMaxWidth().dendeClickable{onPlay(ep,det)}.padding(horizontal=16.dp,vertical=8.dp),
                    Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                    Box(Modifier.size(width=108.dp,height=60.dp).clip(RoundedCornerShape(8.dp)).background(DendeColors.Card), Alignment.Center) {
                        if(ep.thumbnail.isNotEmpty()) AsyncImage(ep.thumbnail,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                        Box(Modifier.size(30.dp).background(DendeColors.Primary.copy(.85f),CircleShape), Alignment.Center){
                            Icon(Icons.Rounded.PlayArrow,null,tint=Color.Black,modifier=Modifier.size(17.dp))
                        }
                        Box(Modifier.align(Alignment.BottomStart).padding(4.dp).background(Color.Black.copy(.7f),RoundedCornerShape(3.dp)).padding(horizontal=4.dp,vertical=1.dp)){
                            Text("Ep. ${ep.number}", color=DendeColors.White, fontSize=8.sp, fontWeight=FontWeight.Bold)
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(ep.title.ifEmpty{"Episodio ${ep.number}"}, color=DendeColors.Text, fontSize=12.5.sp, fontWeight=FontWeight.SemiBold, maxLines=2, overflow=TextOverflow.Ellipsis)
                        if(ep.duration>0) Text("${ep.duration/60} min", color=DendeColors.TextHint, fontSize=10.sp)
                    }
                }
                HorizontalDivider(color=DendeColors.Card, thickness=.5.dp)
            }
        }
        item { Spacer(Modifier.height(32.dp)) }
    }
}

@Composable
private fun LanguageBadge(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(6.dp)).background(color.copy(.15f))
            .border(1.dp, color.copy(.5f), RoundedCornerShape(6.dp))
            .padding(horizontal=8.dp, vertical=4.dp),
        Arrangement.spacedBy(4.dp), Alignment.CenterVertically
    ) {
        Icon(icon, null, tint=color, modifier=Modifier.size(10.dp))
        Text(label, color=color, fontSize=9.sp, fontWeight=FontWeight.Black)
    }
}
