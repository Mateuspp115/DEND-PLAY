package com.dendeplay.ui.splash

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.dendeplay.ui.components.DendeLogo
import com.dendeplay.ui.theme.DendeColors
import kotlinx.coroutines.delay

private enum class Phase { BLACK, SCALE_IN, TRACE, LETTERS, GLOW, FADE_OUT }

@Composable
fun DendePlaySplashScreen(modifier: Modifier = Modifier, onSplashComplete: () -> Unit) {
    var phase by remember { mutableStateOf(Phase.BLACK) }

    val logoScale by animateFloatAsState(if (phase == Phase.BLACK) .70f else if (phase == Phase.FADE_OUT) .96f else 1f, tween(500, easing = CubicBezierEasing(.2f,.9f,.4f,1.1f)), label="s")
    val logoAlpha by animateFloatAsState(if (phase == Phase.BLACK || phase == Phase.FADE_OUT) 0f else 1f, tween(400), label="a")
    val traceProgress by animateFloatAsState(when(phase) { Phase.TRACE,Phase.LETTERS,Phase.GLOW,Phase.FADE_OUT->1f; else->0f }, tween(1100, easing=LinearEasing), label="t")
    val traceAlpha by animateFloatAsState(when(phase) { Phase.TRACE->1f; Phase.LETTERS->.5f; Phase.GLOW->.2f; else->0f }, tween(300), label="ta")

    val appName = "DENDÊPLAY"
    val lAlphas = appName.indices.map { i ->
        animateFloatAsState(if (phase == Phase.LETTERS || phase == Phase.GLOW) 1f else 0f, tween(200, delayMillis = i*65), label="la$i")
    }
    val lOffsets = appName.indices.map { i ->
        animateFloatAsState(if (phase == Phase.LETTERS || phase == Phase.GLOW) 0f else if (phase == Phase.FADE_OUT) -4f else 16f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label="lo$i")
    }

    val gp = rememberInfiniteTransition(label="g")
    val gpv by gp.animateFloat(.5f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label="gpv")
    val screenAlpha by animateFloatAsState(if (phase == Phase.FADE_OUT) 0f else 1f, tween(280), label="sc")

    LaunchedEffect(Unit) {
        delay(150); phase = Phase.SCALE_IN
        delay(450); phase = Phase.TRACE
        delay(1100); phase = Phase.LETTERS
        delay(580); phase = Phase.GLOW
        delay(350); phase = Phase.FADE_OUT
        delay(320); onSplashComplete()
    }

    Box(modifier.fillMaxSize().background(Color.Black).alpha(screenAlpha), Alignment.Center) {
        if (phase == Phase.GLOW) {
            Canvas(Modifier.size(260.dp).offset(y=(-10).dp).alpha(gpv*.35f).blur(55.dp)) {
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFF6000), Color.Transparent)))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(180.dp).scale(logoScale).alpha(logoAlpha), Alignment.Center) {
                // Chama desenhada
                Canvas(Modifier.size(180.dp)) {
                    val w = size.width; val h = size.height; val cx = w*.50f; val cy = h*.52f
                    // Body
                    val body = Path().apply {
                        moveTo(cx, cy+h*.40f)
                        cubicTo(cx-w*.38f,cy+h*.38f,cx-w*.46f,cy+h*.14f,cx-w*.34f,cy-h*.08f)
                        cubicTo(cx-w*.28f,cy-h*.20f,cx-w*.14f,cy-h*.30f,cx-w*.02f,cy-h*.38f)
                        cubicTo(cx+w*.12f,cy-h*.28f,cx+w*.28f,cy-h*.16f,cx+w*.34f,cy-h*.02f)
                        cubicTo(cx+w*.44f,cy+h*.16f,cx+w*.40f,cy+h*.36f,cx,cy+h*.40f); close()
                    }
                    drawPath(body, Brush.linearGradient(listOf(Color(0xFFCC1500),Color(0xFFFF5500),Color(0xFFFF8C00),Color(0xFFFFAA00)), Offset(cx-w*.2f,cy+h*.4f),Offset(cx+w*.1f,cy-h*.38f)))
                    // Left wing
                    val lw = Path().apply { moveTo(cx-w*.34f,cy-h*.08f); cubicTo(cx-w*.46f,cy-h*.20f,cx-w*.44f,cy-h*.38f,cx-w*.28f,cy-h*.44f); cubicTo(cx-w*.20f,cy-h*.34f,cx-w*.22f,cy-h*.20f,cx-w*.20f,cy-h*.10f); close() }
                    drawPath(lw, Color(0xFFCC1500).copy(.85f))
                    // Right wing  
                    val rw = Path().apply { moveTo(cx+w*.34f,cy-h*.02f); cubicTo(cx+w*.44f,cy-h*.14f,cx+w*.44f,cy-h*.28f,cx+w*.34f,cy-h*.36f); cubicTo(cx+w*.28f,cy-h*.28f,cx+w*.30f,cy-h*.16f,cx+w*.30f,cy-h*.06f); close() }
                    drawPath(rw, Color(0xFFDD2800).copy(.85f))
                    // Main flame
                    val mf = Path().apply { moveTo(cx-w*.10f,cy-h*.38f); cubicTo(cx-w*.18f,cy-h*.52f,cx-w*.14f,cy-h*.66f,cx-w*.04f,cy-h*.74f); cubicTo(cx+w*.04f,cy-h*.62f,cx+w*.08f,cy-h*.50f,cx+w*.06f,cy-h*.40f); close() }
                    drawPath(mf, Brush.linearGradient(listOf(Color(0xFFFF8C00),Color(0xFFFFD700),Color(0xFFFFE840)), Offset(cx,cy-h*.38f), Offset(cx,cy-h*.74f)))
                    // Highlight
                    val hi = Path().apply { moveTo(cx+w*.08f,cy-h*.38f); cubicTo(cx+w*.14f,cy-h*.48f,cx+w*.16f,cy-h*.58f,cx+w*.10f,cy-h*.64f); cubicTo(cx+w*.06f,cy-h*.56f,cx+w*.06f,cy-h*.46f,cx+w*.08f,cy-h*.38f); close() }
                    drawPath(hi, Brush.linearGradient(listOf(Color(0xFFFFAA00),Color(0xFFFFF8A0)), Offset(cx+w*.08f,cy-h*.38f), Offset(cx+w*.16f,cy-h*.64f)))
                    // Play
                    val pL=cx-w*.12f; val pT=cy-h*.13f; val pB=cy+h*.13f; val pR=cx+w*.18f; val pM=(pT+pB)/2f
                    drawPath(Path().apply{moveTo(pL+2f,pT+2f);lineTo(pL+2f,pB+2f);lineTo(pR+2f,pM+2f);close()}, Color(0x40000000))
                    drawPath(Path().apply{moveTo(pL,pT);lineTo(pL,pB);lineTo(pR,pM);close()}, Color(0xEE0D0D12))
                    // Trace ring
                    if (traceProgress > 0f && traceAlpha > 0f) {
                        val r = w*.46f
                        drawArc(Brush.sweepGradient(listOf(Color.Transparent,Color(0xFFFFB300).copy(traceAlpha),Color(0xFFFFE040).copy(traceAlpha),Color(0xFFFF8C00).copy(traceAlpha*.6f)), Offset(cx,cy)),
                            -90f, 360f*traceProgress, false, Offset(cx-r,cy-r), Size(r*2f,r*2f),
                            style=Stroke(3.5.dp.toPx(), cap=StrokeCap.Round))
                    }
                }
            }
            Spacer(Modifier.height(34.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                appName.forEachIndexed { i, c ->
                    Text(c.toString(), color=Color.White.copy(lAlphas[i].value), fontSize=36.sp,
                        fontWeight=FontWeight.Black, letterSpacing=1.5.sp, modifier=Modifier.offset(y=lOffsets[i].value.dp))
                }
            }
        }
    }
}
