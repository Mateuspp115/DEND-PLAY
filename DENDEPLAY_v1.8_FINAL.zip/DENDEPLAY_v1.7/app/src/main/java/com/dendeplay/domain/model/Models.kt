package com.dendeplay.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// ════════════════════════════════════════════════════════
// DENDÊPLAY — Domain Models
// Espelham o JSON retornado pelo Go SDK
// ════════════════════════════════════════════════════════

@Serializable
data class SearchResult(
    val id:         String       = "",
    val title:      String       = "",
    @SerialName("title_en")  val titleEn:  String = "",
    @SerialName("image_url") val imageUrl: String = "",
    val url:        String       = "",
    val provider:   String       = "",
    @SerialName("media_type") val mediaType: String = "anime",
    val year:       String       = "",
    val rating:     Double       = 0.0,
    val episodes:   Int          = 0,
    val language:   String       = "",
    val quality:    String       = "",
)

@Serializable
data class MediaDetails(
    val id:         String       = "",
    val title:      String       = "",
    @SerialName("title_en")  val titleEn:  String = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("banner_url") val bannerUrl: String = "",
    val url:        String       = "",
    val provider:   String       = "",
    @SerialName("media_type") val mediaType: String = "anime",
    val overview:   String       = "",
    val genres:     List<String> = emptyList(),
    val year:       String       = "",
    val status:     String       = "",
    val rating:     Double       = 0.0,
    @SerialName("total_eps") val totalEps: Int = 0,
    @SerialName("anilist_id") val anilistId: Int = 0,
    @SerialName("mal_id")    val malId:    Int = 0,
    @SerialName("tmdb_id")   val tmdbId:   Int = 0,
    @SerialName("imdb_id")   val imdbId:   String = "",
    val seasons:    List<Season>  = emptyList(),
    val episodes:   List<Episode> = emptyList(),
    @SerialName("has_dub")   val hasDub:   Boolean = false,
    @SerialName("has_sub")   val hasSub:   Boolean = true,
    val language:   String        = "",
)

@Serializable
data class Season(
    val id:       String        = "",
    val number:   Int           = 0,
    val title:    String        = "",
    val episodes: List<Episode> = emptyList(),
)

@Serializable
data class Episode(
    val number:   Int    = 0,
    val title:    String = "",
    val url:      String = "",
    @SerialName("data_id")   val dataId:   String = "",
    @SerialName("season_id") val seasonId: String = "",
    val aired:    String = "",
    val duration: Int    = 0,
    @SerialName("is_filler") val isFiller: Boolean = false,
    val thumbnail: String = "",
)

@Serializable
data class VideoSource(
    val url:      String            = "",
    val quality:  String            = "auto",
    val format:   String            = "hls",
    val headers:  Map<String, String> = emptyMap(),
    val referer:  String            = "",
    val provider: String            = "",
    val score:    Int               = 0,
    val label:    String            = "",
)

@Serializable
data class ResolvedStream(
    val url:       String            = "",
    val format:    String            = "hls",
    val quality:   String            = "auto",
    val headers:   Map<String, String> = emptyMap(),
    val subtitles: List<Subtitle>    = emptyList(),
)

@Serializable
data class Subtitle(
    val url:      String = "",
    val language: String = "",
    val label:    String = "",
)

@Serializable
data class SkipTimes(
    val intro: TimeRange? = null,
    val outro: TimeRange? = null,
)

@Serializable
data class TimeRange(
    val start: Double = 0.0,
    val end:   Double = 0.0,
)

@Serializable
data class ProviderInfo(
    val id:       String       = "",
    val name:     String       = "",
    val language: String       = "",
    val types:    List<String> = emptyList(),
    val active:   Boolean      = true,
    val priority: Int          = 0,
)

// ── User data ──────────────────────────────────────────

@Serializable
data class WatchedMedia(
    @SerialName("media_id")  val mediaId:  String = "",
    val title:               String        = "",
    val episode:             Int           = 0,
    val provider:            String        = "",
    @SerialName("image_url") val imageUrl: String = "",
    @SerialName("watched_at") val watchedAt: String = "",
    val duration:            Int           = 0,
    val position:            Int           = 0,
    val completed:           Boolean       = false,
)

@Serializable
data class WatchProgress(
    @SerialName("media_id") val mediaId: String = "",
    val episode:  Int = 0,
    val position: Int = 0,
    val duration: Int = 0,
    val percent:  Int = 0,
)

@Serializable
data class DownloadItem(
    val id:       String = "",
    @SerialName("media_id") val mediaId: String = "",
    val title:    String = "",
    val episode:  Int    = 0,
    val status:   String = "",
    val progress: Int    = 0,
    @SerialName("file_path") val filePath: String = "",
    @SerialName("file_size") val fileSize: Long   = 0L,
    val downloaded: Long   = 0L,
    val speed:    String   = "",
    val eta:      String   = "",
    val error:    String   = "",
)

// ── UI State helpers ────────────────────────────────────

sealed class UiState<out T> {
    object Loading                         : UiState<Nothing>()
    data class Success<T>(val data: T)     : UiState<T>()
    data class Error(val message: String)  : UiState<Nothing>()
    object Empty                           : UiState<Nothing>()
}

data class PlayerState(
    val isPlaying:       Boolean   = false,
    val currentPosition: Long      = 0L,
    val duration:        Long      = 0L,
    val bufferedPosition: Long     = 0L,
    val isBuffering:     Boolean   = false,
    val skipTimes:       SkipTimes? = null,
    val currentEpisode:  Episode?  = null,
    val nextEpisode:     Episode?  = null,
    val isCasting:       Boolean   = false,
    val castDeviceName:  String    = "",
)
