package com.dendeplay.api

import com.dendeplay.domain.model.SearchResult
import com.dendeplay.domain.model.MediaDetails
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════
// DENDÊPLAY API UNIFICADA — v1.5 (beta)
//
// Camada central que abstrai local vs cloud.
// Para mudar de local para servidor: implemente CloudDataProvider
// e injete no lugar de LocalDataProvider.
//
// Integração futura com ARUAN IA:
//   aruanEndpoint = "http://seu-servidor/aruan"
//   api.setAruanEndpoint(aruanEndpoint)
//   api.getAIRecommendation("me recomende terror")
// ══════════════════════════════════════════════════════════

enum class AudioPreference { DUBBED, SUBBED, BOTH }

data class UserPreferences(
    val audioPreference: AudioPreference = AudioPreference.BOTH,
    val preferDubbed: Boolean            = true,
    val favoriteGenres: List<String>     = emptyList(),
    val preferredLanguage: String        = "pt-BR",
    val autoSkipIntro: Boolean           = true,
    val autoNextEpisode: Boolean         = true,
    val defaultQuality: String           = "auto",
)

data class Recommendation(
    val mediaId: String,
    val title:   String,
    val imageUrl: String,
    val provider: String,
    val mediaType: String,
    val reason:  String,   // "Porque você assistiu X"
    val score:   Float,    // 0.0–1.0
    val isFromAI: Boolean  = false,
)

data class UserBehavior(
    val mediaId:   String,
    val mediaType: String,
    val genre:     String,
    val watchedPct: Int,   // 0–100
    val completed:  Boolean,
    val timestamp:  Long = System.currentTimeMillis(),
)

// ── Interface do Provider de dados ────────────────────────

interface DataProvider {
    suspend fun getRecommendations(): List<Recommendation>
    suspend fun syncHistory(): Boolean
    suspend fun syncFavorites(): Boolean
    suspend fun syncProgress(): Boolean
    suspend fun sendUserBehavior(b: UserBehavior): Boolean
    suspend fun getAIRecommendation(query: String): List<Recommendation>
    fun isCloud(): Boolean
}

// ── Interface de Sincronização Cloud (futura) ─────────────

interface CloudSyncService {
    suspend fun connect(token: String): Boolean
    suspend fun pushHistory(): Boolean
    suspend fun pullHistory(): Boolean
    suspend fun pushFavorites(): Boolean
    suspend fun pullFavorites(): Boolean
    suspend fun pushProgress(): Boolean
    suspend fun pullProgress(): Boolean
    val isConnected: Boolean
}

// ── DendeAPI — ponto de entrada ───────────────────────────

@Singleton
class DendeAPI @Inject constructor(
    private val local: LocalDataProvider,
) {
    private var cloud: CloudSyncService? = null
    private var aruanEndpoint: String     = ""
    private val _events = MutableSharedFlow<APIEvent>(extraBufferCapacity = 16)
    val events: Flow<APIEvent> = _events.asSharedFlow()

    // Configurar endpoint da IA Aruan (para uso futuro)
    fun setAruanEndpoint(url: String) { aruanEndpoint = url }
    val hasAruan: Boolean get() = aruanEndpoint.isNotEmpty()

    // Configurar cloud sync (para uso futuro)
    fun setCloudSync(svc: CloudSyncService) { cloud = svc }
    val hasCloud: Boolean get() = cloud?.isConnected == true

    // Qual provider usar agora
    private val provider: DataProvider get() = local

    // ── Recomendações ──────────────────────────────────────

    suspend fun getRecommendations(): List<Recommendation> =
        runCatching { provider.getRecommendations() }.getOrElse { emptyList() }

    suspend fun getAIRecommendation(query: String): List<Recommendation> =
        runCatching { provider.getAIRecommendation(query) }.getOrElse { emptyList() }

    // ── Comportamento do usuário ──────────────────────────

    suspend fun recordBehavior(b: UserBehavior) {
        runCatching {
            local.sendUserBehavior(b)
            _events.emit(APIEvent.BehaviorRecorded(b))
        }
    }

    // ── Sincronização (no-op local, ativa quando cloud) ───

    suspend fun syncAll(): Boolean {
        if (!hasCloud) return true // local = sempre sincronizado
        return runCatching {
            val c = cloud!!
            c.pushHistory() && c.pushFavorites() && c.pushProgress()
        }.getOrElse { false }
    }

    // ── Preferências ──────────────────────────────────────

    fun getUserPreferences(): UserPreferences = local.getPreferences()
    fun savePreferences(p: UserPreferences)   = local.savePreferences(p)
}

// ── Eventos da API ────────────────────────────────────────

sealed class APIEvent {
    data class BehaviorRecorded(val b: UserBehavior) : APIEvent()
    data class RecommendationsUpdated(val list: List<Recommendation>) : APIEvent()
    object SyncCompleted : APIEvent()
    data class AruanResponse(val query: String, val results: List<Recommendation>) : APIEvent()
}
