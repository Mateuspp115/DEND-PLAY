package com.dendeplay.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Logo DENDÊPLAY fiel ao PNG do cliente — fireball + play escuro */
@Composable
fun DendeLogo(size: Dp = 44.dp, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.then(Modifier.size(size))) {
        val w  = this.size.width; val h = this.size.height
        val cx = w * .50f;        val cy = h * .52f

        val body = Path().apply {
            moveTo(cx, cy+h*.40f)
            cubicTo(cx-w*.38f,cy+h*.38f, cx-w*.46f,cy+h*.14f, cx-w*.34f,cy-h*.08f)
            cubicTo(cx-w*.28f,cy-h*.20f, cx-w*.14f,cy-h*.30f, cx-w*.02f,cy-h*.38f)
            cubicTo(cx+w*.12f,cy-h*.28f, cx+w*.28f,cy-h*.16f, cx+w*.34f,cy-h*.02f)
            cubicTo(cx+w*.44f,cy+h*.16f, cx+w*.40f,cy+h*.36f, cx,cy+h*.40f); close()
        }
        drawPath(body, Brush.linearGradient(listOf(Color(0xFFCC1500),Color(0xFFE03000),Color(0xFFFF5500),Color(0xFFFF8C00),Color(0xFFFFAA00)),
            Offset(cx-w*.2f,cy+h*.40f), Offset(cx+w*.1f,cy-h*.38f)))

        val lw = Path().apply {
            moveTo(cx-w*.34f,cy-h*.08f)
            cubicTo(cx-w*.46f,cy-h*.20f, cx-w*.44f,cy-h*.38f, cx-w*.28f,cy-h*.44f)
            cubicTo(cx-w*.20f,cy-h*.34f, cx-w*.22f,cy-h*.20f, cx-w*.20f,cy-h*.10f)
            cubicTo(cx-w*.26f,cy-h*.14f, cx-w*.30f,cy-h*.12f, cx-w*.34f,cy-h*.08f); close()
        }
        drawPath(lw, Brush.linearGradient(listOf(Color(0xFFCC1500),Color(0xFFE53A10)),
            Offset(cx-w*.44f,cy-h*.38f), Offset(cx-w*.20f,cy-h*.08f)))

        val rw = Path().apply {
            moveTo(cx+w*.34f,cy-h*.02f)
            cubicTo(cx+w*.44f,cy-h*.14f, cx+w*.44f,cy-h*.28f, cx+w*.34f,cy-h*.36f)
            cubicTo(cx+w*.28f,cy-h*.28f, cx+w*.30f,cy-h*.16f, cx+w*.30f,cy-h*.06f); close()
        }
        drawPath(rw, Color(0xFFDD2800).copy(alpha=.85f))

        val mf = Path().apply {
            moveTo(cx-w*.10f,cy-h*.38f)
            cubicTo(cx-w*.18f,cy-h*.52f, cx-w*.14f,cy-h*.66f, cx-w*.04f,cy-h*.74f)
            cubicTo(cx+w*.04f,cy-h*.62f, cx+w*.08f,cy-h*.50f, cx+w*.06f,cy-h*.40f)
            cubicTo(cx+w*.02f,cy-h*.44f, cx-w*.04f,cy-h*.42f, cx-w*.10f,cy-h*.38f); close()
        }
        drawPath(mf, Brush.linearGradient(listOf(Color(0xFFFF8C00),Color(0xFFFFB300),Color(0xFFFFD700),Color(0xFFFFE840)),
            Offset(cx,cy-h*.38f), Offset(cx-w*.04f,cy-h*.74f)))

        val hi = Path().apply {
            moveTo(cx+w*.08f,cy-h*.38f)
            cubicTo(cx+w*.14f,cy-h*.48f, cx+w*.16f,cy-h*.58f, cx+w*.10f,cy-h*.64f)
            cubicTo(cx+w*.06f,cy-h*.56f, cx+w*.06f,cy-h*.46f, cx+w*.08f,cy-h*.38f); close()
        }
        drawPath(hi, Brush.linearGradient(listOf(Color(0xFFFFAA00),Color(0xFFFFE040),Color(0xFFFFF8A0)),
            Offset(cx+w*.08f,cy-h*.38f), Offset(cx+w*.16f,cy-h*.64f)))

        val pL=cx-w*.12f; val pT=cy-h*.13f; val pB=cy+h*.13f; val pR=cx+w*.18f; val pM=(pT+pB)/2f
        val sh = Path().apply { moveTo(pL+2f,pT+2f); lineTo(pL+2f,pB+2f); lineTo(pR+2f,pM+2f); close() }
        drawPath(sh, Color(0x40000000))
        val pl = Path().apply { moveTo(pL,pT); lineTo(pL,pB); lineTo(pR,pM); close() }
        drawPath(pl, Color(0xEE0D0D12))
    }
}
