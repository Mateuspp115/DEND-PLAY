package com.dendeplay.player

import android.content.Context
import android.content.SharedPreferences
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

// ══════════════════════════════════════════════════════════
// QualityManager v1.7 — até 8K
//
// Detecta qualidades reais disponíveis no stream HLS/DASH
// e inclui 4K (2160p) e 8K (4320p) quando disponíveis.
// ══════════════════════════════════════════════════════════

enum class VideoQuality(val label: String, val maxHeight: Int, val badge: String = "") {
    AUTO  ("Auto",   Int.MAX_VALUE, ""),
    Q8K   ("8K",     4320,          "8K"),
    Q4K   ("4K",     2160,          "4K"),
    Q1440 ("1440p",  1440,          "2K"),
    Q1080 ("1080p",  1080,          "FHD"),
    Q720  ("720p",   720,           "HD"),
    Q480  ("480p",   480,           "SD"),
    Q360  ("360p",   360,           ""),
    Q240  ("240p",   240,           ""),
}

@Singleton
class QualityManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
) {
    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("quality_prefs", Context.MODE_PRIVATE)

    fun getPreference(): VideoQuality =
        runCatching {
            VideoQuality.valueOf(prefs.getString("quality", VideoQuality.AUTO.name)!!)
        }.getOrElse { VideoQuality.AUTO }

    fun savePreference(q: VideoQuality) {
        prefs.edit().putString("quality", q.name).apply()
    }

    @OptIn(UnstableApi::class)
    fun applyQuality(player: ExoPlayer, quality: VideoQuality) {
        val trackSelector = player.trackSelector as? DefaultTrackSelector ?: return

        if (quality == VideoQuality.AUTO) {
            val videoGroup = player.currentTracks.groups
                .firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
            if (videoGroup != null) {
                trackSelector.parameters = trackSelector.buildUponParameters()
                    .clearOverride(videoGroup.mediaTrackGroup)
                    .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                    .build()
            }
            return
        }

        // Encontrar track mais próxima da qualidade desejada
        val videoGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
        var bestGroup: androidx.media3.common.Tracks.Group? = null
        var bestIndex = -1
        var bestDiff  = Int.MAX_VALUE

        for (group in videoGroups) {
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val h = group.getTrackFormat(i).height
                if (h > 0) {
                    val diff = abs(h - quality.maxHeight)
                    if (diff < bestDiff) {
                        bestDiff = diff; bestGroup = group; bestIndex = i
                    }
                }
            }
        }

        if (bestGroup != null && bestIndex >= 0) {
            trackSelector.parameters = trackSelector.buildUponParameters()
                .addOverride(TrackSelectionOverride(bestGroup.mediaTrackGroup, bestIndex))
                .build()
        } else {
            trackSelector.parameters = trackSelector.buildUponParameters()
                .setMaxVideoSize(Int.MAX_VALUE, quality.maxHeight)
                .build()
        }
        savePreference(quality)
    }

    @OptIn(UnstableApi::class)
    fun getAvailableQualities(player: ExoPlayer): List<VideoQuality> {
        val available = mutableSetOf(VideoQuality.AUTO)
        val videoGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }

        for (group in videoGroups) {
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val h = group.getTrackFormat(i).height
                // Mapear altura para VideoQuality com tolerância de ±200px
                VideoQuality.entries
                    .firstOrNull { q -> q != VideoQuality.AUTO && abs(h - q.maxHeight) <= 200 }
                    ?.let { available += it }
                // Incluir 4K e 8K explicitamente (ordem: maior primeiro)
                when {
                    h >= 7680 -> { available += VideoQuality.Q8K; available += VideoQuality.Q4K }
                    h >= 3840 -> available += VideoQuality.Q4K
                }
            }
        }

        // Se stream HLS sem tracks enumeradas, oferecer opções comuns
        if (available.size == 1) {
            available += listOf(
                VideoQuality.Q1080, VideoQuality.Q720,
                VideoQuality.Q480, VideoQuality.Q360
            )
        }

        return available.sortedByDescending { it.maxHeight }
    }

    // Verificar se dispositivo suporta 4K (Display)
    fun deviceSupports4K(): Boolean {
        val dm = ctx.resources.displayMetrics
        return dm.heightPixels >= 2160 || dm.widthPixels >= 3840
    }
}
