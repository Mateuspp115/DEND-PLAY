package com.dendeplay.ui.genres

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dendeplay.domain.model.SearchResult
import com.dendeplay.ui.components.DendeLoadingIndicator
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.components.shimmerBrush
import com.dendeplay.ui.theme.DendeColors

// ══════════════════════════════════════════════════════════
// GenreTabsScreen — navegação por gênero com filtro de tipo
// ══════════════════════════════════════════════════════════

data class GenreTab(
    val id:    String,
    val label: String,
    val icon:  String,         // emoji de ícone representativo
    val color: Color,
    val searchTerms: List<String>, // termos para busca
)

val GENRE_TABS = listOf(
    GenreTab("trending", "Em Alta",    "fire",    DendeColors.Primary,        listOf("popular","trending")),
    GenreTab("action",   "Ação",       "sword",   Color(0xFFE53935),           listOf("ação","action")),
    GenreTab("horror",   "Terror",     "ghost",   Color(0xFF7B1FA2),           listOf("terror","horror","suspense")),
    GenreTab("comedy",   "Comédia",    "laugh",   Color(0xFFF57F17),           listOf("comédia","comedy")),
    GenreTab("romance",  "Romance",    "heart",   Color(0xFFE91E63),           listOf("romance","love")),
    GenreTab("thriller", "Suspense",   "eye",     Color(0xFF37474F),           listOf("suspense","thriller","crime")),
    GenreTab("animation","Animação",   "sparkles",DendeColors.FlameOrange,    listOf("animação","anime")),
    GenreTab("scifi",    "Ficção",     "rocket",  Color(0xFF1565C0),           listOf("ficção científica","sci-fi")),
    GenreTab("drama",    "Drama",      "masks",   Color(0xFF00695C),           listOf("drama")),
    GenreTab("docs",     "Docs",       "camera",  Color(0xFF4E342E),           listOf("documentário","documentary")),
    GenreTab("kids",     "Infantil",   "star",    Color(0xFF00897B),           listOf("infantil","kids","family")),
)

private val genreIcon = mapOf(
    "fire" to Icons.Rounded.LocalFireDepartment,
    "sword" to Icons.Rounded.SportsMartialArts,
    "ghost" to Icons.Rounded.Nightlight,
    "laugh" to Icons.Rounded.SentimentVerySatisfied,
    "heart" to Icons.Rounded.Favorite,
    "eye" to Icons.Rounded.RemoveRedEye,
    "sparkles" to Icons.Rounded.AutoAwesome,
    "rocket" to Icons.Rounded.RocketLaunch,
    "masks" to Icons.Rounded.TheaterComedy,
    "camera" to Icons.Rounded.Camera,
    "star" to Icons.Rounded.ChildCare,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GenreTabsScreen(
    onMediaClick: (SearchResult) -> Unit,
    vm: GenreTabsViewModel = hiltViewModel(),
) {
    val pager    = rememberPagerState(pageCount = { GENRE_TABS.size })
    val scope    = rememberCoroutineScope()
    val selected by vm.selectedFilter.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(DendeColors.Background)) {

        // ── Tabs scrolláveis ──────────────────────────────
        ScrollableTabRow(
            selectedTabIndex = pager.currentPage,
            containerColor   = DendeColors.Background,
            contentColor     = DendeColors.Primary,
            edgePadding      = 8.dp,
            indicator        = { tabPositions ->
                if (pager.currentPage < tabPositions.size)
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[pager.currentPage]).padding(horizontal = 12.dp),
                        color  = GENRE_TABS[pager.currentPage].color,
                        height = 2.5.dp
                    )
            },
            divider = {},
        ) {
            GENRE_TABS.forEachIndexed { i, tab ->
                val sel = pager.currentPage == i
                Tab(
                    selected  = sel,
                    onClick   = { scope.launch { pager.animateScrollToPage(i) } },
                    modifier  = Modifier.padding(horizontal = 4.dp),
                ) {
                    Row(
                        Modifier.padding(horizontal = 6.dp, vertical = 10.dp),
                        Arrangement.spacedBy(5.dp), Alignment.CenterVertically
                    ) {
                        Icon(
                            genreIcon[tab.icon] ?: Icons.Rounded.Movie,
                            null,
                            tint     = if (sel) tab.color else DendeColors.TextSub,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            tab.label,
                            color      = if (sel) tab.color else DendeColors.TextSub,
                            fontSize   = 12.sp,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }

        // ── Filtro de tipo ────────────────────────────────
        LaunchedEffect(pager.currentPage) { vm.loadGenre(GENRE_TABS[pager.currentPage]) }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            Arrangement.spacedBy(6.dp)
        ) {
            listOf("todos" to "Todos", "anime" to "Anime", "movie" to "Filmes", "tv" to "Séries").forEach { (k, v) ->
                FilterChip(
                    selected = selected == k,
                    onClick  = { vm.setFilter(k) },
                    label    = { Text(v, fontSize = 11.sp) },
                    shape    = RoundedCornerShape(20.dp),
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GENRE_TABS[pager.currentPage].color,
                        selectedLabelColor     = Color.White,
                        containerColor         = DendeColors.Card,
                        labelColor             = DendeColors.TextSub,
                    ),
                    border   = FilterChipDefaults.filterChipBorder(
                        enabled               = true,
                        selected              = selected == k,
                        selectedBorderColor   = GENRE_TABS[pager.currentPage].color,
                        borderColor           = DendeColors.SurfaceVar,
                    )
                )
            }
        }

        // ── Conteúdo do gênero (HorizontalPager) ─────────
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            GenrePage(
                tab       = GENRE_TABS[page],
                filter    = selected,
                vm        = vm,
                onClick   = onMediaClick,
            )
        }
    }
}

@Composable
private fun GenrePage(
    tab:     GenreTab,
    filter:  String,
    vm:      GenreTabsViewModel,
    onClick: (SearchResult) -> Unit,
) {
    val state by vm.state.collectAsStateWithLifecycle()

    when (val s = state) {
        is GenreUiState.Loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { DendeLoadingIndicator() }
        is GenreUiState.Error   -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Warning, null, tint = DendeColors.FlameOrange, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text(s.message, color = DendeColors.TextSub)
            }
        }
        is GenreUiState.Empty   -> Box(Modifier.fillMaxSize(), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.SearchOff, null, tint = DendeColors.TextHint, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text("Nenhum conteúdo encontrado", color = DendeColors.TextSub)
            }
        }
        is GenreUiState.Success -> {
            val items = when (filter) {
                "anime" -> s.items.filter { it.mediaType == "anime" }
                "movie" -> s.items.filter { it.mediaType == "movie" }
                "tv"    -> s.items.filter { it.mediaType == "tv" }
                else    -> s.items
            }
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Nenhum resultado para este filtro", color = DendeColors.TextSub)
                }
            } else {
                LazyVerticalGrid(
                    GridCells.Fixed(3),
                    contentPadding       = PaddingValues(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement  = Arrangement.spacedBy(12.dp),
                    modifier             = Modifier.fillMaxSize(),
                ) {
                    items(items, key = { it.provider + ":" + it.id }) { item ->
                        GenreCard(item, tab.color, onClick)
                    }
                }
            }
        }
    }
}

@Composable
private fun GenreCard(item: SearchResult, accentColor: Color, onClick: (SearchResult) -> Unit) {
    Column(Modifier.fillMaxWidth().dendeClickable { onClick(item) }) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(.7f)
                .clip(RoundedCornerShape(10.dp))
                .background(DendeColors.Card)
        ) {
            AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)

            // Badge de tipo
            Box(
                Modifier.align(Alignment.TopEnd).padding(4.dp)
                    .background(accentColor.copy(.85f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(
                    when (item.mediaType) { "movie" -> "Filme"; "tv" -> "Série"; else -> "Anime" },
                    color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold
                )
            }

            // Rating badge
            if (item.rating > 0)
                Box(
                    Modifier.align(Alignment.TopStart).padding(4.dp)
                        .background(Color.Black.copy(.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text("%.1f".format(item.rating), color = DendeColors.FlameGold, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }

            // Gradiente inferior
            Box(
                Modifier.fillMaxWidth().height(40.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f))))
            )

            // Badge "BR" para conteúdo em PT-BR
            if (item.language == "pt-BR")
                Box(
                    Modifier.align(Alignment.BottomStart).padding(5.dp)
                        .background(Color(0xFF007A33), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) { Text("BR", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black) }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            item.title, color = DendeColors.Text, fontSize = 10.5.sp,
            fontWeight = FontWeight.Medium, maxLines = 2,
            overflow = TextOverflow.Ellipsis, lineHeight = 13.sp
        )
    }
}
