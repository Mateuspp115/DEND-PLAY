package com.dendeplay.util

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.util.Log
import coil.Coil
import coil.imageLoader
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════
// LowMemoryWatcher — gerenciamento de memória
//
// Monitora alertas do Android sobre pressão de memória
// e libera caches progressivamente.
//
// Níveis de trimming (ComponentCallbacks2):
//   TRIM_MEMORY_UI_HIDDEN    (20) — app foi para background
//   TRIM_MEMORY_RUNNING_LOW  (10) — sistema com pouca memória
//   TRIM_MEMORY_MODERATE     (60) — moderado, liberar não crítico
//   TRIM_MEMORY_COMPLETE     (80) — liberar tudo que puder
// ══════════════════════════════════════════════════════════

@Singleton
class LowMemoryWatcher @Inject constructor(
    @ApplicationContext private val app: android.content.Context,
) {
    private val TAG = "LowMemoryWatcher"

    private val _isLowMemory = MutableStateFlow(false)
    val isLowMemory: StateFlow<Boolean> = _isLowMemory.asStateFlow()

    private val _memoryLevel = MutableStateFlow(MemoryLevel.NORMAL)
    val memoryLevel: StateFlow<MemoryLevel> = _memoryLevel.asStateFlow()

    // Registra como ComponentCallbacks2 para receber alertas do SO
    private val callbacks = object : ComponentCallbacks2 {
        override fun onTrimMemory(level: Int) {
            Log.d(TAG, "onTrimMemory level=$level")
            when {
                level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> {
                    _memoryLevel.value = MemoryLevel.CRITICAL
                    _isLowMemory.value = true
                    trimAll()
                }
                level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                    _memoryLevel.value = MemoryLevel.LOW
                    _isLowMemory.value = true
                    trimImages()
                }
                level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                    _memoryLevel.value = MemoryLevel.BACKGROUND
                    _isLowMemory.value = false
                    trimImagesLight()
                }
                level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                    _memoryLevel.value = MemoryLevel.LOW
                    _isLowMemory.value = true
                    trimImages()
                }
                else -> {
                    _memoryLevel.value = MemoryLevel.NORMAL
                    _isLowMemory.value = false
                }
            }
        }

        override fun onLowMemory() {
            Log.w(TAG, "onLowMemory — liberando tudo")
            _memoryLevel.value = MemoryLevel.CRITICAL
            _isLowMemory.value = true
            trimAll()
        }

        override fun onConfigurationChanged(c: Configuration) {}
    }

    fun register() {
        app.registerComponentCallbacks(callbacks)
        Log.d(TAG, "LowMemoryWatcher registrado")
    }

    fun unregister() {
        app.unregisterComponentCallbacks(callbacks)
    }

    // ── Ações de limpeza ──────────────────────────────────

    /** Limpa apenas memória de imagens em cache */
    private fun trimImagesLight() {
        runCatching { app.imageLoader.memoryCache?.trimToSize(app.imageLoader.memoryCache!!.size / 2) }
    }

    /** Limpa todo o cache de imagens em memória */
    private fun trimImages() {
        runCatching { app.imageLoader.memoryCache?.clear() }
        Log.d(TAG, "Cache de imagens limpo")
    }

    /** Libera todos os caches disponíveis */
    private fun trimAll() {
        trimImages()
        // Limpa cache de disco do Coil (apenas referências em memória)
        runCatching { app.imageLoader.memoryCache?.clear() }
        System.gc()
        Log.w(TAG, "Trim completo executado")
    }

    // ── Verificação proativa ──────────────────────────────

    fun isDeviceLowRam(): Boolean {
        val am = app.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        return am.isLowRamDevice
    }

    /** Retorna memória disponível em MB */
    fun getAvailableMemoryMB(): Long {
        val am   = app.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / 1_048_576
    }

    /** Retorna RAM total em MB */
    fun getTotalMemoryMB(): Long {
        val am   = app.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.totalMem / 1_048_576
    }
}

enum class MemoryLevel { NORMAL, BACKGROUND, LOW, CRITICAL }
