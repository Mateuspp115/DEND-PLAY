package com.dendeplay.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.dendeplay.R
import com.dendeplay.data.repository.MediaRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class DownloadForegroundService : Service() {

    @Inject lateinit var repository: MediaRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        const val ACTION_START   = "START_DOWNLOAD"
        const val ACTION_PAUSE   = "PAUSE_DOWNLOAD"
        const val ACTION_CANCEL  = "CANCEL_DOWNLOAD"

        // Broadcasts para o DownloadsViewModel
        const val ACTION_PROGRESS = "com.dendeplay.DOWNLOAD_PROGRESS"
        const val ACTION_COMPLETE = "com.dendeplay.DOWNLOAD_COMPLETE"
        const val ACTION_FAILED   = "com.dendeplay.DOWNLOAD_FAILED"

        const val EXTRA_ID    = "download_id"
        const val EXTRA_PCT   = "progress_pct"
        private const val NOTIFICATION_ID = 7001
        private const val CHANNEL_ID     = "dendeplay_downloads"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val dlId = intent?.getStringExtra(EXTRA_ID) ?: ""
        when (intent?.action) {
            ACTION_START -> {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, buildNotification("Baixando…"))
                startDownloadJob(dlId)
            }
            ACTION_PAUSE -> {
                repository.pauseDownload(dlId)
                broadcastProgress(dlId, -1)
                stopSelf()
            }
            ACTION_CANCEL -> {
                repository.cancelDownload(dlId)
                broadcastFailed(dlId)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startDownloadJob(dlId: String) {
        // Simulação de progresso via coroutine — sem Thread.sleep que bloqueia a VM
        // Implementação real: substituir pelo callback de repository.startDownload()
        serviceScope.launch {
            try {
                var pct = 0
                while (pct <= 100) {
                    delay(500)
                    pct += 5
                    broadcastProgress(dlId, pct)
                    withContext(Dispatchers.Main) {
                        updateNotification("Baixando… $pct%")
                    }
                }
                broadcastComplete(dlId)
            } catch (e: CancellationException) {
                broadcastFailed(dlId)
                throw e
            } catch (e: Exception) {
                broadcastFailed(dlId)
            } finally {
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    // ── Broadcasts para DownloadsViewModel ───────────────

    private fun broadcastProgress(id: String, pct: Int) {
        sendBroadcast(Intent(ACTION_PROGRESS).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_PCT, pct)
            setPackage(packageName)
        })
    }

    private fun broadcastComplete(id: String) {
        sendBroadcast(Intent(ACTION_COMPLETE).apply {
            putExtra(EXTRA_ID, id)
            setPackage(packageName)
        })
    }

    private fun broadcastFailed(id: String) {
        sendBroadcast(Intent(ACTION_FAILED).apply {
            putExtra(EXTRA_ID, id)
            setPackage(packageName)
        })
    }

    // ── Notificação ───────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Progresso de downloads do DENDÊPLAY"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DENDÊPLAY — Download")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_logo)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
