package com.dendeplay.ui.travel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class TravelItem(val id: String, val title: String, val sizeLabel: String, val quality: String)
data class TravelState(
    val isDownloading: Boolean = false, val overallProgress: Int = 0,
    val completedItems: Int = 0, val totalItems: Int = 0,
    val currentTitle: String = "", val speedLabel: String = "",
    val downloadedItems: List<TravelItem> = emptyList()
)

@HiltViewModel
class TravelViewModel @Inject constructor() : ViewModel() {
    private val _state    = MutableStateFlow(TravelState())
    private val _gb       = MutableStateFlow(2)
    private val _active   = MutableStateFlow(false)
    val state:   StateFlow<TravelState> = _state.asStateFlow()
    val gbReserved: StateFlow<Int>      = _gb.asStateFlow()
    val isActive: StateFlow<Boolean>    = _active.asStateFlow()

    fun setGB(gb: Int) { _gb.value = gb }
    fun toggleMode(on: Boolean) { _active.value = on }

    fun startDownload() {
        val total = when(_gb.value) { 10->30; 5->15; 2->6; else->3 }
        val titles = listOf("Naruto - Ep.135","One Piece - Ep.1112","AoT - Ep.28","Demon Slayer - Ep.8","Jujutsu Kaisen - Ep.24")
        val downloaded = mutableListOf<TravelItem>()
        viewModelScope.launch {
            _state.value = TravelState(isDownloading=true, totalItems=total)
            repeat(total) { i ->
                val t = titles[i % titles.size]
                _state.value = _state.value.copy(overallProgress=(i+1)*100/total, completedItems=i, currentTitle=t, speedLabel="${"%.1f".format(2.5f+i%3)} MB/s")
                delay(700)
                downloaded += TravelItem("ti_$i", t, "${280+i*30} MB", if(i%2==0) "1080p" else "720p")
                _state.value = _state.value.copy(downloadedItems=downloaded.toList())
            }
            _state.value = _state.value.copy(isDownloading=false, overallProgress=100, completedItems=total)
        }
    }
    fun deleteItem(id: String) { _state.update{it.copy(downloadedItems=it.downloadedItems.filter{i->i.id!=id})} }
}
