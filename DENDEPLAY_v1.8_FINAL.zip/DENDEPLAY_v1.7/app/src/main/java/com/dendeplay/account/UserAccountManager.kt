package com.dendeplay.account

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.activity.result.ActivityResultLauncher
import com.google.android.gms.auth.api.signin.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════
// UserAccountManager — conta Google (v1.5 beta)
//
// AGORA: Login com Google funciona, mas dados ficam apenas
//        no dispositivo. Nenhum dado vai para servidor.
//
// FUTURO: Implementar CloudSyncService e chamar syncAll()
//         quando servidor estiver disponível.
//
// Para ativar o Google Sign-In real:
//   1. Criar projeto no Firebase Console
//   2. Adicionar SHA-1 do keystore
//   3. Baixar google-services.json → app/
//   4. Substituir WEB_CLIENT_ID abaixo
// ══════════════════════════════════════════════════════════

private const val WEB_CLIENT_ID = "YOUR_GOOGLE_WEB_CLIENT_ID" // substituir ao ativar

data class UserAccount(
    val uid:       String  = "",
    val name:      String  = "",
    val email:     String  = "",
    val photoUrl:  String  = "",
    val isSignedIn: Boolean = false,
    val isPremium:  Boolean = false,   // para uso futuro
    val syncEnabled: Boolean = false,  // ativa quando servidor existir
)

@Singleton
class UserAccountManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
) {
    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("dendeplay_account", Context.MODE_PRIVATE)

    private val _account = MutableStateFlow(loadAccount())
    val account: StateFlow<UserAccount> = _account.asStateFlow()

    val isSignedIn: Boolean get() = _account.value.isSignedIn

    // ── Google Sign-In ─────────────────────────────────────

    private fun buildSignInClient(): GoogleSignInClient {
        val opts = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            // .requestIdToken(WEB_CLIENT_ID) // habilitar quando tiver servidor
            .build()
        return GoogleSignIn.getClient(ctx, opts)
    }

    // Retorna Intent para ser lançado pela Activity
    fun getSignInIntent(): Intent = buildSignInClient().signInIntent

    // Processa resultado do Google Sign-In
    fun handleSignInResult(data: Intent?): Result<UserAccount> {
        return runCatching {
            val task   = GoogleSignIn.getSignedInAccountFromIntent(data)
            val google = task.getResult(ApiException::class.java)
            val account = UserAccount(
                uid       = google.id ?: "",
                name      = google.displayName ?: "Usuário",
                email     = google.email ?: "",
                photoUrl  = google.photoUrl?.toString() ?: "",
                isSignedIn = true,
                syncEnabled = false, // servidor não disponível ainda
            )
            saveAccount(account)
            _account.value = account
            account
        }
    }

    // Verifica se já existe sessão ativa (sem mostrar UI)
    fun checkExistingSession() {
        val last = GoogleSignIn.getLastSignedInAccount(ctx)
        if (last != null && !isSignedIn) {
            val account = UserAccount(
                uid       = last.id ?: "",
                name      = last.displayName ?: "Usuário",
                email     = last.email ?: "",
                photoUrl  = last.photoUrl?.toString() ?: "",
                isSignedIn = true,
            )
            saveAccount(account)
            _account.value = account
        }
    }

    fun signOut() {
        buildSignInClient().signOut()
        val empty = UserAccount()
        saveAccount(empty)
        _account.value = empty
    }

    // ── Persistência local ────────────────────────────────

    private fun saveAccount(a: UserAccount) {
        prefs.edit()
            .putString("uid",    a.uid)
            .putString("name",   a.name)
            .putString("email",  a.email)
            .putString("photo",  a.photoUrl)
            .putBoolean("signed_in", a.isSignedIn)
            .apply()
    }

    private fun loadAccount(): UserAccount {
        if (!prefs.getBoolean("signed_in", false)) return UserAccount()
        return UserAccount(
            uid        = prefs.getString("uid",   "") ?: "",
            name       = prefs.getString("name",  "Usuário") ?: "Usuário",
            email      = prefs.getString("email", "") ?: "",
            photoUrl   = prefs.getString("photo", "") ?: "",
            isSignedIn = true,
        )
    }

    // ── Sincronização (estrutura para futuro) ─────────────

    /**
     * Sincroniza dados com servidor.
     * Por enquanto retorna true (no-op local).
     * Quando servidor existir: implementar e injetar CloudSyncService.
     */
    suspend fun syncToCloud(): SyncResult {
        if (!isSignedIn) return SyncResult.NotSignedIn
        if (!_account.value.syncEnabled) return SyncResult.ServerNotAvailable
        // TODO: chamar CloudSyncService quando disponível
        return SyncResult.Success
    }
}

enum class SyncResult {
    Success, NotSignedIn, ServerNotAvailable, Error
}
