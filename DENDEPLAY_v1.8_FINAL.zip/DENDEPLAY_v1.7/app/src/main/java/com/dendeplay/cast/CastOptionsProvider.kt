package com.dendeplay.cast

import android.content.Context
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.*
import com.google.android.gms.cast.framework.media.CastMediaOptions
import com.google.android.gms.cast.framework.media.MediaIntentReceiver
import com.google.android.gms.cast.framework.media.NotificationOptions

class CastOptionsProvider : OptionsProvider {
    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(
                CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID
            )
            .setCastMediaOptions(
                CastMediaOptions.Builder()
                    .setNotificationOptions(
                        NotificationOptions.Builder()
                            .setActions(
                                listOf(
                                    MediaIntentReceiver.ACTION_TOGGLE_PLAYBACK,
                                    MediaIntentReceiver.ACTION_DISCONNECT_CAST
                                ),
                                intArrayOf(0, 1)
                            )
                            .build()
                    )
                    .build()
            )
            .build()

    override fun getAdditionalSessionProviders(context: Context) = null
}
