package com.dendeplay

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import coil.Coil
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.dendeplay.util.LowMemoryWatcher
import dagger.hilt.android.HiltAndroidApp
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class DendePlayApp : Application() {

    @Inject lateinit var lowMemoryWatcher: LowMemoryWatcher

    override fun onCreate() {
        super.onCreate()
        setupCoil()
        lowMemoryWatcher.register()
    }

    // ── Coil com limites de cache explícitos ──────────────
    // Sem isso o cache cresce sem limite em uso intenso.
    // 50MB disco + 25MB memória é seguro para dispositivos 1-2GB RAM.
    private fun setupCoil() {
        val loader = ImageLoader.Builder(this)
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(50L * 1024 * 1024) // 50 MB
                    .build()
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20) // 20% da RAM disponível (máx ~50 MB)
                    .build()
            }
            .okHttpClient {
                OkHttpClient.Builder()
                    .connectTimeout(10, TimeUnit.SECONDS)
                    .readTimeout(15, TimeUnit.SECONDS)
                    .build()
            }
            .respectCacheHeaders(false) // provedores de anime têm headers ruins
            .crossfade(true)
            .build()
        Coil.setImageLoader(loader)
    }

    // ── LowMemoryWatcher — libera caches quando memória baixa ──
    // onTrimMemory() é chamado pelo SO antes de matar o processo.
    // Dispositivos Moto G35, A32, A10, J5 se beneficiam muito disso.
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when (level) {
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL,
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> {
                // Situação crítica: libera tudo que puder
                Coil.imageLoader(this).memoryCache?.clear()
            }
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW,
            ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                // Pressão moderada: libera metade do cache de imagens
                Coil.imageLoader(this).memoryCache?.trimToSize(
                    Coil.imageLoader(this).memoryCache?.maxSize?.div(2) ?: 0
                )
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Coil.imageLoader(this).memoryCache?.clear()
    }

    override fun onTerminate() {
        super.onTerminate()
        lowMemoryWatcher.unregister()
    }
}
