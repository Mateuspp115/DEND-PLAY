package com.dendeplay.cast

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.theme.DendeColors

fun castTypeIcon(type: CastType) = when (type) {
    CastType.CHROMECAST    -> Icons.Rounded.Cast
    CastType.DLNA          -> Icons.Rounded.Tv
    CastType.SAMSUNG_TIZEN -> Icons.Rounded.Tv
    CastType.LG_WEBOS      -> Icons.Rounded.Tv
    CastType.ROKU          -> Icons.Rounded.OndemandVideo
    CastType.ANDROID_TV    -> Icons.Rounded.Tv
}

fun castTypeLabel(type: CastType) = when (type) {
    CastType.CHROMECAST    -> "Google Cast"
    CastType.DLNA          -> "DLNA / UPnP"
    CastType.SAMSUNG_TIZEN -> "Samsung Tizen"
    CastType.LG_WEBOS      -> "LG webOS"
    CastType.ROKU          -> "Roku TV"
    CastType.ANDROID_TV    -> "Android TV"
}

fun castTypeColor(type: CastType) = when (type) {
    CastType.CHROMECAST    -> Color(0xFF4285F4)
    CastType.SAMSUNG_TIZEN -> Color(0xFF1428A0)
    CastType.LG_WEBOS      -> Color(0xFFC0392B)
    CastType.ROKU          -> Color(0xFF662D8C)
    CastType.ANDROID_TV    -> Color(0xFF4CAF50)
    CastType.DLNA          -> DendeColors.Primary
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CastPickerSheet(
    devices:     List<CastDevice>,
    state:       CastPlaybackState,
    discovering: Boolean,
    onConnect:   (CastDevice) -> Unit,
    onDisconnect: () -> Unit,
    onRefresh:   () -> Unit,
    onDismiss:   () -> Unit,
    onPowerSaveToggle: (Boolean) -> Unit = {},
) {
    val rotAnim = rememberInfiniteTransition(label="rot")
    val rot by rotAnim.animateFloat(0f, 360f, infiniteRepeatable(tween(1000, easing=LinearEasing)), label="r")

    ModalBottomSheet(onDismissRequest=onDismiss, containerColor=DendeColors.Surface,
        dragHandle={ Box(Modifier.padding(vertical=10.dp).size(40.dp,4.dp).clip(CircleShape).background(DendeColors.SurfaceVar)) }) {
        Column(Modifier.fillMaxWidth().padding(horizontal=16.dp).navigationBarsPadding()) {
            // Header
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Column {
                    Text("Enviar para TV", color=DendeColors.Text, fontSize=18.sp, fontWeight=FontWeight.Black)
                    Text(if(discovering)"Procurando..." else "${devices.size} dispositivo(s)",
                        color=DendeColors.TextSub, fontSize=11.sp)
                }
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    if(state.isConnected) TextButton(onDisconnect){ Text("Desconectar",color=DendeColors.Error,fontSize=12.sp) }
                    IconButton(onRefresh){ Icon(Icons.Rounded.Refresh, null, tint=DendeColors.Primary,
                        modifier=Modifier.size(20.dp).then(if(discovering) Modifier.rotate(rot) else Modifier)) }
                }
            }
            Spacer(Modifier.height(12.dp))

            // Conectado
            if(state.isConnected) ConnectedCard(state)
            if(discovering) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(1.dp)),color=DendeColors.Primary,trackColor=DendeColors.SurfaceVar) }
            Spacer(Modifier.height(10.dp))

            // Dispositivos
            val groups = devices.groupBy{it.type}
            val order = listOf(CastType.CHROMECAST,CastType.ANDROID_TV,CastType.SAMSUNG_TIZEN,CastType.LG_WEBOS,CastType.ROKU,CastType.DLNA)

            if(devices.isEmpty() && !discovering) {
                Box(Modifier.fillMaxWidth().padding(vertical=24.dp), Alignment.Center) {
                    Column(horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.WifiOff,null,tint=DendeColors.TextHint,modifier=Modifier.size(40.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Nenhum dispositivo na rede",color=DendeColors.TextSub,fontSize=13.sp)
                        Text("Verifique se sua TV esta no mesmo Wi-Fi",color=DendeColors.TextHint,fontSize=11.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onRefresh,border=BorderStroke(1.dp,DendeColors.Primary),colors=ButtonDefaults.outlinedButtonColors(contentColor=DendeColors.Primary)){
                            Text("Procurar novamente",fontSize=12.sp) }
                    }
                }
            } else {
                LazyColumn(verticalArrangement=Arrangement.spacedBy(4.dp), modifier=Modifier.heightIn(max=360.dp)) {
                    order.forEach { type ->
                        val group = groups[type] ?: return@forEach
                        item { Text(castTypeLabel(type).uppercase(), color=castTypeColor(type),
                            fontSize=10.sp, fontWeight=FontWeight.Black, letterSpacing=1.5.sp,
                            modifier=Modifier.padding(horizontal=4.dp,vertical=5.dp)) }
                        items(group,key={it.id}) { dev ->
                            DeviceRow(dev, state.isConnected && state.deviceName==dev.name) { onConnect(dev) }
                        }
                    }
                }
            }

            // Power Save toggle
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color=DendeColors.SurfaceVar)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(DendeColors.Card)
                .clickable{onPowerSaveToggle(!state.isPowerSaveOff)}.padding(14.dp),
                Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                Icon(if(state.isPowerSaveOff) Icons.Rounded.BatteryFull else Icons.Rounded.BatterySaver,null,
                    tint=if(state.isPowerSaveOff) DendeColors.Primary else DendeColors.TextSub, modifier=Modifier.size(22.dp))
                Column(Modifier.weight(1f)) {
                    Text("Desativar Economia de Energia",color=DendeColors.Text,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
                    Text("Mantém CPU ativa. Recomendado para TVs que desligam automaticamente.",
                        color=DendeColors.TextHint,fontSize=10.sp,lineHeight=14.sp)
                }
                Switch(state.isPowerSaveOff, onPowerSaveToggle,
                    colors=SwitchDefaults.colors(checkedThumbColor=DendeColors.Background,checkedTrackColor=DendeColors.Primary,
                        uncheckedThumbColor=DendeColors.TextSub,uncheckedTrackColor=DendeColors.SurfaceVar))
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun ConnectedCard(state: CastPlaybackState) {
    val col = state.deviceType?.let{castTypeColor(it)} ?: DendeColors.Primary
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(col.copy(.12f))
        .border(1.dp,col.copy(.4f),RoundedCornerShape(12.dp)).padding(14.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(col.copy(.2f),CircleShape), Alignment.Center) {
            Icon(state.deviceType?.let{castTypeIcon(it)}?:Icons.Rounded.Tv, null, tint=col, modifier=Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(state.deviceName,color=DendeColors.Text,fontSize=14.sp,fontWeight=FontWeight.Bold)
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(4.dp)){
                Box(Modifier.size(6.dp).background(DendeColors.Success,CircleShape))
                Text(if(state.isPlaying)"Reproduzindo" else "Conectado",color=DendeColors.Success,fontSize=11.sp)
            }
            if(state.currentTitle.isNotEmpty()) Text(state.currentTitle,color=DendeColors.TextSub,fontSize=10.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun DeviceRow(device: CastDevice, active: Boolean, onClick: () -> Unit) {
    val col = castTypeColor(device.type)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
        .background(if(active) col.copy(.1f) else DendeColors.Card)
        .dendeClickable(onClick=onClick).padding(12.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(DendeColors.Surface,CircleShape), Alignment.Center){
            Icon(castTypeIcon(device.type),null, tint=if(active) col else DendeColors.TextSub, modifier=Modifier.size(18.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(device.name,color=DendeColors.Text,fontSize=13.sp,fontWeight=FontWeight.SemiBold)
            Text(buildString{
                append(castTypeLabel(device.type))
                if(device.address.isNotEmpty()) append(" · ${device.address}")
                if(device.latencyMs>0) append(" · ${device.latencyMs}ms")
            }, color=DendeColors.TextHint, fontSize=10.sp)
        }
        if(active) Box(Modifier.background(col,RoundedCornerShape(20.dp)).padding(horizontal=8.dp,vertical=4.dp)){
            Text("Ativo",color=Color.Black,fontSize=10.sp,fontWeight=FontWeight.Bold)
        } else Icon(Icons.Rounded.ChevronRight,null,tint=DendeColors.TextHint,modifier=Modifier.size(16.dp))
    }
}
