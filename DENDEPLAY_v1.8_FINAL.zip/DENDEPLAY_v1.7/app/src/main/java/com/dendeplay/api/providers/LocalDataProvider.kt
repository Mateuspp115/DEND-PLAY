package com.dendeplay.api.providers

import android.content.Context
import android.content.SharedPreferences
import com.dendeplay.api.*
import com.dendeplay.data.repository.MediaRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.roundToInt
import kotlin.random.Random

// ══════════════════════════════════════════════════════════
// LocalDataProvider — implementação 100% offline
//
// Recomendações baseadas em:
//   - Histórico local do usuário
//   - Gêneros mais assistidos (PredictiveCache do SDK)
//   - Score simples de similaridade por gênero
//
// Quando ARUAN IA estiver disponível, override getAIRecommendation()
// apontando para o endpoint do servidor.
// ══════════════════════════════════════════════════════════

@Singleton
class LocalDataProvider @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val repo: MediaRepository,
    private val gson: Gson,
) : DataProvider {

    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("dendeplay_api_prefs", Context.MODE_PRIVATE)

    // ── Recomendações ──────────────────────────────────────

    override suspend fun getRecommendations(): List<Recommendation> =
        withContext(Dispatchers.Default) {
            val favGenres = getFavoriteGenres()
            val history   = getWatchedIds()
            val pref      = getPreferences()

            // Busca conteúdo dos gêneros favoritos
            val candidates = mutableListOf<Recommendation>()
            favGenres.take(3).forEach { genre ->
                repo.searchByType(genre, if (pref.audioPreference == AudioPreference.DUBBED) "dubbed" else "anime")
                    .getOrElse { emptyList() }
                    .filterNot { it.id in history }
                    .take(5)
                    .forEach { r ->
                        candidates += Recommendation(
                            mediaId   = r.id,
                            title     = r.title,
                            imageUrl  = r.imageUrl,
                            provider  = r.provider,
                            mediaType = r.mediaType,
                            reason    = "Porque você curte $genre",
                            score     = 0.8f + Random.nextFloat() * 0.2f,
                        )
                    }
            }

            // Trending como fallback
            if (candidates.size < 5) {
                repo.getTrending("anime")
                    .getOrElse { emptyList() }
                    .filterNot { it.id in history }
                    .take(10 - candidates.size)
                    .forEach { r ->
                        candidates += Recommendation(
                            mediaId   = r.id,
                            title     = r.title,
                            imageUrl  = r.imageUrl,
                            provider  = r.provider,
                            mediaType = r.mediaType,
                            reason    = "Em alta agora",
                            score     = 0.6f + Random.nextFloat() * 0.2f,
                        )
                    }
            }

            candidates.sortedByDescending { it.score }
        }

    // ── IA local simulada ─────────────────────────────────
    // Quando ARUAN estiver disponível, substituir por chamada HTTP

    override suspend fun getAIRecommendation(query: String): List<Recommendation> =
        withContext(Dispatchers.Default) {
            val lq = query.lowercase()
            val genre = when {
                lq.contains("terror") || lq.contains("horror") -> "Terror"
                lq.contains("ação")   || lq.contains("action") -> "Ação"
                lq.contains("comédia")|| lq.contains("comedy") -> "Comédia"
                lq.contains("romance")                          -> "Romance"
                lq.contains("suspense")|| lq.contains("thriller") -> "Suspense"
                lq.contains("ficção") || lq.contains("sci-fi") -> "Ficção Científica"
                lq.contains("animação")|| lq.contains("anime") -> "Animação"
                lq.contains("drama")                            -> "Drama"
                lq.contains("infantil")|| lq.contains("kids")  -> "Infantil"
                else -> "Ação"
            }

            repo.searchByType(genre, "anime")
                .getOrElse { emptyList() }
                .take(8)
                .map { r ->
                    Recommendation(
                        mediaId   = r.id,
                        title     = r.title,
                        imageUrl  = r.imageUrl,
                        provider  = r.provider,
                        mediaType = r.mediaType,
                        reason    = "ARUAN: resultado para \"$query\"",
                        score     = 0.75f + Random.nextFloat() * 0.25f,
                        isFromAI  = true,
                    )
                }
        }

    // ── Comportamento ─────────────────────────────────────

    override suspend fun sendUserBehavior(b: UserBehavior): Boolean {
        // Salva localmente para aprendizado
        val behaviors = getSavedBehaviors().toMutableList()
        behaviors.add(b)
        // Mantém últimos 500
        val trimmed = if (behaviors.size > 500) behaviors.takeLast(500) else behaviors
        prefs.edit().putString("behaviors", gson.toJson(trimmed)).apply()

        // Atualiza contagem de gêneros
        if (b.watchedPct >= 70) { // considerado "gostou"
            val counts = getGenreCounts().toMutableMap()
            counts[b.genre] = (counts[b.genre] ?: 0) + 1
            prefs.edit().putString("genre_counts", gson.toJson(counts)).apply()
        }
        return true
    }

    // ── Sync (no-op local) ────────────────────────────────

    override suspend fun syncHistory():   Boolean = true
    override suspend fun syncFavorites(): Boolean = true
    override suspend fun syncProgress():  Boolean = true
    override fun isCloud(): Boolean = false

    // ── Preferências ──────────────────────────────────────

    fun getPreferences(): UserPreferences {
        val json = prefs.getString("user_prefs", null) ?: return UserPreferences()
        return runCatching { gson.fromJson(json, UserPreferences::class.java) }
            .getOrElse { UserPreferences() }
    }

    fun savePreferences(p: UserPreferences) {
        prefs.edit().putString("user_prefs", gson.toJson(p)).apply()
    }

    // ── Helpers internos ──────────────────────────────────

    fun getFavoriteGenres(): List<String> {
        val counts = getGenreCounts()
        return counts.entries.sortedByDescending { it.value }.map { it.key }.take(5)
            .ifEmpty { listOf("Ação", "Comédia", "Romance") }
    }

    fun getSurpriseWeights(): Map<String, Float> {
        val counts = getGenreCounts()
        val total  = counts.values.sum().toFloat().coerceAtLeast(1f)
        return counts.mapValues { (_, c) -> c / total }
    }

    private fun getGenreCounts(): Map<String, Int> {
        val json = prefs.getString("genre_counts", null) ?: return emptyMap()
        return runCatching {
            gson.fromJson<Map<String, Int>>(json, object : TypeToken<Map<String, Int>>(){}.type)
        }.getOrElse { emptyMap() }
    }

    private fun getWatchedIds(): Set<String> {
        // Combina favoritos + histórico para filtrar conteúdo já conhecido
        // getContinueWatching usa o SDK síncrono (stub retorna lista local)
        val favs    = runCatching { repo.getFavorites().map { it.id } }.getOrElse { emptyList() }
        val history = runCatching { repo.getDownloads().map { it.mediaId } }.getOrElse { emptyList() }
        return (favs + history).toSet()
    }

    private fun getSavedBehaviors(): List<UserBehavior> {
        val json = prefs.getString("behaviors", null) ?: return emptyList()
        return runCatching {
            gson.fromJson<List<UserBehavior>>(json, object : TypeToken<List<UserBehavior>>(){}.type)
        }.getOrElse { emptyList() }
    }
}
