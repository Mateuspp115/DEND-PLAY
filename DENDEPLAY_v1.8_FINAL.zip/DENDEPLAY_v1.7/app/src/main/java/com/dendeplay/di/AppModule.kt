package com.dendeplay.di

import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.dendeplay.account.UserAccountManager
import com.dendeplay.api.DendeAPI
import com.dendeplay.api.providers.LocalDataProvider
import com.dendeplay.player.QualityManager
import com.dendeplay.player.SkipIntroManager
import com.dendeplay.cast.AdvancedCastManager
import com.dendeplay.data.repository.DendeSDKWrapper
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.util.LowMemoryWatcher
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDendeSDK(): DendeSDKWrapper = object : DendeSDKWrapper {
        override fun searchUniversal(q: String)                          = "[]"
        override fun searchByType(q: String, t: String)                  = "[]"
        override fun getMediaDetails(id: String, p: String)              = "{}"
        override fun getEpisodes(url: String, p: String)                 = "[]"
        override fun getVideoSources(url: String, p: String, ep: Int)    = "[]"
        override fun getTrending(t: String)                              = "[]"
        override fun getLatestEpisodes()                                 = "[]"
        override fun getSkipTimes(mal: Int, ep: Int)                     = "{}"
        override fun getHistory()                                        = "[]"
        override fun addToHistory(j: String)                             = """{"ok":true}"""
        override fun getFavorites()                                      = "[]"
        override fun addToFavorites(j: String)                          = """{"ok":true}"""
        override fun removeFromFavorites(id: String)                    = """{"ok":true}"""
        override fun getProgress(id: String, ep: Int)                   = "{}"
        override fun updateProgress(id: String, ep: Int, p: Int, d: Int) = """{"ok":true}"""
        override fun startDownload(mid: String, url: String, q: String, t: String, ep: Int) = """{"id":"0"}"""
        override fun getDownloads()                                      = "[]"
        override fun pauseDownload(id: String)                          = """{"ok":true}"""
        override fun resumeDownload(id: String)                         = """{"ok":true}"""
        override fun cancelDownload(id: String)                         = """{"ok":true}"""
        override fun getDownloadProgress(id: String)                    = 0
        override fun clearCache()                                       {}
        override fun getProviderCount()                                  = 26
        override fun getVersion()                                        = "1.7.0"
    }

    @Provides @Singleton
    fun provideGson(): Gson = GsonBuilder().setLenient().create()

    @Provides @Singleton
    fun provideMediaRepository(sdk: DendeSDKWrapper, gson: Gson): MediaRepository =
        MediaRepository(sdk, gson)

    @Provides @Singleton
    fun provideAdvancedCastManager(@ApplicationContext ctx: Context): AdvancedCastManager {
        val castManager = AdvancedCastManager(ctx).also { it.init() }
        // Libera recursos (coroutines, WakeLock, MulticastLock) quando o processo termina
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                castManager.destroy()
            }
        })
        return castManager
    }

    @Provides @Singleton
    fun provideLocalDataProvider(
        @ApplicationContext ctx: Context,
        repo: MediaRepository,
        gson: Gson,
    ): LocalDataProvider = LocalDataProvider(ctx, repo, gson)

    @Provides @Singleton
    fun provideDendeAPI(local: LocalDataProvider): DendeAPI = DendeAPI(local)

    @Provides @Singleton
    fun provideUserAccountManager(@ApplicationContext ctx: Context): UserAccountManager =
        UserAccountManager(ctx).also { it.checkExistingSession() }

    @Provides @Singleton
    fun provideSkipIntroManager(
        @ApplicationContext ctx: Context,
        gson: Gson,
    ): SkipIntroManager = SkipIntroManager(ctx, gson)

    @Provides @Singleton
    fun provideQualityManager(
        @ApplicationContext ctx: Context,
    ): QualityManager = QualityManager(ctx)

    @Provides @Singleton
    fun provideLowMemoryWatcher(
        @ApplicationContext ctx: Context,
    ): LowMemoryWatcher = LowMemoryWatcher(ctx)
}
