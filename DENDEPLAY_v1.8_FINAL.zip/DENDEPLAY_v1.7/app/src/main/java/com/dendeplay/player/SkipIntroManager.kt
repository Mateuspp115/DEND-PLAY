package com.dendeplay.player

import android.content.Context
import android.content.SharedPreferences
import com.dendeplay.domain.model.SkipTimes
import com.google.gson.Gson
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class SkipWindow(
    val start:  Double     = 0.0,
    val end:    Double     = 0.0,
    val type:   SkipType   = SkipType.INTRO,
    val source: SkipSource = SkipSource.ANISKIP,
)

enum class SkipType   { INTRO, OUTRO, RECAP }
enum class SkipSource { ANISKIP, PATTERN, AI, USER_DEFINED }

data class SkipStats(
    val mediaId:    String  = "",
    val skipCount:  Int     = 0,
    val watchCount: Int     = 0,
    val autoSkip:   Boolean = false,
    val lastUpdate: Long    = 0L,
)

@Singleton
class SkipIntroManager @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val gson: Gson,
) {
    private val prefs: SharedPreferences =
        ctx.getSharedPreferences("skip_prefs", Context.MODE_PRIVATE)

    // Após 3 skips seguidos → sugere "pular sempre?"
    private val AUTO_SKIP_THRESHOLD = 3

    // ── Obter janelas de skip ─────────────────────────────

    fun getSkipWindows(
        mediaType: String,
        duration:  Long,
        skipTimes: SkipTimes?,
    ): List<SkipWindow> {
        val windows = mutableListOf<SkipWindow>()

        // 1. AniSkip (mais preciso para animes)
        skipTimes?.intro?.let { i ->
            if (i.end > i.start) windows += SkipWindow(i.start, i.end, SkipType.INTRO, SkipSource.ANISKIP)
        }
        skipTimes?.outro?.let { o ->
            if (o.end > o.start) windows += SkipWindow(o.start, o.end, SkipType.OUTRO, SkipSource.ANISKIP)
        }

        // 2. Fallback por padrão temporal quando AniSkip não tem dados
        if (windows.isEmpty() && duration > 0) {
            windows += estimateByPattern(mediaType, duration / 1000.0)
        }
        return windows
    }

    /** Heurísticas por tipo e duração */
    private fun estimateByPattern(type: String, durSec: Double): List<SkipWindow> {
        val w = mutableListOf<SkipWindow>()
        when {
            type == "anime" && durSec < 1800 -> {  // anime curto (~23 min)
                val outroStart = (durSec - 100).coerceAtLeast(96.0)
                val outroEnd   = (durSec - 5).coerceAtLeast(outroStart + 1.0)
                w += SkipWindow(5.0, 95.0.coerceAtMost(outroStart - 1), SkipType.INTRO, SkipSource.PATTERN)
                w += SkipWindow(outroStart, outroEnd, SkipType.OUTRO, SkipSource.PATTERN)
            }
            type == "anime" -> {                   // anime longo / OVA
                val outroStart = (durSec - 120).coerceAtLeast(121.0)
                val outroEnd   = (durSec - 5).coerceAtLeast(outroStart + 1.0)
                w += SkipWindow(5.0, 120.0, SkipType.INTRO, SkipSource.PATTERN)
                w += SkipWindow(outroStart, outroEnd, SkipType.OUTRO, SkipSource.PATTERN)
            }
            type == "tv" -> {                      // série live-action
                val outroStart = (durSec - 90).coerceAtLeast(31.0)
                w += SkipWindow(0.0, 30.0, SkipType.INTRO, SkipSource.PATTERN)
                w += SkipWindow(outroStart, durSec, SkipType.OUTRO, SkipSource.PATTERN)
            }
            type == "movie" && durSec > 3600 -> {  // filme longo
                val outroStart = (durSec - 300).coerceAtLeast(181.0)
                w += SkipWindow(0.0, 180.0, SkipType.INTRO, SkipSource.PATTERN)
                w += SkipWindow(outroStart, durSec, SkipType.OUTRO, SkipSource.PATTERN)
            }
        }
        return w
    }

    // ── Posição atual está em janela de skip? ─────────────

    fun currentWindow(posMs: Long, windows: List<SkipWindow>): SkipWindow? {
        val s = posMs / 1000.0
        return windows.firstOrNull { w -> s >= (w.start - 2.0) && s < w.end }
    }

    // ── Aprendizado por série ─────────────────────────────

    fun recordSkip(mediaId: String) {
        val st = stats(mediaId)
        save(mediaId, st.copy(skipCount = st.skipCount+1, lastUpdate = System.currentTimeMillis()))
    }

    fun recordWatch(mediaId: String) {
        val st = stats(mediaId)
        save(mediaId, st.copy(watchCount = st.watchCount+1))
    }

    fun shouldAutoSkip(mediaId: String): Boolean = stats(mediaId).autoSkip
    fun setAutoSkip(mediaId: String, on: Boolean) { save(mediaId, stats(mediaId).copy(autoSkip=on)) }

    fun shouldSuggestAutoSkip(mediaId: String): Boolean {
        val st = stats(mediaId)
        return !st.autoSkip && st.skipCount >= AUTO_SKIP_THRESHOLD && st.skipCount > st.watchCount * 2
    }

    // Stub para futura integração com ARUAN IA
    suspend fun requestAruanDetection(mediaId: String, videoUrl: String, duration: Long): List<SkipWindow> = emptyList()

    // ── Persistência ──────────────────────────────────────
    private fun stats(id: String): SkipStats =
        runCatching { gson.fromJson(prefs.getString("skip_$id", null), SkipStats::class.java) }.getOrElse { SkipStats(id) }
    private fun save(id: String, st: SkipStats) =
        prefs.edit().putString("skip_$id", gson.toJson(st)).apply()
}
