package com.dendeplay.ui.genres

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.SearchResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

sealed class GenreUiState {
    object Loading                              : GenreUiState()
    object Empty                                : GenreUiState()
    data class Success(val items: List<SearchResult>) : GenreUiState()
    data class Error(val message: String)       : GenreUiState()
}

@HiltViewModel
class GenreTabsViewModel @Inject constructor(
    private val repo: MediaRepository,
) : ViewModel() {

    private val _state          = MutableStateFlow<GenreUiState>(GenreUiState.Loading)
    private val _selectedFilter = MutableStateFlow("todos")

    val state:          StateFlow<GenreUiState> = _state.asStateFlow()
    val selectedFilter: StateFlow<String>       = _selectedFilter.asStateFlow()

    // Cache por gênero para não refazer requisições ao trocar de aba
    private val cache = mutableMapOf<String, List<SearchResult>>()
    private var currentJob: Job? = null

    fun setFilter(f: String) { _selectedFilter.value = f }

    fun loadGenre(tab: GenreTab) {
        val cached = cache[tab.id]
        if (cached != null) {
            _state.value = if (cached.isEmpty()) GenreUiState.Empty else GenreUiState.Success(cached)
            return
        }

        currentJob?.cancel()
        currentJob = viewModelScope.launch {
            _state.value = GenreUiState.Loading

            // Busca em paralelo por todos os termos do gênero
            val results = mutableListOf<SearchResult>()
            val jobs = tab.searchTerms.map { term ->
                async {
                    withTimeoutOrNull(8_000) {
                        repo.searchUniversal(term).getOrElse { emptyList() }
                    } ?: emptyList()
                }
            }

            // Também busca trending se for a aba "Em Alta"
            if (tab.id == "trending") {
                val trending = async { repo.getTrending("anime").getOrElse { emptyList() } }
                results.addAll(trending.await())
            }

            jobs.forEach { results.addAll(it.await()) }

            // Deduplica por título
            val deduped = results
                .distinctBy { it.title.lowercase().trim() }
                .sortedByDescending { it.rating }
                .take(60)

            cache[tab.id] = deduped
            _state.value = if (deduped.isEmpty()) GenreUiState.Empty else GenreUiState.Success(deduped)
        }
    }

    fun clearCache() { cache.clear() }

    override fun onCleared() {
        super.onCleared()
        currentJob?.cancel()
    }
}
