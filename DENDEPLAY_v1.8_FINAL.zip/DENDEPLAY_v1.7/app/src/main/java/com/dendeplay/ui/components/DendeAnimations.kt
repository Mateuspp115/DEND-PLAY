package com.dendeplay.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.*
import com.dendeplay.ui.theme.DendeColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

val DendeEasing = CubicBezierEasing(0.2f, 0.9f, 0.4f, 1.1f)

@Composable
fun Modifier.dendeClickable(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val scale       = remember { Animatable(1f) }
    val scope       = rememberCoroutineScope()
    val interactionSource = remember { MutableInteractionSource() }
    return this
        .scale(scale.value)
        .clickable(
            interactionSource = interactionSource,
            indication        = ripple(color = DendeColors.RippleGold),
            enabled           = enabled,
        ) {
            scope.launch { scale.animateTo(.95f, spring(Spring.DampingRatioNoBouncy, Spring.StiffnessHigh)) }
            scope.launch { scale.animateTo(1f,   spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }
            onClick()
        }
}

@Composable
fun shimmerBrush(): Brush {
    val t = rememberInfiniteTransition(label="sh")
    val x by t.animateFloat(0f, 1200f, infiniteRepeatable(tween(1200, easing=LinearEasing)), label="sx")
    return Brush.linearGradient(listOf(DendeColors.SurfaceVar, DendeColors.Surface, DendeColors.SurfaceVar),
        Offset(x-400, 0f), Offset(x, 0f))
}

@Composable
fun DendeLoadingIndicator(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label="li")
    val arc by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing=LinearEasing)), label="arc")
    val arcS by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1800, easing=LinearEasing)), label="ars")
    val pulse by inf.animateFloat(.7f, 1f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label="pu")
    Canvas(modifier.size(56.dp)) {
        val c = Offset(size.width/2f, size.height/2f); val r = size.minDimension/2f - 5.dp.toPx()
        drawCircle(DendeColors.Surface, r, c)
        drawCircle(DendeColors.Primary.copy(.15f*pulse), r*.6f, c)
        drawArc(Brush.sweepGradient(listOf(Color.Transparent, DendeColors.Primary, DendeColors.Secondary), c),
            arcS, 240f, false, Offset(c.x-r,c.y-r), androidx.compose.ui.geometry.Size(r*2f,r*2f),
            style=androidx.compose.ui.graphics.drawscope.Stroke(3.5.dp.toPx(), cap=StrokeCap.Round))
    }
}

@Composable
fun ConfettiEffect(visible: Boolean) {
    if (!visible) return
    val particles = remember { List(40) { Triple(Random.nextFloat(), .5f+Random.nextFloat()*1.5f,
        Pair(3f+Random.nextFloat()*8f, listOf(DendeColors.Primary, DendeColors.Secondary, DendeColors.FlameGold, DendeColors.FlameAmber).random())) } }
    var p by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { while(p<1f){p=(p+.015f).coerceAtMost(1f); delay(16)} }
    Canvas(Modifier.fillMaxSize()) {
        particles.forEach { (sx, sp, sc) ->
            val y = size.height*p*sp; val x = size.width*sx + sin(p*10f+sx*20f)*30f
            if(y<size.height) drawCircle(sc.second.copy((1f-p*.8f).coerceIn(0f,1f)), sc.first, Offset(x,y))
        }
    }
}
