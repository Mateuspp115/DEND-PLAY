package com.dendeplay.data.repository

import com.dendeplay.domain.model.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepository @Inject constructor(
    private val sdk: DendeSDKWrapper,
    private val gson: Gson,
) {
    suspend fun searchUniversal(query: String): Result<List<SearchResult>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.searchUniversal(query), object : TypeToken<List<SearchResult>>() {}.type) ?: emptyList()
        }}

    suspend fun searchByType(query: String, type: String): Result<List<SearchResult>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.searchByType(query, type), object : TypeToken<List<SearchResult>>() {}.type) ?: emptyList()
        }}

    suspend fun getMediaDetails(id: String, provider: String): Result<MediaDetails> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.getMediaDetails(id, provider), MediaDetails::class.java)
        }}

    suspend fun getEpisodes(mediaUrl: String, provider: String): Result<List<Episode>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.getEpisodes(mediaUrl, provider), object : TypeToken<List<Episode>>() {}.type) ?: emptyList()
        }}

    suspend fun getVideoSources(episodeUrl: String, provider: String, epNum: Int): Result<List<VideoSource>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.getVideoSources(episodeUrl, provider, epNum), object : TypeToken<List<VideoSource>>() {}.type) ?: emptyList()
        }}

    suspend fun getTrending(mediaType: String): Result<List<SearchResult>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.getTrending(mediaType), object : TypeToken<List<SearchResult>>() {}.type) ?: emptyList()
        }}

    suspend fun getLatestEpisodes(): Result<List<SearchResult>> =
        withContext(Dispatchers.IO) { runCatching {
            gson.fromJson(sdk.getLatestEpisodes(), object : TypeToken<List<SearchResult>>() {}.type) ?: emptyList()
        }}

    suspend fun getContinueWatching(): Result<List<SearchResult>> =
        withContext(Dispatchers.IO) { runCatching {
            val history: List<WatchedMedia> = gson.fromJson(sdk.getHistory(), object : TypeToken<List<WatchedMedia>>() {}.type) ?: emptyList()
            history.take(10).map { SearchResult(id=it.mediaId,title=it.title,imageUrl=it.imageUrl,url=it.mediaId,provider=it.provider,episodes=it.episode) }
        }}

    suspend fun getRecentlyAdded(): Result<List<SearchResult>> = searchByType("popular", "anime")
    suspend fun getRecommended(): Result<List<SearchResult>> = searchByType("action", "anime")

    suspend fun getSkipTimes(malId: Int, ep: Int): Result<SkipTimes> =
        withContext(Dispatchers.IO) { runCatching { gson.fromJson(sdk.getSkipTimes(malId, ep), SkipTimes::class.java) }}

    fun updateProgress(mediaId: String, ep: Int, pos: Int, dur: Int) { sdk.updateProgress(mediaId, ep, pos, dur) }
    fun getProgress(mediaId: String, ep: Int): WatchProgress? = runCatching { gson.fromJson(sdk.getProgress(mediaId, ep), WatchProgress::class.java) }.getOrNull()
    fun addToFavorites(r: SearchResult) { sdk.addToFavorites(gson.toJson(WatchedMedia(mediaId=r.id,title=r.title,provider=r.provider,imageUrl=r.imageUrl))) }
    fun removeFromFavorites(id: String) = sdk.removeFromFavorites(id)
    fun getFavorites(): List<SearchResult> = runCatching {
        val f: List<WatchedMedia> = gson.fromJson(sdk.getFavorites(), object : TypeToken<List<WatchedMedia>>() {}.type) ?: emptyList()
        f.map { SearchResult(id=it.mediaId,title=it.title,imageUrl=it.imageUrl,url=it.mediaId,provider=it.provider) }
    }.getOrElse { emptyList() }
    fun startDownload(mediaId: String, epUrl: String, quality: String, title: String, ep: Int): String {
        val res = sdk.startDownload(mediaId, epUrl, quality, title, ep)
        return runCatching { (@Suppress("UNCHECKED_CAST")(gson.fromJson(res, Map::class.java) as? Map<String,Any>))?.get("id") as? String ?: "" }.getOrElse { "" }
    }
    fun getDownloads(): List<DownloadItem> = runCatching { gson.fromJson(sdk.getDownloads(), object : TypeToken<List<DownloadItem>>() {}.type) ?: emptyList<DownloadItem>() }.getOrElse { emptyList() }
    fun pauseDownload(id: String) = sdk.pauseDownload(id)
    fun resumeDownload(id: String) = sdk.resumeDownload(id)
    fun cancelDownload(id: String) = sdk.cancelDownload(id)
    fun getDownloadProgress(id: String): Int = sdk.getDownloadProgress(id)
    fun clearCache() = sdk.clearCache()
}

interface DendeSDKWrapper {
    fun searchUniversal(query: String): String
    fun searchByType(query: String, type: String): String
    fun getMediaDetails(id: String, provider: String): String
    fun getEpisodes(mediaUrl: String, provider: String): String
    fun getVideoSources(episodeUrl: String, provider: String, epNum: Int): String
    fun getTrending(mediaType: String): String
    fun getLatestEpisodes(): String
    fun getSkipTimes(malId: Int, ep: Int): String
    fun getHistory(): String
    fun addToHistory(json: String): String
    fun getFavorites(): String
    fun addToFavorites(json: String): String
    fun removeFromFavorites(id: String): String
    fun getProgress(mediaId: String, ep: Int): String
    fun updateProgress(mediaId: String, ep: Int, pos: Int, dur: Int): String
    fun startDownload(mediaId: String, epUrl: String, quality: String, title: String, ep: Int): String
    fun getDownloads(): String
    fun pauseDownload(id: String): String
    fun resumeDownload(id: String): String
    fun cancelDownload(id: String): String
    fun getDownloadProgress(id: String): Int
    fun clearCache()
    fun getProviderCount(): Int
    fun getVersion(): String
}
