package com.dendeplay.ui.player

import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.dendeplay.player.SkipSource
import com.dendeplay.player.SkipType
import com.dendeplay.player.VideoQuality
import com.dendeplay.ui.theme.DendeColors
import com.dendeplay.ui.util.fmtMs

// ══════════════════════════════════════════════════════════
// PlayerScreenV11 v1.7 — player polido e completo
//
// Novidades vs v1.6:
//  - Controle de velocidade (0.5x / 0.75x / 1x / 1.25x / 1.5x / 2x)
//  - Seletor de faixa de áudio (DUB / LEG)
//  - Badge de qualidade 4K com brilho especial
//  - Tempo restante além do tempo total
//  - Seek visual com preview de tempo
//  - UI do menu de qualidade e áudio unificada em BottomSheet
//  - Animações suaves em todas as transições
// ══════════════════════════════════════════════════════════

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreenV11(
    episodeUrl:  String,
    provider:    String,
    episodeNum:  Int,
    mediaId:     String,
    title:       String,
    malId:       Int,
    onBack:      () -> Unit,
    onEnterPiP:  () -> Unit,
    onCastClick: () -> Unit,
    vm: PlayerViewModel = hiltViewModel(),
) {
    val ps           by vm.playerState.collectAsStateWithLifecycle()
    val ctrl         by vm.controlsVisible.collectAsStateWithLifecycle()
    val skip         by vm.skipTimes.collectAsStateWithLifecycle()
    val loading      by vm.isLoading.collectAsStateWithLifecycle()
    val speed        by vm.playbackSpeed.collectAsStateWithLifecycle()
    val audioTracks  by vm.audioTracks.collectAsStateWithLifecycle()
    val curAudioIdx  by vm.currentAudioIdx.collectAsStateWithLifecycle()
    val haptic       = LocalHapticFeedback.current

    // Menu state
    var showSheet         by remember { mutableStateOf(SheetContent.NONE) }
    var availQualities    by remember { mutableStateOf(listOf(VideoQuality.AUTO)) }
    var currentQuality    by remember { mutableStateOf(vm.getCurrentQuality()) }
    var showAutoSkipDialog by remember { mutableStateOf(false) }

    // Gesture state
    var seekPreview by remember { mutableStateOf<Long?>(null) }
    var seekDir     by remember { mutableStateOf(0) }
    var seekShow    by remember { mutableStateOf(false) }
    var gestLab     by remember { mutableStateOf("") }
    var gestVal     by remember { mutableStateOf(0f) }
    var gestShow    by remember { mutableStateOf(false) }
    var gestLeft    by remember { mutableStateOf(true) }

    // Skip
    val skipWindows = remember(skip, ps.duration) { vm.getSkipWindows(skip, ps.duration) }
    val activeSkip  = remember(ps.currentPosition, skipWindows) {
        vm.skipManager.currentWindow(ps.currentPosition, skipWindows)
    }

    LaunchedEffect(episodeUrl) { vm.loadEpisode(episodeUrl, provider, episodeNum, mediaId, malId, mediaType) }
    LaunchedEffect(ps.duration) { if (ps.duration > 0) availQualities = vm.getAvailableQualities() }
    LaunchedEffect(gestShow) { if (gestShow) { kotlinx.coroutines.delay(1500); gestShow = false } }

    // Gesto modifier
    val gMod = Modifier.fillMaxSize()
        .pointerInput(Unit) {
            var start = androidx.compose.ui.geometry.Offset.Zero
            var axis  = '?'
            detectDragGestures(
                onDragStart = { start = it; axis = '?' },
                onDrag = { ch, d ->
                    val tx = kotlin.math.abs(ch.position.x - start.x)
                    val ty = kotlin.math.abs(ch.position.y - start.y)
                    if (axis == '?' && (tx > 15 || ty > 15)) axis = if (tx > ty) 'H' else 'V'
                    when (axis) {
                        'H' -> {
                            seekPreview = (vm.currentPosition + (d.x * 200L).toLong()).coerceIn(0L, vm.duration)
                            seekDir  = if (d.x > 0) 1 else -1
                            seekShow = true
                        }
                        'V' -> {
                            gestLeft = start.x < size.width / 2
                            gestVal  = (gestVal - d.y / size.height).coerceIn(0f, 1f)
                            gestLab  = "${if (gestLeft) "Brilho" else "Volume"} ${(gestVal * 100).toInt()}%"
                            gestShow = true
                        }
                    }
                },
                onDragEnd = {
                    if (seekShow && seekPreview != null) {
                        vm.seekTo(seekPreview!!)
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                    seekShow = false; seekPreview = null; axis = '?'
                }
            )
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onTap        = { vm.toggleControls() },
                onDoubleTap  = { off ->
                    if (off.x < size.width / 2) { vm.seekRelative(-10_000); seekDir = -1 }
                    else { vm.seekRelative(10_000); seekDir = 1 }
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
            )
        }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Vídeo
        AndroidView(
            factory = { cx ->
                PlayerView(cx).apply {
                    useController = false
                    resizeMode    = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update   = { it.player = vm.exoPlayer },
            modifier = Modifier.fillMaxSize()
        )
        Box(modifier = gMod)

        // Loading
        AnimatedVisibility(loading && !ps.isPlaying,
            Modifier.align(Alignment.Center), fadeIn(), fadeOut()) {
            CircularProgressIndicator(
                color       = DendeColors.Primary,
                strokeWidth = 3.dp,
                modifier    = Modifier.size(52.dp)
            )
        }

        // Seek preview
        AnimatedVisibility(seekShow, Modifier.align(Alignment.Center), fadeIn(), fadeOut()) {
            val previewMs = seekPreview ?: ps.currentPosition
            Column(
                Modifier.background(Color.Black.copy(.75f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    if (seekDir >= 0) Icons.Rounded.Forward10 else Icons.Rounded.Replay10,
                    null, tint = DendeColors.Primary, modifier = Modifier.size(36.dp)
                )
                Spacer(Modifier.height(4.dp))
                Text(fmtMs(previewMs), color = DendeColors.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("/ ${fmtMs(ps.duration)}", color = DendeColors.White.copy(.55f), fontSize = 11.sp)
            }
        }

        // Gesto volume/brilho
        AnimatedVisibility(gestShow,
            Modifier.align(if (gestLeft) Alignment.CenterStart else Alignment.CenterEnd).padding(20.dp),
            fadeIn(), fadeOut()) {
            Column(
                Modifier.background(Color.Black.copy(.72f), RoundedCornerShape(12.dp))
                    .padding(12.dp).width(56.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    if (gestLeft) Icons.Rounded.BrightnessHigh else
                        if (gestVal < .01f) Icons.Rounded.VolumeOff else
                        if (gestVal < .5f)  Icons.Rounded.VolumeDown else Icons.Rounded.VolumeUp,
                    null, tint = DendeColors.White, modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(120.dp).background(Color.White.copy(.1f), RoundedCornerShape(6.dp))) {
                    Box(
                        Modifier.fillMaxWidth().fillMaxHeight(gestVal).align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(listOf(DendeColors.Primary, DendeColors.Secondary)),
                                RoundedCornerShape(6.dp)
                            )
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(gestLab, color = DendeColors.White, fontSize = 8.sp, fontWeight = FontWeight.Medium)
            }
        }

        // ── Botão Pular ──────────────────────────────────
        AnimatedVisibility(activeSkip != null && !loading,
            Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 110.dp),
            enter = slideInHorizontally { it } + fadeIn(tween(250)),
            exit  = slideOutHorizontally { it } + fadeOut(tween(200)),
        ) {
            val label = when (activeSkip?.type) {
                SkipType.INTRO -> "Pular Abertura"
                SkipType.OUTRO -> "Pular Encerramento"
                SkipType.RECAP -> "Pular Recap"
                else           -> "Pular"
            }
            val srcLabel = when (activeSkip?.source) {
                SkipSource.PATTERN -> " (estimado)"
                else               -> ""
            }

            OutlinedButton(
                onClick = {
                    activeSkip?.let { w ->
                        vm.seekTo((w.end * 1000).toLong())
                        vm.skipManager.recordSkip(mediaId)
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (vm.skipManager.shouldSuggestAutoSkip(mediaId)) showAutoSkipDialog = true
                    }
                },
                shape  = RoundedCornerShape(10.dp),
                border = BorderStroke(1.5.dp, DendeColors.Primary),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.Black.copy(.78f),
                    contentColor   = DendeColors.White
                ),
            ) {
                Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(15.dp), tint = DendeColors.Primary)
                Spacer(Modifier.width(6.dp))
                Text("$label$srcLabel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // ── Auto-skip dialog ─────────────────────────────
        if (showAutoSkipDialog) {
            AlertDialog(
                onDismissRequest = { showAutoSkipDialog = false },
                containerColor   = DendeColors.Surface,
                title  = { Text("Pular sempre?", color = DendeColors.Text, fontWeight = FontWeight.Bold) },
                text   = { Text("Você pulou a abertura várias vezes. Pular automaticamente nesta série?", color = DendeColors.TextSub) },
                confirmButton = {
                    TextButton({
                        vm.skipManager.setAutoSkip(mediaId, true)
                        showAutoSkipDialog = false
                    }) { Text("Sim, sempre", color = DendeColors.Primary) }
                },
                dismissButton = {
                    TextButton({ showAutoSkipDialog = false }) { Text("Não", color = DendeColors.TextSub) }
                }
            )
        }

        // ── Bottom Sheet (qualidade / áudio / velocidade) ─
        if (showSheet != SheetContent.NONE) {
            ModalBottomSheet(
                onDismissRequest  = { showSheet = SheetContent.NONE },
                containerColor    = DendeColors.Surface,
                scrimColor        = Color.Black.copy(.6f),
                dragHandle        = {
                    Box(Modifier.padding(vertical = 10.dp).size(40.dp, 4.dp)
                        .clip(CircleShape).background(DendeColors.SurfaceVar))
                }
            ) {
                when (showSheet) {
                    SheetContent.QUALITY -> QualitySheet(availQualities, currentQuality) { q ->
                        vm.setQuality(q); currentQuality = q; showSheet = SheetContent.NONE
                    }
                    SheetContent.AUDIO -> AudioSheet(audioTracks, curAudioIdx) { track ->
                        vm.selectAudioTrack(track); showSheet = SheetContent.NONE
                    }
                    SheetContent.SPEED -> SpeedSheet(speed) { s ->
                        vm.setSpeed(s); showSheet = SheetContent.NONE
                    }
                    SheetContent.NONE -> {}
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        // ── Overlay de controles ─────────────────────────
        AnimatedVisibility(ctrl, Modifier.fillMaxSize(), fadeIn(tween(200)), fadeOut(tween(300))) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(.38f))) {

                // Top gradient
                Box(Modifier.fillMaxWidth().height(100.dp).align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(.85f), Color.Transparent))))

                // Top bar
                Row(
                    Modifier.fillMaxWidth().align(Alignment.TopStart)
                        .systemBarsPadding().padding(horizontal = 6.dp, vertical = 4.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "Voltar", tint = DendeColors.White) }
                        Column {
                            Text(title, color = DendeColors.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("Episódio $episodeNum", color = DendeColors.White.copy(.65f), fontSize = 10.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        // Velocidade
                        if (speed != 1.0f) {
                            Box(Modifier.padding(end = 2.dp).background(DendeColors.Primary.copy(.15f), RoundedCornerShape(6.dp)).padding(horizontal=8.dp,vertical=4.dp)) {
                                Text("${speed}x", color = DendeColors.Primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        // Qualidade badge
                        PlayerIconButton(
                            onClick = { showSheet = SheetContent.QUALITY },
                            icon    = { QualityBadge(currentQuality) }
                        )
                        // Áudio
                        if (audioTracks.size > 1) {
                            PlayerIconButton(
                                onClick = { showSheet = SheetContent.AUDIO },
                                icon    = { Icon(Icons.Rounded.Translate, null, tint = DendeColors.White, modifier = Modifier.size(20.dp)) }
                            )
                        }
                        // Velocidade
                        PlayerIconButton(
                            onClick = { showSheet = SheetContent.SPEED },
                            icon    = { Icon(Icons.Rounded.Speed, null, tint = DendeColors.White, modifier = Modifier.size(20.dp)) }
                        )
                        // Cast
                        PlayerIconButton(
                            onClick = onCastClick,
                            icon    = { Icon(Icons.Rounded.Cast, null, tint = DendeColors.White, modifier = Modifier.size(20.dp)) }
                        )
                        // PiP
                        PlayerIconButton(
                            onClick = onEnterPiP,
                            icon    = { Icon(Icons.Rounded.PictureInPicture, null, tint = DendeColors.White, modifier = Modifier.size(20.dp)) }
                        )
                    }
                }

                // Controles centrais
                Row(
                    Modifier.align(Alignment.Center),
                    Arrangement.spacedBy(28.dp),
                    Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick   = { vm.seekRelative(-10_000) },
                        modifier  = Modifier.size(52.dp).background(Color.White.copy(.1f), CircleShape)
                    ) {
                        Icon(Icons.Rounded.Replay10, null, tint = DendeColors.White, modifier = Modifier.size(28.dp))
                    }

                    Box(
                        Modifier.size(68.dp)
                            .background(
                                Brush.radialGradient(listOf(DendeColors.Secondary.copy(.9f), DendeColors.Primary)),
                                CircleShape
                            )
                            .clickable(null, null) { vm.togglePlayPause() },
                        Alignment.Center
                    ) {
                        AnimatedContent(targetState = ps.isPlaying, label = "play_pause") { playing ->
                            Icon(
                                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                null, tint = Color.Black, modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick  = { vm.seekRelative(10_000) },
                        modifier = Modifier.size(52.dp).background(Color.White.copy(.1f), CircleShape)
                    ) {
                        Icon(Icons.Rounded.Forward10, null, tint = DendeColors.White, modifier = Modifier.size(28.dp))
                    }
                }

                // Bottom gradient + progress
                Box(Modifier.fillMaxWidth().height(120.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.9f)))))

                Column(
                    Modifier.align(Alignment.BottomStart).fillMaxWidth()
                        .navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(fmtMs(ps.currentPosition), color = DendeColors.White, fontSize = 11.sp)
                        // Mostrar tempo restante
                        val remaining = ps.duration - ps.currentPosition
                        if (remaining > 0) Text("-${fmtMs(remaining)}", color = DendeColors.White.copy(.6f), fontSize = 10.sp)
                        Text(fmtMs(ps.duration), color = DendeColors.White.copy(.55f), fontSize = 11.sp)
                    }
                    if (ps.duration > 0) {
                        Slider(
                            value         = (ps.currentPosition.toFloat() / ps.duration).coerceIn(0f, 1f),
                            onValueChange = { vm.seekTo((it * ps.duration).toLong()) },
                            modifier      = Modifier.fillMaxWidth().height(28.dp)
                                .semantics { contentDescription = "Progresso do vídeo" },
                            colors = SliderDefaults.colors(
                                thumbColor         = DendeColors.Primary,
                                activeTrackColor   = DendeColors.Primary,
                                inactiveTrackColor = Color.White.copy(.25f),
                                activeTickColor    = Color.Transparent,
                                inactiveTickColor  = Color.Transparent,
                            ),
                        )
                    }
                }
            }
        }
    }
}

// ── Componentes auxiliares ────────────────────────────────

private enum class SheetContent { NONE, QUALITY, AUDIO, SPEED }

@Composable
private fun PlayerIconButton(onClick: () -> Unit, icon: @Composable () -> Unit) {
    IconButton(onClick, modifier = Modifier.size(40.dp)) { icon() }
}

@Composable
private fun QualityBadge(q: VideoQuality) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.HighQuality, null, tint = DendeColors.White, modifier = Modifier.size(18.dp))
        val is4K = q == VideoQuality.Q4K || q == VideoQuality.Q8K
        Text(
            q.label,
            color      = if (is4K) DendeColors.FlameGold else DendeColors.Primary,
            fontSize   = 7.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun QualitySheet(
    available: List<VideoQuality>,
    current:   VideoQuality,
    onSelect:  (VideoQuality) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Text("Qualidade de Vídeo", color = DendeColors.Text, fontSize = 16.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 16.dp))
        available.forEach { q ->
            val is4K  = q == VideoQuality.Q4K || q == VideoQuality.Q8K
            val color = if (is4K) DendeColors.FlameGold else DendeColors.Primary
            Row(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (current == q) color.copy(.12f) else Color.Transparent)
                    .clickable { onSelect(q) }
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                Arrangement.spacedBy(12.dp), Alignment.CenterVertically
            ) {
                if (current == q) Icon(Icons.Rounded.Check, null, tint = color, modifier = Modifier.size(18.dp))
                else Spacer(Modifier.size(18.dp))
                Column(Modifier.weight(1f)) {
                    Row(Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                        Text(q.label, color = if (current == q) color else DendeColors.Text,
                            fontSize = 14.sp, fontWeight = if (current == q) FontWeight.Bold else FontWeight.Normal)
                        if (q.badge.isNotEmpty())
                            Box(Modifier.background(color.copy(.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text(q.badge, color = color, fontSize = 9.sp, fontWeight = FontWeight.Black)
                            }
                    }
                    if (q == VideoQuality.AUTO)
                        Text("Adaptativo • melhor para a rede", color = DendeColors.TextHint, fontSize = 10.sp)
                    if (is4K)
                        Text("Ultra Alta Definição", color = DendeColors.TextHint, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun AudioSheet(
    tracks:    List<AudioTrack>,
    currentIdx: Int,
    onSelect:   (AudioTrack) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Text("Faixa de Áudio", color = DendeColors.Text, fontSize = 16.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 16.dp))
        if (tracks.isEmpty()) {
            Text("Apenas uma faixa disponível", color = DendeColors.TextSub, fontSize = 13.sp)
        } else {
            tracks.forEachIndexed { i, track ->
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (i == currentIdx) DendeColors.Primary.copy(.12f) else Color.Transparent)
                        .clickable { onSelect(track) }
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    Arrangement.spacedBy(12.dp), Alignment.CenterVertically
                ) {
                    if (i == currentIdx) Icon(Icons.Rounded.Check, null, tint = DendeColors.Primary, modifier = Modifier.size(18.dp))
                    else Spacer(Modifier.size(18.dp))
                    Icon(Icons.Rounded.Mic, null, tint = if (i == currentIdx) DendeColors.Primary else DendeColors.TextSub, modifier = Modifier.size(18.dp))
                    Text(track.label,
                        color = if (i == currentIdx) DendeColors.Primary else DendeColors.Text,
                        fontSize = 14.sp,
                        fontWeight = if (i == currentIdx) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun SpeedSheet(current: Float, onSelect: (Float) -> Unit) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Text("Velocidade de Reprodução", color = DendeColors.Text, fontSize = 16.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 16.dp))
        speeds.forEach { s ->
            Row(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (s == current) DendeColors.Primary.copy(.12f) else Color.Transparent)
                    .clickable { onSelect(s) }
                    .padding(horizontal = 14.dp, vertical = 14.dp),
                Arrangement.spacedBy(12.dp), Alignment.CenterVertically
            ) {
                if (s == current) Icon(Icons.Rounded.Check, null, tint = DendeColors.Primary, modifier = Modifier.size(18.dp))
                else Spacer(Modifier.size(18.dp))
                Icon(Icons.Rounded.Speed, null, tint = if (s == current) DendeColors.Primary else DendeColors.TextSub, modifier = Modifier.size(18.dp))
                Text(
                    "${s}x${if (s == 1.0f) " (Normal)" else ""}",
                    color = if (s == current) DendeColors.Primary else DendeColors.Text,
                    fontSize = 14.sp,
                    fontWeight = if (s == current) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
