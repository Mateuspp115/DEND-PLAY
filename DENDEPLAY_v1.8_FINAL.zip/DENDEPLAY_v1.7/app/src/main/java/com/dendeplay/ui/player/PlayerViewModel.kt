package com.dendeplay.ui.player

import android.app.Application
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.PlayerState
import com.dendeplay.domain.model.SkipTimes
import com.dendeplay.domain.model.VideoSource
import com.dendeplay.player.QualityManager
import com.dendeplay.player.SkipIntroManager
import com.dendeplay.player.SkipWindow
import com.dendeplay.player.VideoQuality
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

// ══════════════════════════════════════════════════════════
// PlayerViewModel v1.7 — ExoPlayer otimizado para baixo RAM
//
// Configurações chave vs v1.6:
//  - DefaultLoadControl com buffers calibrados (15s min / 50s max)
//  - AdaptiveTrackSelection com bandwidthFraction = 0.75 (conservador)
//  - DefaultBandwidthMeter para decisões baseadas em rede real
//  - Preferência por vídeo menor em dispositivos com RAM < 2GB
//  - Playback speed state exposto para UI
//  - Track de áudio e legenda expostos
// ══════════════════════════════════════════════════════════

@OptIn(UnstableApi::class)
@HiltViewModel
class PlayerViewModel @Inject constructor(
    app: Application,
    private val repo:           MediaRepository,
    val skipManager:            SkipIntroManager,
    private val qualityManager: QualityManager,
) : AndroidViewModel(app) {

    // ── ExoPlayer configurado para eficiência ─────────────

    private val bandwidthMeter = DefaultBandwidthMeter.Builder(app)
        .setResetOnNetworkTypeChange(true)
        .build()

    private val trackSelector = DefaultTrackSelector(app,
        AdaptiveTrackSelection.Factory(
            /* minDurationForQualityIncreaseMs = */ 10_000,
            /* maxDurationForQualityDecreaseMs = */ 25_000,
            /* minDurationToRetainAfterDiscardMs = */ 25_000,
            /* bandwidthFraction = */ 0.75f   // usa 75% da banda disponível
        )
    ).also { sel ->
        // Prefere streams de menor resolução em dispositivos fracos
        val am = app.getSystemService(android.app.ActivityManager::class.java)
        val memInfo = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val isLowRam = am.isLowRamDevice || memInfo.totalMem < 2L * 1024 * 1024 * 1024
        if (isLowRam) {
            sel.parameters = sel.buildUponParameters()
                .setMaxVideoSize(1920, 1080)   // Cap em 1080p para dispositivos fracos
                .setMaxVideoBitrate(5_000_000) // 5 Mbps máximo
                .build()
        }
    }

    private val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            /* minBufferMs = */ 15_000,         // 15s mínimo antes de iniciar
            /* maxBufferMs = */ 50_000,          // 50s máximo em cache (economiza RAM)
            /* bufferForPlaybackMs = */ 2_500,   // 2.5s para começar a tocar
            /* bufferForPlaybackAfterRebufferMs = */ 5_000  // 5s após rebuffer
        )
        .setPrioritizeTimeOverSizeThresholds(true) // Prioriza tempo, não bytes
        .build()

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(app)
        .setTrackSelector(trackSelector)
        .setLoadControl(loadControl)
        .setBandwidthMeter(bandwidthMeter)
        .setWakeMode(C.WAKE_MODE_NETWORK) // Mantém rede ativa durante reprodução
        .build()

    // ── State flows ───────────────────────────────────────

    private val _state         = MutableStateFlow(PlayerState())
    private val _ctrl          = MutableStateFlow(true)
    private val _skip          = MutableStateFlow<SkipTimes?>(null)
    private val _loading       = MutableStateFlow(false)
    private val _playbackSpeed = MutableStateFlow(1.0f)
    private val _audioTracks   = MutableStateFlow<List<AudioTrack>>(emptyList())
    private val _currentAudio  = MutableStateFlow(0)

    val playerState:     StateFlow<PlayerState>        = _state.asStateFlow()
    val controlsVisible: StateFlow<Boolean>            = _ctrl.asStateFlow()
    val skipTimes:       StateFlow<SkipTimes?>         = _skip.asStateFlow()
    val isLoading:       StateFlow<Boolean>            = _loading.asStateFlow()
    val playbackSpeed:   StateFlow<Float>              = _playbackSpeed.asStateFlow()
    val audioTracks:     StateFlow<List<AudioTrack>>   = _audioTracks.asStateFlow()
    val currentAudioIdx: StateFlow<Int>                = _currentAudio.asStateFlow()

    val currentPosition: Long get() = exoPlayer.currentPosition
    val duration:        Long get() = exoPlayer.duration.takeIf { it > 0 } ?: 0L

    private var curId       = ""
    private var curEp       = 0
    private var curMediaType = "anime"
    private var hideJob: Job? = null
    private var progJob: Job? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _state.update { it.copy(isPlaying = playing) }
                if (playing) schedHide()
            }
            override fun onIsLoadingChanged(loading: Boolean) {
                _loading.value = loading
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    _loading.value = false
                    refreshAudioTracks()
                }
            }
        })

        // Tick de progresso a cada 500ms para seek mais fluido
        progJob = viewModelScope.launch {
            var saveCounter = 0
            while (true) {
                delay(500)
                val pos = exoPlayer.currentPosition
                val dur = exoPlayer.duration.takeIf { it > 0 } ?: 0L
                _state.update { it.copy(currentPosition = pos, duration = dur) }

                if (curId.isNotEmpty() && dur > 0) {
                    // Salva progresso a cada 10 ticks = 5 segundos (contador explícito, sem módulo frágil)
                    saveCounter++
                    if (saveCounter >= 10) {
                        saveCounter = 0
                        repo.updateProgress(curId, curEp, (pos / 1000).toInt(), (dur / 1000).toInt())
                    }
                }

                // Auto-skip
                if (skipManager.shouldAutoSkip(curId)) {
                    val windows = getSkipWindows(_skip.value, dur)
                    skipManager.currentWindow(pos, windows)?.let { w ->
                        seekTo((w.end * 1000).toLong())
                    }
                }
            }
        }
    }

    // ── Carregamento de episódio ──────────────────────────

    fun loadEpisode(url: String, prov: String, ep: Int, mid: String, malId: Int, mediaType: String = "anime") {
        curId = mid; curEp = ep; curMediaType = mediaType
        _loading.value = true

        viewModelScope.launch {
            // Busca skip times em paralelo
            launch {
                if (malId > 0) repo.getSkipTimes(malId, ep).onSuccess { _skip.value = it }
            }

            repo.getVideoSources(url, prov, ep).onSuccess { srcs ->
                _loading.value = false
                val best = srcs.maxByOrNull { it.score } ?: srcs.firstOrNull()
                best?.let { playSource(it) }
            }.onFailure {
                _loading.value = false
            }

            // Restaura progresso anterior
            repo.getProgress(mid, ep)?.let { prog ->
                if (prog.position > 10) {
                    delay(800)
                    exoPlayer.seekTo(prog.position * 1000L)
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playSource(s: VideoSource) {
        val dataSourceFactory = DefaultHttpDataSource.Factory().apply {
            setConnectTimeoutMs(15_000)
            setReadTimeoutMs(15_000)
            setAllowCrossProtocolRedirects(true)
            s.headers.forEach { (k, v) -> setDefaultRequestProperty(k, v) }
        }

        val mediaItem = MediaItem.fromUri(s.url)
        val src = if (s.format == "hls")
            HlsMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem)
        else
            ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(mediaItem)

        exoPlayer.setMediaSource(src)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true

        // Aplicar qualidade salva após tracks carregadas
        viewModelScope.launch {
            delay(2_000)
            val pref = qualityManager.getPreference()
            if (pref != VideoQuality.AUTO) qualityManager.applyQuality(exoPlayer, pref)
        }
    }

    // ── Qualidade ─────────────────────────────────────────

    fun setQuality(q: VideoQuality) = qualityManager.applyQuality(exoPlayer, q)
    fun getCurrentQuality(): VideoQuality = qualityManager.getPreference()
    fun getAvailableQualities(): List<VideoQuality> = qualityManager.getAvailableQualities(exoPlayer)

    // ── Skip ──────────────────────────────────────────────

    fun getSkipWindows(skipTimes: SkipTimes?, duration: Long): List<SkipWindow> =
        skipManager.getSkipWindows(curMediaType, duration, skipTimes)

    // ── Velocidade de reprodução ──────────────────────────

    fun setSpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed)
        _playbackSpeed.value = speed
    }

    // ── Faixas de áudio ──────────────────────────────────

    @OptIn(UnstableApi::class)
    private fun refreshAudioTracks() {
        val tracks = mutableListOf<AudioTrack>()
        exoPlayer.currentTracks.groups.forEachIndexed { gi, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    val lang  = fmt.language ?: "und"
                    val label = when (lang.lowercase()) {
                        "pt", "pt-br" -> "Português (BR)"
                        "pt-pt"       -> "Português (PT)"
                        "en"          -> "English"
                        "ja"          -> "Japonês"
                        "es"          -> "Espanhol"
                        else          -> lang.uppercase()
                    }
                    tracks += AudioTrack(groupIndex = gi, trackIndex = i, label = label, language = lang)
                }
            }
        }
        _audioTracks.value = tracks
    }

    @OptIn(UnstableApi::class)
    fun selectAudioTrack(track: AudioTrack) {
        val groups = exoPlayer.currentTracks.groups
        if (track.groupIndex < groups.size) {
            trackSelector.parameters = trackSelector.buildUponParameters()
                .addOverride(
                    androidx.media3.common.TrackSelectionOverride(
                        groups[track.groupIndex].mediaTrackGroup,
                        track.trackIndex
                    )
                ).build()
            _currentAudio.value = _audioTracks.value.indexOf(track)
        }
    }

    // ── Controles básicos ─────────────────────────────────

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
        showCtrl()
    }

    fun seekTo(ms: Long) {
        exoPlayer.seekTo(ms.coerceAtLeast(0))
        showCtrl()
    }

    fun seekRelative(deltaMs: Long) {
        exoPlayer.seekTo((exoPlayer.currentPosition + deltaMs).coerceAtLeast(0))
        showCtrl()
    }

    fun toggleControls() {
        if (_ctrl.value) _ctrl.value = false else showCtrl()
    }

    private fun showCtrl() {
        _ctrl.value = true
        schedHide()
    }

    private fun schedHide() {
        hideJob?.cancel()
        hideJob = viewModelScope.launch {
            delay(4000)
            if (exoPlayer.isPlaying) _ctrl.value = false
        }
    }

    override fun onCleared() {
        progJob?.cancel()
        hideJob?.cancel()
        exoPlayer.release()
        super.onCleared()
    }
}

// ── Data classes auxiliares ───────────────────────────────

data class AudioTrack(
    val groupIndex: Int,
    val trackIndex: Int,
    val label:      String,
    val language:   String,
)
