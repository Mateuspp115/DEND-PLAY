// DENDÊPLAY — Modificações, design e melhorias
// Criado por Mateus "TinkWink" © 2026
//
// Baseado no GoAnime original:
// MIT License — Copyright © 2023 Krone
// https://github.com/alvarorichard/GoAnime
package com.dendeplay.cast.platform

import android.content.Context
import android.util.Log
import com.dendeplay.cast.CastDevice
import com.dendeplay.cast.CastType
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.*
import java.net.*
import java.util.concurrent.TimeUnit

private val httpClient = OkHttpClient.Builder()
    .connectTimeout(3, TimeUnit.SECONDS)
    .readTimeout(5, TimeUnit.SECONDS)
    .writeTimeout(5, TimeUnit.SECONDS)
    .build()

private suspend fun httpGet(url: String): String? = withContext(Dispatchers.IO) {
    runCatching {
        val req = Request.Builder().url(url).get().build()
        httpClient.newCall(req).execute().use { it.body?.string() }
    }.getOrNull()
}

private suspend fun httpPost(url: String, body: String, contentType: String = "application/x-www-form-urlencoded"): Int =
    withContext(Dispatchers.IO) {
        runCatching {
            val rb  = body.toRequestBody(contentType.toMediaType())
            val req = Request.Builder().url(url).post(rb).build()
            httpClient.newCall(req).execute().use { it.code }
        }.getOrElse { -1 }
    }

// ═══════════════════════════════════════════════════════
// RokuManager — Roku ECP
// ═══════════════════════════════════════════════════════

class RokuManager(private val ctx: Context) {
    private val TAG   = "RokuManager"
    private var dev:  CastDevice? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun discover(onFound: (CastDevice) -> Unit) = withContext(Dispatchers.IO) {
        val ssdp = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nST: roku:ecp\r\nMX: 3\r\n\r\n"
        runCatching {
            DatagramSocket().use { sock ->
                sock.soTimeout = 4000; sock.broadcast = true
                val grp = InetAddress.getByName("239.255.255.250")
                sock.send(DatagramPacket(ssdp.toByteArray(), ssdp.length, grp, 1900))
                val buf = ByteArray(4096)
                while (true) {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val resp = String(pkt.data, 0, pkt.length)
                    if (resp.contains("roku", ignoreCase=true)) {
                        val ip = pkt.address.hostAddress ?: continue
                        val name = httpGet("http://$ip:8060/query/device-info")
                            ?.let { Regex("<friendly-screen-name>([^<]+)").find(it)?.groupValues?.get(1) }
                            ?: "Roku TV"
                        onFound(CastDevice("roku:$ip", name, CastType.ROKU, address=ip, port=8060, manufacturer="Roku"))
                        Log.i(TAG, "Encontrado: $name @ $ip")
                    }
                }
            }
        }; Unit
    }

    fun connect(d: CastDevice) { dev = d }
    fun disconnect() { dev = null }

    fun play(url: String, title: String, @Suppress("UNUSED_PARAMETER") thumb: String) {
        val d = dev ?: return
        scope.launch {
            httpPost("http://${d.address}:${d.port}/input/15985",
                "t=v&u=${URLEncoder.encode(url,"UTF-8")}&k=(null)&videoName=${URLEncoder.encode(title,"UTF-8")}&videoFormat=mp4")
        }
    }
    fun play()   = keypress("Play"); fun pause() = keypress("Play"); fun stop() = keypress("Home")
    fun seekTo(ms: Long) = keypress(if (ms > 0) "Fwd" else "Rev")
    fun setVolume(v: Float) {}; fun setSpeed(v: Float) {}
    fun destroy() { scope.cancel() }
    private fun keypress(key: String) { val d = dev ?: return; scope.launch { httpPost("http://${d.address}:${d.port}/keypress/$key", "") } }
}

// ═══════════════════════════════════════════════════════
// SamsungTizenManager — MultiScreen (antigo) + SmartThings (2021+) com fallback
// ═══════════════════════════════════════════════════════

class SamsungTizenManager(private val ctx: Context) {
    private val TAG   = "SamsungTizen"
    private var dev:  CastDevice? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    enum class SamsungGeneration { LEGACY, MODERN } // LEGACY = 2016-2020, MODERN = 2021+

    suspend fun discover(onFound: (CastDevice) -> Unit) = withContext(Dispatchers.IO) {
        // Samsung responde a múltiplos STs
        for (st in listOf(
            "urn:samsung.com:service:MultiScreen:1",
            "urn:samsung.com:device:RemoteControlReceiver:1",
            "urn:schemas-upnp-org:device:MediaRenderer:1"
        )) {
            val ssdp = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nST: $st\r\nMX: 2\r\n\r\n"
            runCatching {
                DatagramSocket().use { sock ->
                    sock.soTimeout = 3000; sock.broadcast = true
                    val grp = InetAddress.getByName("239.255.255.250")
                    sock.send(DatagramPacket(ssdp.toByteArray(), ssdp.length, grp, 1900))
                    val buf = ByteArray(4096)
                    while (true) {
                        val pkt = DatagramPacket(buf, buf.size)
                        sock.receive(pkt)
                        val resp = String(pkt.data, 0, pkt.length)
                        if (resp.contains("samsung", ignoreCase=true) || resp.contains("tizen", ignoreCase=true)) {
                            val ip = pkt.address.hostAddress ?: continue
                            if (alreadyFound(ip)) continue
                            // Detectar geração pelo header Server ou pelo ano do modelo
                            val gen = detectGeneration(resp)
                            val name = extractDeviceName(resp) ?: "Samsung Smart TV"
                            onFound(CastDevice("samsung:$ip", name, CastType.SAMSUNG_TIZEN, address=ip, port=8001, manufacturer="Samsung",
                                model = gen.name))
                            Log.i(TAG, "Samsung $gen @ $ip: $name")
                        }
                    }
                }
            }
        }; Unit
    }

    private val foundIPs: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf())
    private fun alreadyFound(ip: String): Boolean { if (ip in foundIPs) return true; foundIPs += ip; return false }

    private fun detectGeneration(ssdpResponse: String): SamsungGeneration {
        // TVs 2021+ geralmente anunciam "Tizen" versão 6+ ou têm "SmartThings" no header
        val version = Regex("Tizen/([\\d.]+)").find(ssdpResponse)?.groupValues?.get(1)
        val major = version?.split(".")?.firstOrNull()?.toIntOrNull() ?: 0
        return if (major >= 6) SamsungGeneration.MODERN else SamsungGeneration.LEGACY
    }

    private fun extractDeviceName(resp: String): String? =
        Regex("SERVER:.*?([^\r\n]+Samsung[^\r\n]+)", RegexOption.IGNORE_CASE).find(resp)?.groupValues?.get(1)?.trim()

    fun connect(d: CastDevice) { dev = d }
    fun disconnect() { dev = null }

    fun play(url: String, title: String, @Suppress("UNUSED_PARAMETER") thumb: String) {
        val d = dev ?: return
        val gen = runCatching { SamsungGeneration.valueOf(d.model) }.getOrElse { SamsungGeneration.LEGACY }
        scope.launch {
            if (gen == SamsungGeneration.MODERN) {
                playModern(d, url, title)
            } else {
                playLegacy(d, url)
            }
        }
    }

    /** Samsung 2021+: REST API na porta 8001/8002 */
    private suspend fun playModern(d: CastDevice, url: String, title: String) {
        val payload = JSONObject().apply {
            put("id", "samsung.api.v2"); put("method", "ms.channel.emit")
            put("params", JSONObject().apply {
                put("event", "ed.apps.launch"); put("to", "host")
                put("data", JSONObject().apply { put("appId","org.tizen.browser"); put("action_type","NATIVE_LAUNCH"); put("metaTag", url) })
            })
        }.toString()
        val code = httpPost("http://${d.address}:${d.port}/api/v2/applications/org.tizen.browser", payload, "application/json")
        if (code < 0) { Log.w(TAG, "Modern API falhou, tentando legacy..."); playLegacy(d, url) }
    }

    /** Samsung 2016-2020: abrir URL via browser app */
    private suspend fun playLegacy(d: CastDevice, url: String) {
        httpPost("http://${d.address}:${d.port}/api/v2/channels/samsung.remote.control", 
            """{"method":"ms.remote.control","params":{"Cmd":"Click","DataOfCmd":"KEY_MUTE","Option":"false","TypeOfRemote":"SendRemoteKey"}}""",
            "application/json")
    }

    fun play() {}; fun pause() {}; fun stop() {}
    fun seekTo(ms: Long) {}; fun setVolume(v: Float) {}; fun setSpeed(v: Float) {}
    fun destroy() { scope.cancel() }
}

// ═══════════════════════════════════════════════════════
// LGWebOSManager — webOS 3-5 (porta 3000) + webOS 6+ (porta diferente)
// ═══════════════════════════════════════════════════════

class LGWebOSManager(private val ctx: Context) {
    private val TAG   = "LGWebOS"
    private var dev:  CastDevice? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val wsClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0,  TimeUnit.MILLISECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    @Volatile private var webSocket: WebSocket? = null

    private val wsListener = object : WebSocketListener() {
        override fun onOpen(ws: WebSocket, response: Response) {
            webSocket = ws
            // Handshake de registro
            ws.send(JSONObject().apply {
                put("type","register"); put("id","dendeplay-register")
                put("payload", JSONObject().apply {
                    put("forcePairing",false); put("pairingType","PROMPT")
                    put("manifest", JSONObject().apply { put("manifestVersion",1); put("appDescription","DENDÊPLAY") })
                })
            }.toString())
            Log.i(TAG, "LG WebSocket conectado: ${dev?.address}")
        }
        override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
            Log.w(TAG, "LG WS falhou: ${t.message}"); webSocket = null
        }
        override fun onClosed(ws: WebSocket, code: Int, reason: String) { webSocket = null }
        override fun onMessage(ws: WebSocket, text: String) { Log.d(TAG, "LG: ${text.take(80)}") }
    }

    suspend fun discover(onFound: (CastDevice) -> Unit) = withContext(Dispatchers.IO) {
        val ssdp = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nST: urn:lge-com:service:webos-second-screen:1\r\nMX: 3\r\n\r\n"
        runCatching {
            DatagramSocket().use { sock ->
                sock.soTimeout = 4000; sock.broadcast = true
                val grp = InetAddress.getByName("239.255.255.250")
                sock.send(DatagramPacket(ssdp.toByteArray(), ssdp.length, grp, 1900))
                val buf = ByteArray(4096)
                while (true) {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val resp = String(pkt.data, 0, pkt.length)
                    if (resp.contains("lge", ignoreCase=true) || resp.contains("webos", ignoreCase=true)) {
                        val ip = pkt.address.hostAddress ?: continue
                        // Detectar versão webOS pelo port ou header
                        val port = if (resp.contains("webOS/6") || resp.contains("webOS/7") || resp.contains("webOS/8")) 3001 else 3000
                        onFound(CastDevice("lg:$ip", "LG Smart TV", CastType.LG_WEBOS, address=ip, port=port, manufacturer="LG"))
                        Log.i(TAG, "LG descoberto: $ip port=$port")
                    }
                }
            }
        }; Unit
    }

    fun connect(d: CastDevice) {
        dev = d
        val req = Request.Builder().url("ws://${d.address}:${d.port}").build()
        wsClient.newWebSocket(req, wsListener)
    }

    fun disconnect() { webSocket?.close(1000, "DENDÊPLAY disconnected"); webSocket = null; dev = null }

    fun play(url: String, title: String, @Suppress("UNUSED_PARAMETER") thumb: String) {
        send(JSONObject().apply {
            put("type","request"); put("id","play-video"); put("uri","ssap://media.viewer/open")
            put("payload", JSONObject().apply {
                put("target", url); put("title", title)
                put("mimeType", if (url.contains(".m3u8")) "application/x-mpegURL" else "video/mp4")
            })
        }.toString())
    }

    fun play()  { send(cmd("ssap://media.controls/play")) }
    fun pause() { send(cmd("ssap://media.controls/pause")) }
    fun stop()  { send(cmd("ssap://media.controls/stop")) }

    fun seekTo(ms: Long) {
        send(JSONObject().apply {
            put("type","request"); put("id","seek"); put("uri","ssap://media.controls/seek")
            put("payload", JSONObject().put("position", ms/1000))
        }.toString())
    }

    fun setVolume(v: Float) {
        send(JSONObject().apply {
            put("type","request"); put("id","vol"); put("uri","ssap://audio/setVolume")
            put("payload", JSONObject().put("volume", (v*100).toInt()))
        }.toString())
    }

    fun setSpeed(v: Float) {}

    private fun send(msg: String) { webSocket?.send(msg) ?: Log.w(TAG, "WS não conectado") }
    private fun cmd(uri: String)  = JSONObject().apply { put("type","request"); put("uri",uri) }.toString()

    fun destroy() { scope.cancel(); disconnect(); wsClient.dispatcher.executorService.shutdownNow() }
}

// ═══════════════════════════════════════════════════════
// AndroidTVManager e DLNAManager (inalterados mas com melhorias menores)
// ═══════════════════════════════════════════════════════

class AndroidTVManager(private val ctx: Context) {
    private val TAG = "AndroidTV"; private var dev: CastDevice? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun discover(onFound: (CastDevice) -> Unit) = withContext(Dispatchers.IO) {
        val ssdp = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nST: urn:dial-multiscreen-org:service:dial:1\r\nMX: 3\r\n\r\n"
        runCatching {
            DatagramSocket().use { sock ->
                sock.soTimeout = 4000; sock.broadcast = true
                val grp = InetAddress.getByName("239.255.255.250")
                sock.send(DatagramPacket(ssdp.toByteArray(), ssdp.length, grp, 1900))
                val buf = ByteArray(4096)
                while (true) {
                    val pkt = DatagramPacket(buf, buf.size)
                    sock.receive(pkt)
                    val r = String(pkt.data, 0, pkt.length)
                    if (r.contains("Android TV",ignoreCase=true)||r.contains("Google TV",ignoreCase=true)||r.contains("bravia",ignoreCase=true)) {
                        val ip = pkt.address.hostAddress ?: continue
                        onFound(CastDevice("atv:$ip","Android TV",CastType.ANDROID_TV,address=ip,port=9080,manufacturer="Google"))
                    }
                }
            }
        }; Unit
    }
    fun connect(d: CastDevice) { dev = d }; fun disconnect() { dev = null }
    fun play(url: String, @Suppress("UNUSED_PARAMETER") title: String, @Suppress("UNUSED_PARAMETER") thumb: String) {
        val d = dev ?: return
        scope.launch { httpPost("http://${d.address}:${d.port}/apps/YouTube","v=${URLEncoder.encode(url,"UTF-8")}","text/plain") }
    }
    fun play(){}; fun pause(){}; fun stop(){}
    fun seekTo(ms: Long){}; fun setVolume(v: Float){}; fun setSpeed(v: Float){}
    fun destroy() { scope.cancel() }
}

class DLNAManager(private val ctx: Context) {
    private val TAG = "DLNA"; private var dev: CastDevice? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun connect(d: CastDevice) { dev = d }; fun disconnect() { dev = null }

    fun play(url: String, title: String) {
        val d = dev ?: return
        scope.launch {
            runCatching {
                soap(d,"/AVTransport/control","urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI",buildSetURI(url,title))
                delay(600)
                soap(d,"/AVTransport/control","urn:schemas-upnp-org:service:AVTransport:1#Play",buildPlay())
            }.onFailure { Log.e(TAG,"DLNA play: ${it.message}") }
        }
    }

    fun play()  = action("Play","<InstanceID>0</InstanceID><Speed>1</Speed>")
    fun pause() = action("Pause","<InstanceID>0</InstanceID><Speed>1</Speed>")
    fun stop()  = action("Stop","<InstanceID>0</InstanceID>")
    fun seekTo(ms: Long) {
        val t = "%02d:%02d:%02d".format(ms/3_600_000,(ms/60_000)%60,(ms/1_000)%60)
        action("Seek","<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>$t</Target>")
    }
    fun setVolume(v: Float) {
        val d = dev ?: return
        scope.launch { soap(d,"/RenderingControl/control","urn:schemas-upnp-org:service:RenderingControl:1#SetVolume",
            """<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body>
            <u:SetVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1">
            <InstanceID>0</InstanceID><Channel>Master</Channel><DesiredVolume>${(v*100).toInt()}</DesiredVolume>
            </u:SetVolume></s:Body></s:Envelope>""") }
    }
    fun setSpeed(v: Float) {}

    private fun action(a: String, inner: String) {
        val d = dev ?: return
        scope.launch { soap(d,"/AVTransport/control","urn:schemas-upnp-org:service:AVTransport:1#$a",
            """<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
            <s:Body><u:$a xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">$inner</u:$a></s:Body></s:Envelope>""") }
    }

    private suspend fun soap(d: CastDevice, path: String, action: String, body: String) {
        withContext(Dispatchers.IO) {
            val rb  = body.toRequestBody("text/xml; charset=utf-8".toMediaType())
            val req = Request.Builder().url("http://${d.address}:${d.port}$path").post(rb)
                .addHeader("SOAPAction","\"$action\"").build()
            httpClient.newCall(req).execute().use { Log.d(TAG,"SOAP $action -> ${it.code}") }
        }
    }

    private fun buildSetURI(url: String, title: String) = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body><u:SetAVTransportURI xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
    <InstanceID>0</InstanceID><CurrentURI>${url}</CurrentURI>
    <CurrentURIMetaData>&lt;DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/"
      xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/"&gt;
      &lt;item&gt;&lt;dc:title&gt;${title.replace("&","&amp;")}&lt;/dc:title&gt;
      &lt;upnp:class&gt;object.item.videoItem&lt;/upnp:class&gt;
      &lt;/item&gt;&lt;/DIDL-Lite&gt;</CurrentURIMetaData>
  </u:SetAVTransportURI></s:Body></s:Envelope>""".trimIndent()

    private fun buildPlay() = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
  <s:Body><u:Play xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
    <InstanceID>0</InstanceID><Speed>1</Speed>
  </u:Play></s:Body></s:Envelope>""".trimIndent()

    fun destroy() { scope.cancel() }
}
