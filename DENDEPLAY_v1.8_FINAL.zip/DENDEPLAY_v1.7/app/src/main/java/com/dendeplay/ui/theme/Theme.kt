package com.dendeplay.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object DendeColors {
    val Black       = Color(0xFF000000)
    val Background  = Color(0xFF0A0A0A)
    val Surface     = Color(0xFF1E1E1E)
    val SurfaceVar  = Color(0xFF2A2A2A)
    val Card        = Color(0xFF181818)
    val Primary     = Color(0xFFFFB300)
    val PrimaryDark = Color(0xFFE65100)
    val Secondary   = Color(0xFFFF6D00)
    val FlameRed    = Color(0xFFCC1500)
    val FlameOrange = Color(0xFFFF6D00)
    val FlameGold   = Color(0xFFFFD700)
    val FlameAmber  = Color(0xFFFFB300)
    val White       = Color(0xFFFFFFFF)
    val Text        = Color(0xFFFFFFFF)
    val TextSub     = Color(0xFFB0B0B0)
    val TextHint    = Color(0xFF606060)
    val Success     = Color(0xFF4CAF50)
    val Error       = Color(0xFFF44336)
    val RippleGold  = Color(0x30FFB300)
    val DiskBg      = Color(0xFF0D0D22)
    val flameBrush  = Brush.verticalGradient(listOf(Color(0xFFFFEE58), FlameAmber, FlameOrange, FlameRed))
    val cardGrad    = Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))
}

private val scheme = darkColorScheme(
    primary          = DendeColors.Primary,    onPrimary         = Color(0xFF000000),
    primaryContainer = DendeColors.PrimaryDark,
    secondary        = DendeColors.Secondary,  onSecondary       = DendeColors.White,
    background       = DendeColors.Background, onBackground      = DendeColors.Text,
    surface          = DendeColors.Surface,    onSurface         = DendeColors.Text,
    surfaceVariant   = DendeColors.SurfaceVar,
    error            = DendeColors.Error,      onError           = DendeColors.White,
)

@Composable
fun DendePlayTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, typography = DendeTypography, content = content)
