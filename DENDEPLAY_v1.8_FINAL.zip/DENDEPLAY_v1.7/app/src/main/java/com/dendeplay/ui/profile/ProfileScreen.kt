package com.dendeplay.ui.profile

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dendeplay.account.UserAccount
import com.dendeplay.api.AudioPreference
import com.dendeplay.domain.model.SearchResult
import com.dendeplay.ui.components.DendeLogo
import com.dendeplay.ui.home.PosterCard
import com.dendeplay.ui.theme.DendeColors

@Composable
fun ProfileScreen(
    onMediaClick:   (SearchResult) -> Unit = {},
    onCreditsClick: () -> Unit             = {},
    onGoogleSignIn: () -> Unit             = {},
    vm:             ProfileViewModel       = hiltViewModel(),
) {
    val favs    by vm.favs.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val account by vm.account.collectAsStateWithLifecycle()
    val prefs   by vm.preferences.collectAsStateWithLifecycle()
    var tab     by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().background(DendeColors.Background).statusBarsPadding()) {
        // Header com conta
        ProfileHeader(account, onGoogleSignIn)

        // Tabs
        TabRow(tab, containerColor=DendeColors.Background, contentColor=DendeColors.Primary,
            indicator={tp->TabRowDefaults.SecondaryIndicator(Modifier.tabIndicatorOffset(tp[tab]),color=DendeColors.Primary,height=2.dp)}) {
            Tab(tab==0,{tab=0},text={Text("Favoritos",fontSize=13.sp)})
            Tab(tab==1,{tab=1},text={Text("Histórico",fontSize=13.sp)})
            Tab(tab==2,{tab=2},text={Text("Ajustes",fontSize=13.sp)})
        }

        when(tab) {
            0 -> if(favs.isEmpty()) EmptyTab(Icons.Rounded.FavoriteBorder,"Nenhum favorito ainda","Toque em Favorito nos detalhes para adicionar")
                 else LazyRow(contentPadding=PaddingValues(16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)){
                     items(favs){PosterCard(it,onMediaClick)}
                 }
            1 -> if(history.isEmpty()) EmptyTab(Icons.Rounded.History,"Histórico vazio","Assista algo para aparecer aqui")
                 else LazyColumn(contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)){
                     items(history){item->
                         Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(DendeColors.Card)
                             .clickable{onMediaClick(item)}.padding(10.dp),
                             Arrangement.spacedBy(12.dp), Alignment.CenterVertically){
                             Box(Modifier.size(54.dp).clip(RoundedCornerShape(8.dp)).background(DendeColors.Surface)){
                                 AsyncImage(item.imageUrl,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                             }
                             Column(Modifier.weight(1f)){
                                 Text(item.title,color=DendeColors.Text,fontSize=13.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                                 if(item.episodes>0) Text("Ep. ${item.episodes}",color=DendeColors.TextSub,fontSize=11.sp)
                             }
                             Icon(Icons.Rounded.PlayArrow,null,tint=DendeColors.Primary,modifier=Modifier.size(20.dp))
                         }
                     }
                 }
            2 -> SettingsTab(vm, prefs, onCreditsClick)
        }
    }
}

@Composable
private fun ProfileHeader(account: UserAccount, onSignIn: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(DendeColors.Surface,DendeColors.Background))).padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(14.dp)) {
            if(account.isSignedIn && account.photoUrl.isNotEmpty()) {
                AsyncImage(account.photoUrl,null,Modifier.size(56.dp).clip(CircleShape).border(2.dp,DendeColors.Primary,CircleShape),contentScale=ContentScale.Crop)
            } else {
                Box(Modifier.size(56.dp).background(Brush.radialGradient(listOf(DendeColors.FlameOrange,DendeColors.PrimaryDark)),CircleShape),Alignment.Center){
                    if(account.isSignedIn) Text(account.name.take(1).uppercase(),color=Color.Black,fontSize=20.sp,fontWeight=FontWeight.Black)
                    else DendeLogo(32.dp)
                }
            }
            Column(Modifier.weight(1f)) {
                if(account.isSignedIn) {
                    Text(account.name, color=DendeColors.Text, fontSize=17.sp, fontWeight=FontWeight.Black)
                    Text(account.email, color=DendeColors.TextSub, fontSize=11.sp)
                    Row(Modifier.padding(top=4.dp), Arrangement.spacedBy(6.dp), Alignment.CenterVertically){
                        Box(Modifier.size(6.dp).background(DendeColors.Success,CircleShape))
                        Text("Conta conectada (local)", color=DendeColors.Success, fontSize=10.sp)
                    }
                } else {
                    Text("Entrar com Google", color=DendeColors.Text, fontSize=17.sp, fontWeight=FontWeight.Black)
                    Text("Para sincronizar dados no futuro", color=DendeColors.TextSub, fontSize=11.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick=onSignIn, shape=RoundedCornerShape(8.dp),
                        border=BorderStroke(1.dp,DendeColors.Primary),
                        colors=ButtonDefaults.outlinedButtonColors(contentColor=DendeColors.Primary)) {
                        Icon(Icons.Rounded.AccountCircle,null,modifier=Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Entrar com Google",fontSize=12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyTab(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) =
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.padding(32.dp)) {
            Icon(icon,null,tint=DendeColors.SurfaceVar,modifier=Modifier.size(52.dp))
            Spacer(Modifier.height(14.dp))
            Text(title,color=DendeColors.Text,fontSize=17.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(sub,color=DendeColors.TextSub,fontSize=13.sp)
        }
    }

@Composable
private fun SettingsTab(vm: ProfileViewModel, prefs: com.dendeplay.api.UserPreferences, onCreditsClick: () -> Unit) {
    LazyColumn(contentPadding=PaddingValues(14.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) {
        item { SettSection("Reprodução") }
        item { SettToggle("Pular abertura automaticamente", Icons.Rounded.SkipNext, prefs.autoSkipIntro){ vm.setAutoSkip(it) } }
        item { SettToggle("Reprodução automática", Icons.Rounded.PlayCircle, prefs.autoNextEpisode){ vm.setAutoNext(it) } }
        item { SettToggle("PiP automático ao sair", Icons.Rounded.PictureInPicture, false){} }
        item { SettItem("Qualidade padrão", prefs.defaultQuality, Icons.Rounded.HighQuality){} }

        item { Spacer(Modifier.height(8.dp)); SettSection("Idioma e Áudio") }
        item {
            // Preferência de áudio (dublado/legendado/ambos)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(DendeColors.Card).padding(12.dp),
                Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                Icon(Icons.Rounded.Mic,null,tint=DendeColors.TextSub,modifier=Modifier.size(18.dp))
                Text("Preferência de áudio",color=DendeColors.Text,fontSize=13.sp,modifier=Modifier.weight(1f))
            }
            Row(Modifier.padding(start=42.dp).padding(bottom=4.dp), Arrangement.spacedBy(8.dp)){
                listOf(AudioPreference.DUBBED to "Dublado", AudioPreference.SUBBED to "Legendado", AudioPreference.BOTH to "Ambos").forEach { (p,l) ->
                    FilterChip(selected=prefs.audioPreference==p, onClick={vm.setAudioPref(p)}, label={Text(l,fontSize=11.sp)}, shape=RoundedCornerShape(20.dp),
                        colors=FilterChipDefaults.filterChipColors(selectedContainerColor=DendeColors.Primary,selectedLabelColor=Color.Black,containerColor=DendeColors.Card,labelColor=DendeColors.TextSub))
                }
            }
        }
        item { SettToggle("Mostrar dublado primeiro", Icons.Rounded.RecordVoiceOver, prefs.preferDubbed){ vm.setPreferDubbed(it) } }

        item { Spacer(Modifier.height(8.dp)); SettSection("Downloads") }
        item { SettToggle("Baixar só no Wi-Fi", Icons.Rounded.Wifi, true){} }
        item { SettItem("Qualidade de download","720p", Icons.Rounded.Download){} }
        item { SettItem("Limpar cache","", Icons.Rounded.CleaningServices){ vm.clearCache() } }

        item { Spacer(Modifier.height(8.dp)); SettSection("Sobre") }
        item { SettItem("Versão","1.8.0", Icons.Rounded.Info){} }
        item { SettItem("Providers ativos","${vm.providerCount} fontes", Icons.Rounded.Source){} }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(DendeColors.Primary.copy(.08f))
                .clickable(onClick=onCreditsClick).padding(12.dp),
                Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                Icon(Icons.Rounded.Copyright,null,tint=DendeColors.Primary,modifier=Modifier.size(18.dp))
                Text("Sobre e Créditos",color=DendeColors.Primary,fontSize=13.sp,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f))
                Text("MIT + DENDEPLAY",color=DendeColors.TextHint,fontSize=11.sp)
                Icon(Icons.Rounded.ChevronRight,null,tint=DendeColors.Primary,modifier=Modifier.size(16.dp))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top=8.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                Text("DENDEPLAY v1.8.0",color=DendeColors.TextHint,fontSize=10.sp,fontWeight=FontWeight.Bold)
                Text("© 2026 Mateus \"TinkWink\"",color=DendeColors.TextHint,fontSize=10.sp)
                Text("Baseado no GoAnime © 2023 Krone — MIT",color=DendeColors.TextHint,fontSize=9.sp)
            }
        }
    }
}

@Composable private fun SettSection(t: String) =
    Text(t.uppercase(),color=DendeColors.Primary,fontSize=10.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp,modifier=Modifier.padding(vertical=8.dp,horizontal=4.dp))

@Composable private fun SettItem(t: String, v: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: ()->Unit) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable(onClick=onClick).padding(12.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Icon(icon,null,tint=DendeColors.TextSub,modifier=Modifier.size(18.dp))
        Text(t,color=DendeColors.Text,fontSize=13.sp,modifier=Modifier.weight(1f))
        if(v.isNotEmpty()) Text(v,color=DendeColors.TextSub,fontSize=12.sp)
        Icon(Icons.Rounded.ChevronRight,null,tint=DendeColors.TextHint,modifier=Modifier.size(16.dp))
    }

@Composable private fun SettToggle(t: String, icon: androidx.compose.ui.graphics.vector.ImageVector, init: Boolean, onToggle: (Boolean)->Unit) {
    var st by remember{mutableStateOf(init)}
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable{st=!st;onToggle(st)}.padding(12.dp),
        Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
        Icon(icon,null,tint=DendeColors.TextSub,modifier=Modifier.size(18.dp))
        Text(t,color=DendeColors.Text,fontSize=13.sp,modifier=Modifier.weight(1f))
        Switch(st,{st=it;onToggle(it)},colors=SwitchDefaults.colors(checkedThumbColor=DendeColors.Background,checkedTrackColor=DendeColors.Primary,uncheckedThumbColor=DendeColors.TextSub,uncheckedTrackColor=DendeColors.SurfaceVar))
    }
}
