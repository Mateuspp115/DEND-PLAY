package com.dendeplay.ui.social

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.theme.DendeColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ══════════════════════════════════════════════════════════
// ChatScreen — chat por série/anime
//
// Permite que usuários deixem comentários e discussões
// sobre cada série ou anime.
// Armazena localmente por enquanto (Room DB no futuro).
// Estrutura pronta para conectar com servidor.
// ══════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    mediaId:   String,
    mediaTitle: String,
    onBack:    () -> Unit,
    vm:        ChatViewModel = hiltViewModel(),
) {
    LaunchedEffect(mediaId) { vm.load(mediaId) }

    val messages by vm.messages.collectAsStateWithLifecycle()
    val account  by vm.userDisplay.collectAsStateWithLifecycle()
    var text     by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        containerColor = DendeColors.Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Discussão", color = DendeColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(mediaTitle, color = DendeColors.TextSub, fontSize = 11.sp, maxLines = 1)
                    }
                },
                navigationIcon = {
                    IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = DendeColors.Text) }
                },
                actions = {
                    Box(
                        Modifier.padding(end = 12.dp).background(DendeColors.Primary.copy(.12f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("${messages.size} ${if (messages.size == 1) "mensagem" else "mensagens"}", color = DendeColors.Primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DendeColors.Background)
            )
        },
        bottomBar = {
            Surface(color = DendeColors.Surface, shadowElevation = 8.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    Arrangement.spacedBy(8.dp), Alignment.CenterVertically
                ) {
                    // Avatar do usuário
                    Box(
                        Modifier.size(32.dp).background(
                            Brush.radialGradient(listOf(DendeColors.FlameOrange, DendeColors.PrimaryDark)),
                            CircleShape
                        ), Alignment.Center
                    ) { Text(account.take(1).uppercase(), color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Black) }

                    OutlinedTextField(
                        value         = text,
                        onValueChange = { if (it.length <= 280) text = it },
                        modifier      = Modifier.weight(1f),
                        placeholder   = { Text("Comentar sobre $mediaTitle…", color = DendeColors.TextHint, fontSize = 13.sp) },
                        singleLine    = false,
                        maxLines      = 3,
                        shape         = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor    = DendeColors.Primary,
                            unfocusedBorderColor  = DendeColors.SurfaceVar,
                            focusedTextColor      = DendeColors.Text,
                            unfocusedTextColor    = DendeColors.Text,
                            cursorColor           = DendeColors.Primary,
                            focusedContainerColor = DendeColors.Card,
                            unfocusedContainerColor = DendeColors.Card,
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (text.isNotBlank()) { vm.send(mediaId, text); text = "" }
                        }),
                        trailingIcon = {
                            Text("${text.length}/280", color = DendeColors.TextHint, fontSize = 9.sp,
                                modifier = Modifier.padding(end = 8.dp))
                        }
                    )

                    // Botão enviar
                    Box(
                        Modifier.size(40.dp)
                            .background(if (text.isNotBlank()) DendeColors.Primary else DendeColors.SurfaceVar, CircleShape)
                            .clickable { if (text.isNotBlank()) { vm.send(mediaId, text); text = "" } },
                        Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Send, null,
                            tint = if (text.isNotBlank()) Color.Black else DendeColors.TextHint,
                            modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    ) { pad ->
        if (messages.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Rounded.Forum, null, tint = DendeColors.SurfaceVar, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Nenhum comentário ainda", color = DendeColors.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Seja o primeiro a comentar sobre esta série!", color = DendeColors.TextSub, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                state           = listState,
                modifier        = Modifier.fillMaxSize().padding(pad),
                contentPadding  = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatBubble(msg = msg, isOwn = msg.userId == vm.currentUserId, onLike = { vm.like(msg.id) })
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(msg: ChatMessage, isOwn: Boolean, onLike: () -> Unit) {
    val align = if (isOwn) Alignment.End else Alignment.Start
    val bubbleColor = if (isOwn) DendeColors.Primary.copy(.18f) else DendeColors.Card
    val dateStr = remember(msg.timestamp) {
        SimpleDateFormat("HH:mm", Locale("pt","BR")).format(Date(msg.timestamp))
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        if (!isOwn) {
            Text(msg.userName, color = DendeColors.Primary, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp, bottom = 2.dp))
        }
        Box(
            Modifier.fillMaxWidth(.82f)
                .clip(RoundedCornerShape(
                    topStart    = if (isOwn) 14.dp else 4.dp,
                    topEnd      = if (isOwn) 4.dp else 14.dp,
                    bottomStart = 14.dp, bottomEnd = 14.dp
                ))
                .background(bubbleColor)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Column {
                Text(msg.text, color = DendeColors.Text, fontSize = 13.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(dateStr, color = DendeColors.TextHint, fontSize = 9.sp)
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onLike)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        Arrangement.spacedBy(3.dp), Alignment.CenterVertically
                    ) {
                        Icon(
                            if (msg.likedByMe) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            null,
                            tint     = if (msg.likedByMe) DendeColors.Primary else DendeColors.TextHint,
                            modifier = Modifier.size(12.dp)
                        )
                        if (msg.likes > 0) Text("${msg.likes}", color = DendeColors.TextHint, fontSize = 9.sp)
                    }
                }
            }
        }
    }
}
