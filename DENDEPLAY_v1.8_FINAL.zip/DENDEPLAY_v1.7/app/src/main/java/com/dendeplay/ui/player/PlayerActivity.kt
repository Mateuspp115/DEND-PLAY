package com.dendeplay.ui.player

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.OptIn
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.util.UnstableApi
import com.dendeplay.cast.AdvancedCastManager
import com.dendeplay.cast.CastPickerSheet
import com.dendeplay.ui.theme.DendePlayTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class PlayerActivity : ComponentActivity() {

    @Inject lateinit var castManager: AdvancedCastManager

    companion object {
        const val EXTRA_EPISODE_URL = "episode_url"
        const val EXTRA_PROVIDER    = "provider"
        const val EXTRA_EPISODE_NUM = "episode_num"
        const val EXTRA_MEDIA_ID    = "media_id"
        const val EXTRA_TITLE       = "title"
        const val EXTRA_MAL_ID      = "mal_id"
        const val EXTRA_MEDIA_TYPE  = "media_type"
    }

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()

        val episodeUrl = intent.getStringExtra(EXTRA_EPISODE_URL) ?: ""
        val title      = intent.getStringExtra(EXTRA_TITLE)       ?: ""

        setContent {
            DendePlayTheme {
                var showCastPicker by remember { mutableStateOf(false) }
                val devices     by castManager.devices.collectAsStateWithLifecycle()
                val castState   by castManager.state.collectAsStateWithLifecycle()
                val discovering by castManager.discovering.collectAsStateWithLifecycle()

                PlayerScreenV11(
                    episodeUrl = episodeUrl,
                    provider   = intent.getStringExtra(EXTRA_PROVIDER)    ?: "",
                    episodeNum = intent.getIntExtra(EXTRA_EPISODE_NUM, 1),
                    mediaId    = intent.getStringExtra(EXTRA_MEDIA_ID)    ?: "",
                    title      = title,
                    malId      = intent.getIntExtra(EXTRA_MAL_ID, 0),
                    mediaType  = intent.getStringExtra(EXTRA_MEDIA_TYPE)  ?: "anime",
                    onBack     = { finish() },
                    onEnterPiP = { enterPiP() },
                    onCastClick = { showCastPicker = true }
                )

                if (showCastPicker) {
                    CastPickerSheet(
                        devices      = devices,
                        state        = castState,
                        discovering  = discovering,
                        onConnect    = { device ->
                            castManager.connect(device)
                            // Inicia cast assim que conectar
                            castManager.cast(
                                videoUrl = episodeUrl,
                                title    = title,
                            )
                        },
                        onDisconnect = { castManager.disconnect() },
                        onRefresh    = { castManager.refreshDevices() },
                        onDismiss    = { showCastPicker = false },
                        onPowerSaveToggle = { enabled -> castManager.setPowerSave(enabled) },
                    )
                }
            }
        }
    }

    override fun onUserLeaveHint() { super.onUserLeaveHint(); enterPiP() }

    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            runCatching { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16,9)).build()) }
    }
}
