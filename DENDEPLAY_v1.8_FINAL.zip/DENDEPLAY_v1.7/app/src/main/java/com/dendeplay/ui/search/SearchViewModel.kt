package com.dendeplay.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.SearchResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

sealed class SearchUiState {
    object Idle    : SearchUiState()
    object Loading : SearchUiState()
    object Empty   : SearchUiState()
    data class Results(val items: List<SearchResult>) : SearchUiState()
    data class Error(val message: String)             : SearchUiState()
}

@HiltViewModel
class SearchViewModel @Inject constructor(private val repo: MediaRepository) : ViewModel() {
    private val _query  = MutableStateFlow("")
    private val _filter = MutableStateFlow("todos")
    private val _state  = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    private var job: Job? = null

    val query: StateFlow<String>          = _query.asStateFlow()
    val filter: StateFlow<String>         = _filter.asStateFlow()
    val state: StateFlow<SearchUiState>   = _state.asStateFlow()

    fun onQueryChange(q: String) {
        _query.value = q
        if (q.length < 2) { _state.value = SearchUiState.Idle; return }
        job?.cancel()
        job = viewModelScope.launch { delay(320); doSearch() }
    }
    fun setFilter(f: String) { _filter.value = f; if (_query.value.length >= 2) doSearch() }
    fun search() = doSearch()

    private fun doSearch() {
        val q = _query.value.trim(); if (q.isEmpty()) return
        viewModelScope.launch {
            _state.value = SearchUiState.Loading
            repo.searchUniversal(q).onSuccess { all ->
                val filtered = when (_filter.value) {
                    "anime" -> all.filter { it.mediaType == "anime" }
                    "movie" -> all.filter { it.mediaType == "movie" }
                    "tv"    -> all.filter { it.mediaType == "tv" }
                    else    -> all
                }
                _state.value = if (filtered.isEmpty()) SearchUiState.Empty else SearchUiState.Results(filtered)
            }.onFailure { _state.value = SearchUiState.Error(it.message ?: "Erro") }
        }
    }
}
