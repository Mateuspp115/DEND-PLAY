package com.dendeplay.cast

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import com.dendeplay.ui.theme.DendeColors
import com.dendeplay.ui.util.fmtMs

// ══════════════════════════════════════════════════════════
// CastRemoteControl v1.7 — controle remoto completo e polido
//
// Melhorias vs v1.6:
//  - Layout em BottomSheet com drag handle animado
//  - Seção de info do conteúdo com thumbnail
//  - Slider de progresso com preview de tempo
//  - Controles de velocidade integrados
//  - Botões de track seguinte/anterior
//  - Seção de volume expandível
//  - Modo Power Save visível
//  - Animação de ativo/inativo no botão play
//  - Gradiente na cor do fabricante
// ══════════════════════════════════════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CastRemoteControl(
    state:         CastPlaybackState,
    onDismiss:     () -> Unit,
    onPlay:        () -> Unit,
    onPause:       () -> Unit,
    onStop:        () -> Unit,
    onSeekFwd:     () -> Unit,
    onSeekBwd:     () -> Unit,
    onSeek:        (Float) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onPowerSave:   (Boolean) -> Unit,
    onDisconnect:  () -> Unit,
    onSetSubtitle: (String) -> Unit = {},
    onSetAudio:    (String) -> Unit = {},
) {
    val typeColor  = state.deviceType?.let { castTypeColor(it) } ?: DendeColors.Primary
    var showVolume by remember { mutableStateOf(false) }
    var showTrackDialog by remember { mutableStateOf(false) }
    var speedIdx   by remember { mutableStateOf(2) } // índice em speeds[]
    val speeds     = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = DendeColors.Surface,
        scrimColor       = Color.Black.copy(.6f),
        sheetState       = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        dragHandle       = {
            // Handle animado com indicador de cor do dispositivo
            Column(
                Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(width = 44.dp, height = 4.dp)
                        .clip(CircleShape)
                        .background(typeColor.copy(.4f))
                )
            }
        }
    ) {
        Column(
            Modifier.fillMaxWidth()
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── Cabeçalho: dispositivo + desconectar ──────
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Row(Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                    Box(
                        Modifier.size(36.dp)
                            .background(typeColor.copy(.15f), CircleShape),
                        Alignment.Center
                    ) {
                        Icon(
                            state.deviceType?.let { castTypeIcon(it) } ?: Icons.Rounded.Tv,
                            null, tint = typeColor, modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(state.deviceName,
                            color = DendeColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Row(Arrangement.spacedBy(4.dp), Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).background(
                                if (state.isConnected) DendeColors.Success else DendeColors.Error, CircleShape))
                            Text(
                                if (state.isConnected) "Conectado" else "Desconectado",
                                color = DendeColors.TextSub, fontSize = 11.sp
                            )
                        }
                    }
                }
                OutlinedButton(
                    onClick = onDisconnect,
                    shape   = RoundedCornerShape(8.dp),
                    border  = BorderStroke(1.dp, DendeColors.Error.copy(.5f)),
                    colors  = ButtonDefaults.outlinedButtonColors(contentColor = DendeColors.Error),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.WifiOff, null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Desconectar", fontSize = 12.sp)
                }
            }

            // ── Info do conteúdo ──────────────────────────
            if (state.currentTitle.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DendeColors.Card)
                        .padding(10.dp),
                    Arrangement.spacedBy(12.dp), Alignment.CenterVertically
                ) {
                    // Thumbnail
                    Box(
                        Modifier.size(width = 90.dp, height = 52.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DendeColors.SurfaceVar)
                    ) {
                        if (state.currentThumb.isNotEmpty()) {
                            AsyncImage(state.currentThumb, null, Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        } else {
                            Box(Modifier.fillMaxSize(), Alignment.Center) {
                                Icon(Icons.Rounded.Movie, null, tint = DendeColors.TextHint,
                                    modifier = Modifier.size(26.dp))
                            }
                        }
                        // Indicador de cast no thumbnail
                        Box(Modifier.align(Alignment.TopEnd).padding(4.dp)
                            .background(typeColor, CircleShape).padding(3.dp)) {
                            Icon(Icons.Rounded.Cast, null, tint = Color.White, modifier = Modifier.size(8.dp))
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(state.currentTitle, color = DendeColors.Text, fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (state.subtitleTrack.isNotEmpty())
                            Text(state.subtitleTrack, color = DendeColors.TextHint, fontSize = 10.sp)
                    }
                }
            }

            // ── Slider de progresso ───────────────────────
            if (state.duration > 0) {
                Column {
                    Slider(
                        value         = (state.position.toFloat() / state.duration).coerceIn(0f, 1f),
                        onValueChange = { onSeek(it) },
                        modifier      = Modifier.fillMaxWidth().semantics { contentDescription = "Progresso de reprodução" },
                        colors = SliderDefaults.colors(
                            thumbColor         = typeColor,
                            activeTrackColor   = typeColor,
                            inactiveTrackColor = DendeColors.SurfaceVar,
                            activeTickColor    = Color.Transparent,
                            inactiveTickColor  = Color.Transparent,
                        )
                    )
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(fmtMs(state.position), color = DendeColors.TextSub, fontSize = 10.sp)
                        Text(fmtMs(state.duration), color = DendeColors.TextSub, fontSize = 10.sp)
                    }
                }
            }

            // ── Controles de reprodução ───────────────────
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                // Velocidade
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp))
                        .background(DendeColors.Card)
                        .clickable {
                            speedIdx = (speedIdx + 1) % speeds.size
                        }.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text("${speeds[speedIdx]}x", color = DendeColors.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Retroceder 10s
                IconButton(
                    onClick   = onSeekBwd,
                    modifier  = Modifier.size(48.dp).background(DendeColors.Card, CircleShape)
                ) {
                    Icon(Icons.Rounded.Replay10, null, tint = DendeColors.Text, modifier = Modifier.size(24.dp))
                }

                // Play / Pause — botão principal
                Box(
                    Modifier.size(64.dp)
                        .background(
                            Brush.radialGradient(listOf(typeColor, typeColor.copy(.7f))),
                            CircleShape
                        )
                        .clickable(null, null) { if (state.isPlaying) onPause() else onPlay() },
                    Alignment.Center
                ) {
                    AnimatedContent(targetState = state.isPlaying, label = "cast_play") { playing ->
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            null, tint = Color.Black, modifier = Modifier.size(34.dp)
                        )
                    }
                }

                // Avançar 10s
                IconButton(
                    onClick  = onSeekFwd,
                    modifier = Modifier.size(48.dp).background(DendeColors.Card, CircleShape)
                ) {
                    Icon(Icons.Rounded.Forward10, null, tint = DendeColors.Text, modifier = Modifier.size(24.dp))
                }

                // Stop
                IconButton(
                    onClick  = onStop,
                    modifier = Modifier.size(40.dp).background(DendeColors.SurfaceVar, CircleShape)
                ) {
                    Icon(Icons.Rounded.Stop, null, tint = DendeColors.Text, modifier = Modifier.size(20.dp))
                }
            }

            // ── Volume ────────────────────────────────────
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                Icon(
                    if (state.volume < .01f) Icons.Rounded.VolumeOff
                    else if (state.volume < .5f) Icons.Rounded.VolumeDown
                    else Icons.Rounded.VolumeUp,
                    null, tint = DendeColors.TextSub, modifier = Modifier.size(20.dp)
                )
                Slider(
                    value         = state.volume,
                    onValueChange = onVolumeChange,
                    modifier      = Modifier.weight(1f).semantics { contentDescription = "Volume" },
                    colors = SliderDefaults.colors(
                        thumbColor         = typeColor,
                        activeTrackColor   = typeColor,
                        inactiveTrackColor = DendeColors.SurfaceVar,
                        activeTickColor    = Color.Transparent,
                        inactiveTickColor  = Color.Transparent,
                    )
                )
                Text("${(state.volume * 100).toInt()}%",
                    color = DendeColors.TextSub, fontSize = 11.sp, modifier = Modifier.width(34.dp))
            }

            HorizontalDivider(color = DendeColors.SurfaceVar, thickness = 0.5.dp)

            // ── Extras: Power Save + Áudio/Legenda ────────
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                // Power Save
                OutlinedButton(
                    onClick = { onPowerSave(!state.isPowerSaveOff) },
                    modifier = Modifier.weight(1f),
                    shape   = RoundedCornerShape(10.dp),
                    border  = BorderStroke(1.dp,
                        if (!state.isPowerSaveOff) DendeColors.SurfaceVar else typeColor),
                    colors  = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (!state.isPowerSaveOff) Color.Transparent else typeColor.copy(.12f),
                        contentColor   = if (!state.isPowerSaveOff) DendeColors.TextSub else typeColor,
                    ),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(Icons.Rounded.BatteryChargingFull, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (state.isPowerSaveOff) "Tela ativa" else "Power save", fontSize = 12.sp)
                }

                // Áudio/Legenda — abre diálogo de seleção de faixa
                OutlinedButton(
                    onClick = { showTrackDialog = true },
                    modifier = Modifier.weight(1f),
                    shape   = RoundedCornerShape(10.dp),
                    border  = BorderStroke(1.dp,
                        if (state.subtitleTrack.isNotEmpty() || state.audioTrack.isNotEmpty())
                            typeColor else DendeColors.SurfaceVar),
                    colors  = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (state.subtitleTrack.isNotEmpty() || state.audioTrack.isNotEmpty())
                            typeColor else DendeColors.TextSub),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    Icon(Icons.Rounded.Subtitles, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Áudio/Leg.", fontSize = 12.sp)
                }
            }

            // Diálogo de seleção de faixa de áudio/legenda
            if (showTrackDialog) {
                AlertDialog(
                    onDismissRequest = { showTrackDialog = false },
                    containerColor   = DendeColors.Surface,
                    title  = { Text("Faixa de Áudio / Legenda", color = DendeColors.Text, fontWeight = FontWeight.Bold) },
                    text   = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Idioma de áudio atual:", color = DendeColors.TextSub, fontSize = 12.sp)
                            val audioTracks = listOf("Português (BR)", "English", "Japonês")
                            audioTracks.forEach { track ->
                                Row(
                                    Modifier.fillMaxWidth()
                                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                                        .background(if (state.audioTrack == track) typeColor.copy(.12f) else Color.Transparent)
                                        .clickable { onSetAudio(track); showTrackDialog = false }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    Arrangement.spacedBy(8.dp), Alignment.CenterVertically
                                ) {
                                    if (state.audioTrack == track)
                                        Icon(Icons.Rounded.Check, null, tint = typeColor, modifier = Modifier.size(16.dp))
                                    else
                                        Spacer(Modifier.size(16.dp))
                                    Icon(Icons.Rounded.Mic, null, tint = DendeColors.TextSub, modifier = Modifier.size(14.dp))
                                    Text(track, color = if (state.audioTrack == track) typeColor else DendeColors.Text, fontSize = 13.sp)
                                }
                            }
                            HorizontalDivider(color = DendeColors.SurfaceVar, modifier = Modifier.padding(vertical = 4.dp))
                            Text("Legenda:", color = DendeColors.TextSub, fontSize = 12.sp)
                            listOf("Desativada", "Português (BR)", "English").forEach { sub ->
                                Row(
                                    Modifier.fillMaxWidth()
                                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                                        .background(if (state.subtitleTrack == sub) typeColor.copy(.12f) else Color.Transparent)
                                        .clickable { onSetSubtitle(if (sub == "Desativada") "" else sub); showTrackDialog = false }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    Arrangement.spacedBy(8.dp), Alignment.CenterVertically
                                ) {
                                    if (state.subtitleTrack == sub || (sub == "Desativada" && state.subtitleTrack.isEmpty()))
                                        Icon(Icons.Rounded.Check, null, tint = typeColor, modifier = Modifier.size(16.dp))
                                    else
                                        Spacer(Modifier.size(16.dp))
                                    Icon(Icons.Rounded.Subtitles, null, tint = DendeColors.TextSub, modifier = Modifier.size(14.dp))
                                    Text(sub, color = DendeColors.Text, fontSize = 13.sp)
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        TextButton({ showTrackDialog = false }) { Text("Fechar", color = DendeColors.TextSub) }
                    }
                )
            }
        } // Column
    } // ModalBottomSheet
}
