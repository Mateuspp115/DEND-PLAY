package com.dendeplay.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.navigation.*
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.dendeplay.ui.components.DendeLogo
import com.dendeplay.ui.credits.CreditsScreen
import com.dendeplay.ui.travel.TravelModeScreen
import com.dendeplay.ui.voice.VoiceAssistantScreen
import com.dendeplay.ui.detail.DetailScreen
import com.dendeplay.ui.downloads.DownloadsScreen
import com.dendeplay.ui.genres.GenreTabsScreen
import com.dendeplay.ui.home.HomeScreen
import com.dendeplay.ui.player.PlayerActivity
import com.dendeplay.ui.profile.ProfileScreen
import com.dendeplay.ui.search.SearchScreen
import com.dendeplay.ui.social.ChatScreen
import com.dendeplay.ui.theme.DendeColors
import com.dendeplay.ui.theme.DendePlayTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle     = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            DendePlayTheme {
                DendePlayApp { url, prov, ep, mid, title, malId, mediaType ->
                    startActivity(Intent(this, PlayerActivity::class.java).apply {
                        putExtra(PlayerActivity.EXTRA_EPISODE_URL, url)
                        putExtra(PlayerActivity.EXTRA_PROVIDER,    prov)
                        putExtra(PlayerActivity.EXTRA_EPISODE_NUM, ep)
                        putExtra(PlayerActivity.EXTRA_MEDIA_ID,    mid)
                        putExtra(PlayerActivity.EXTRA_TITLE,       title)
                        putExtra(PlayerActivity.EXTRA_MAL_ID,      malId)
                        putExtra(PlayerActivity.EXTRA_MEDIA_TYPE,  mediaType)
                    })
                }
            }
        }
    }
}

sealed class Screen(val route: String) {
    object Home      : Screen("home")
    object Genres    : Screen("genres")
    object Search    : Screen("search")
    object Downloads : Screen("downloads")
    object Profile   : Screen("profile")
    object Credits   : Screen("credits")
    object Detail    : Screen("detail/{provider}/{id}") { fun go(p:String,id:String)="detail/$p/$id" }
    object Travel  : Screen("travel")
    object Voice   : Screen("voice")
    object Chat      : Screen("chat/{mediaId}/{title}") { fun go(id:String,t:String)="chat/$id/${java.net.URLEncoder.encode(t,"UTF-8")}" }
}

private val bottomTabs = listOf(
    Triple(Screen.Home,      "Início",    Icons.Rounded.Home),
    Triple(Screen.Genres,    "Gêneros",   Icons.Rounded.Category),
    Triple(Screen.Search,    "Buscar",    Icons.Rounded.Search),
    Triple(Screen.Downloads, "Downloads", Icons.Rounded.Download),
    Triple(Screen.Profile,   "Perfil",    Icons.Rounded.Person),
)

@Composable
fun DendePlayApp(onOpenPlayer: (String,String,Int,String,String,Int,String)->Unit) {
    val nav = rememberNavController()
    val back by nav.currentBackStackEntryAsState()
    val cur = back?.destination
    val showBar = bottomTabs.any { it.first.route == cur?.route }

    Scaffold(
        containerColor = DendeColors.Background,
        bottomBar = {
            AnimatedVisibility(showBar, enter=slideInVertically{it}, exit=slideOutVertically{it}) {
                NavigationBar(containerColor=Color(0xFF0A0A0A), tonalElevation=0.dp,
                    modifier=Modifier.navigationBarsPadding().drawWithContent{
                        drawContent()
                        drawLine(DendeColors.Primary.copy(.18f),Offset(0f,0f),Offset(size.width,0f),1.dp.toPx())
                    }) {
                    bottomTabs.forEach { (screen,label,icon) ->
                        val sel = cur?.hierarchy?.any{it.route==screen.route}==true
                        NavigationBarItem(selected=sel, onClick={
                            nav.navigate(screen.route){
                                popUpTo(nav.graph.findStartDestination().id){saveState=true}
                                launchSingleTop=true; restoreState=true
                            }
                        }, label={Text(label,fontSize=10.sp,fontWeight=if(sel) FontWeight.Bold else FontWeight.Normal)},
                        icon={
                            Box(contentAlignment=Alignment.Center){
                                AnimatedVisibility(sel,enter=scaleIn(spring(Spring.DampingRatioMediumBouncy)),exit=scaleOut()){
                                    Box(Modifier.size(38.dp,26.dp).background(DendeColors.Primary.copy(.16f),
                                        androidx.compose.foundation.shape.RoundedCornerShape(50)))
                                }
                                if(screen==Screen.Home&&sel) DendeLogo(22.dp) else Icon(icon,label,Modifier.size(22.dp))
                            }
                        }, colors=NavigationBarItemDefaults.colors(
                            selectedIconColor=DendeColors.Primary,unselectedIconColor=DendeColors.TextSub,
                            selectedTextColor=DendeColors.Primary,unselectedTextColor=Color(0xFF555555),
                            indicatorColor=Color.Transparent))
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, Screen.Home.route,
            Modifier.padding(bottom=if(showBar) pad.calculateBottomPadding() else 0.dp),
            enterTransition={slideInHorizontally{it}+fadeIn(tween(250))},
            exitTransition={slideOutHorizontally{-it/3}+fadeOut(tween(200))},
            popEnterTransition={slideInHorizontally{-it/3}+fadeIn(tween(250))},
            popExitTransition={slideOutHorizontally{it}+fadeOut(tween(200))},
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onMediaClick   = { nav.navigate(Screen.Detail.go(it.provider,it.id)) },
                    onSearchClick  = { nav.navigate(Screen.Search.route) },
                    onProfileClick = { nav.navigate(Screen.Profile.route) },
                )
            }
            composable(Screen.Genres.route) {
                GenreTabsScreen(onMediaClick = { nav.navigate(Screen.Detail.go(it.provider,it.id)) })
            }
            composable(Screen.Search.route) {
                SearchScreen(
                    onMediaClick = { nav.navigate(Screen.Detail.go(it.provider,it.id)) },
                    onBack       = { nav.popBackStack() },
                )
            }
            composable(Screen.Downloads.route) { DownloadsScreen() }
            composable(Screen.Profile.route) {
                ProfileScreen(
                    onMediaClick   = { nav.navigate(Screen.Detail.go(it.provider,it.id)) },
                    onCreditsClick = { nav.navigate(Screen.Credits.route) },
                )
            }
            composable(Screen.Credits.route) { CreditsScreen(onBack = { nav.popBackStack() }) }
            composable(Screen.Detail.route,
                arguments=listOf(navArgument("provider"){type=NavType.StringType},navArgument("id"){type=NavType.StringType})
            ) { b ->
                val provider = b.arguments?.getString("provider")?:""
                val id       = b.arguments?.getString("id")?:""
                DetailScreen(
                    mediaId=id, provider=provider,
                    onBack={nav.popBackStack()},
                    onPlayEpisode={ep,det->onOpenPlayer(ep.url,provider,ep.number,det.id,det.title,det.malId,det.mediaType)},
                    onOpenChat={mid,title->nav.navigate(Screen.Chat.go(mid,title))},
                )
            }
            composable(Screen.Travel.route) {
                TravelModeScreen(onBack = { nav.popBackStack() })
            }
            composable(Screen.Voice.route) {
                VoiceAssistantScreen(onBack = { nav.popBackStack() })
            }
            composable(Screen.Chat.route,
                arguments=listOf(navArgument("mediaId"){type=NavType.StringType},navArgument("title"){type=NavType.StringType})
            ) { b ->
                val mediaId = b.arguments?.getString("mediaId")?:""
                val title   = java.net.URLDecoder.decode(b.arguments?.getString("title")?:"","UTF-8")
                ChatScreen(mediaId=mediaId, mediaTitle=title, onBack={nav.popBackStack()})
            }
        }
    }
}
