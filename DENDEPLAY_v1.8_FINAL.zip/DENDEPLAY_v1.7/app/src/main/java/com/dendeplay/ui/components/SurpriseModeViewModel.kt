package com.dendeplay.ui.components

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.api.UserBehavior
import com.dendeplay.api.providers.LocalDataProvider
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.SearchResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import kotlin.random.Random

sealed class SurpriseMode {
    object Favorite : SurpriseMode()  // baseado no histórico
    object Random   : SurpriseMode()  // qualquer coisa
    object New      : SurpriseMode()  // algo que nunca assistiu
}

sealed class SurpriseState {
    object Idle                                    : SurpriseState()
    object Loading                                 : SurpriseState()
    data class Found(val result: SearchResult)     : SurpriseState()
    data class Error(val message: String)          : SurpriseState()
}

@HiltViewModel
class SurpriseModeViewModel @Inject constructor(
    private val repo:          MediaRepository,
    private val localProvider: LocalDataProvider,
) : ViewModel() {

    private val _state = MutableStateFlow<SurpriseState>(SurpriseState.Idle)
    val state: StateFlow<SurpriseState> = _state.asStateFlow()

    // ── Buscar surpresa ───────────────────────────────────

    fun getSurprise(mode: SurpriseMode) {
        viewModelScope.launch {
            _state.value = SurpriseState.Loading
            runCatching {
                val result = when (mode) {
                    is SurpriseMode.Favorite -> smartSurprise()
                    is SurpriseMode.Random   -> randomSurprise()
                    is SurpriseMode.New      -> newSurprise()
                }
                if (result != null) _state.value = SurpriseState.Found(result)
                else _state.value = SurpriseState.Error("Nenhum conteúdo encontrado")
            }.onFailure {
                _state.value = SurpriseState.Error(it.message ?: "Erro")
            }
        }
    }

    fun reset() { _state.value = SurpriseState.Idle }

    // ── Feedback do usuário ───────────────────────────────

    fun recordFeedback(item: SearchResult, watchedPct: Int) {
        viewModelScope.launch {
            localProvider.sendUserBehavior(
                UserBehavior(
                    mediaId    = item.id,
                    mediaType  = item.mediaType,
                    genre      = item.title,
                    watchedPct = watchedPct,
                    completed  = watchedPct >= 90,
                )
            )
        }
    }

    // ── Lógica inteligente ─────────────────────────────────

    /**
     * Algoritmo de surpresa:
     *   70% = gênero favorito do usuário
     *   20% = gênero moderado
     *   10% = novo (exploração)
     */
    private suspend fun smartSurprise(): SearchResult? {
        val favoriteGenres = localProvider.getFavoriteGenres()
        val weights        = localProvider.getSurpriseWeights()

        val roll = Random.nextFloat()
        val genre = when {
            roll < 0.70f && favoriteGenres.isNotEmpty() ->
                favoriteGenres[Random.nextInt(favoriteGenres.size.coerceAtMost(2))]
            roll < 0.90f && favoriteGenres.size > 2 ->
                favoriteGenres[Random.nextInt(2, favoriteGenres.size)]
            else ->
                listOf("Ficção Científica", "Terror", "Suspense", "Drama", "Aventura").random()
        }

        return withTimeoutOrNull(8_000) {
            repo.searchByType(genre, "anime").getOrElse { emptyList() }
        }?.randomOrNull()
    }

    private suspend fun randomSurprise(): SearchResult? {
        val genres = listOf("ação","comédia","romance","terror","drama","aventura","fantasia")
        return withTimeoutOrNull(8_000) {
            repo.searchUniversal(genres.random()).getOrElse { emptyList() }
        }?.randomOrNull()
    }

    private suspend fun newSurprise(): SearchResult? {
        val watched = repo.getFavorites().map { it.id }.toSet()
        return withTimeoutOrNull(8_000) {
            repo.getTrending("anime").getOrElse { emptyList() }
        }
            ?.filterNot { it.id in watched }
            ?.randomOrNull()
            ?: randomSurprise()
    }
}
