package com.dendeplay.ui.components

import android.content.Intent
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.dendeplay.domain.model.SearchResult
import com.dendeplay.ui.theme.DendeColors

@Composable
fun SurpriseModeCard(
    onSurprise:   (SearchResult) -> Unit,
    recentGenres: List<String>,
    vm:           SurpriseModeViewModel = hiltViewModel(),
) {
    val state    by vm.state.collectAsStateWithLifecycle()
    var spinning by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(if(spinning) 720f else 0f, tween(800, easing=FastOutSlowInEasing), label="spin")
    val scale    by animateFloatAsState(if(spinning) 1.05f else 1f, spring(Spring.DampingRatioMediumBouncy), label="sc")

    // Quando o ViewModel encontrar um resultado, entrega e para o spin
    LaunchedEffect(state) {
        if (state is SurpriseState.Found) {
            onSurprise((state as SurpriseState.Found).result)
            spinning = false
            vm.reset()
        } else if (state is SurpriseState.Error || state is SurpriseState.Idle) {
            spinning = false
        }
    }

    Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), CardDefaults.cardColors(DendeColors.Surface)) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(DendeColors.Primary.copy(.07f), DendeColors.Secondary.copy(.04f)))).padding(20.dp)) {
            Column(horizontalAlignment=Alignment.CenterHorizontally, modifier=Modifier.fillMaxWidth()) {
                Text("Modo Surpresa",color=DendeColors.Text,fontSize=18.sp,fontWeight=FontWeight.Black)
                Text("Não sabe o que assistir?",color=DendeColors.TextSub,fontSize=12.sp)
                Spacer(Modifier.height(16.dp))
                Box(
                    Modifier.size(76.dp).rotate(rotation).scale(scale)
                        .background(Brush.radialGradient(listOf(DendeColors.Primary, DendeColors.Secondary)), CircleShape)
                        .clickable {
                            if (!spinning && state !is SurpriseState.Loading) {
                                spinning = true
                                vm.getSurprise(SurpriseMode.Favorite)
                            }
                        },
                    Alignment.Center
                ) {
                    if (state is SurpriseState.Loading) {
                        CircularProgressIndicator(color=Color.Black, strokeWidth=2.dp, modifier=Modifier.size(28.dp))
                    } else {
                        Icon(Icons.Rounded.Shuffle, null, tint=Color.Black, modifier=Modifier.size(34.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    if (state is SurpriseState.Loading) "Buscando conteúdo…"
                    else "Toque para descobrir o conteúdo do dia",
                    color=DendeColors.TextHint, fontSize=11.sp, textAlign=TextAlign.Center
                )
                if (state is SurpriseState.Error) {
                    Spacer(Modifier.height(6.dp))
                    Text("Sem conexão. Tente novamente.", color=DendeColors.Error, fontSize=10.sp)
                }
                if(recentGenres.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Baseado em: ${recentGenres.take(3).joinToString(", ")}",color=DendeColors.Primary,fontSize=10.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchPartySheet(onDismiss: ()->Unit, onCreateRoom: ()->String, onJoinRoom: (String)->Unit) {
    var mode by remember { mutableStateOf<String?>(null) }
    var roomCode by remember { mutableStateOf("") }
    var joinCode by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest=onDismiss, containerColor=DendeColors.Surface) {
        Column(Modifier.fillMaxWidth().padding(horizontal=20.dp).navigationBarsPadding(), horizontalAlignment=Alignment.CenterHorizontally) {
            Text("Watch Party",color=DendeColors.Text,fontSize=20.sp,fontWeight=FontWeight.Black)
            Text("Assista junto com amigos",color=DendeColors.TextSub,fontSize=12.sp)
            Spacer(Modifier.height(20.dp))
            when(mode) {
                null -> Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                    listOf("Criar Sala" to Icons.Rounded.AddCircle, "Entrar" to Icons.Rounded.GroupAdd).forEachIndexed { i, (label, icon) ->
                        Card(Modifier.weight(1f).clickable{ if(i==0){mode="create";roomCode=onCreateRoom()} else mode="join" },
                            RoundedCornerShape(14.dp), CardDefaults.cardColors(DendeColors.Card)) {
                            Column(Modifier.padding(14.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                                Icon(icon,null,tint=DendeColors.Primary,modifier=Modifier.size(30.dp))
                                Spacer(Modifier.height(8.dp))
                                Text(label,color=DendeColors.Text,fontSize=13.sp,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                }
                "create" -> {
                    val context = LocalContext.current
                    Icon(Icons.Rounded.QrCode2,null,tint=DendeColors.Primary,modifier=Modifier.size(60.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Código da Sala",color=DendeColors.TextSub,fontSize=12.sp)
                    Box(Modifier.background(DendeColors.SurfaceVar,RoundedCornerShape(12.dp)).padding(horizontal=28.dp,vertical=14.dp)) {
                        Text(roomCode.uppercase(),color=DendeColors.Primary,fontSize=28.sp,fontWeight=FontWeight.Black,letterSpacing=8.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT,
                                    "Entre na minha Watch Party do DENDÊPLAY! Código: ${roomCode.uppercase()}")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Compartilhar código"))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(10.dp),
                        colors   = ButtonDefaults.buttonColors(DendeColors.Primary)
                    ) {
                        Icon(Icons.Rounded.Share,null,tint=Color.Black,modifier=Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp)); Text("Compartilhar Código",color=Color.Black,fontWeight=FontWeight.Black)
                    }
                }
                "join" -> {
                    OutlinedTextField(joinCode, {if(it.length<=6) joinCode=it.uppercase()},
                        Modifier.fillMaxWidth(), label={Text("Código da Sala")}, singleLine=true, shape=RoundedCornerShape(12.dp),
                        colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=DendeColors.Primary,unfocusedBorderColor=DendeColors.SurfaceVar,focusedTextColor=DendeColors.Text,unfocusedTextColor=DendeColors.Text))
                    Spacer(Modifier.height(14.dp))
                    Button(onClick={if(joinCode.length==6) onJoinRoom(joinCode)}, enabled=joinCode.length==6,
                        modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(10.dp), colors=ButtonDefaults.buttonColors(DendeColors.Primary)) {
                        Text("Entrar na Sala",color=Color.Black,fontWeight=FontWeight.Black)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
