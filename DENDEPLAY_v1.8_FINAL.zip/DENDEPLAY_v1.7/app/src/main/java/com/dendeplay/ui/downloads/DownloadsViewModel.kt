package com.dendeplay.ui.downloads

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.DownloadItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    app: Application,
    private val repo: MediaRepository,
) : AndroidViewModel(app) {

    private val _downloads   = MutableStateFlow<List<DownloadItem>>(emptyList())
    private val _storageUsed = MutableStateFlow("0 MB")
    val downloads:   StateFlow<List<DownloadItem>> = _downloads.asStateFlow()
    val storageUsed: StateFlow<String>             = _storageUsed.asStateFlow()

    // Receptor de broadcasts do DownloadService (substitui polling)
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_DOWNLOAD_PROGRESS,
                ACTION_DOWNLOAD_COMPLETE,
                ACTION_DOWNLOAD_FAILED -> refresh()
            }
        }
    }

    init {
        // Registro do receiver
        val filter = IntentFilter().apply {
            addAction(ACTION_DOWNLOAD_PROGRESS)
            addAction(ACTION_DOWNLOAD_COMPLETE)
            addAction(ACTION_DOWNLOAD_FAILED)
        }
        // Registro do receiver — Android 14+ exige flag explícita
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getApplication<Application>().registerReceiver(
                downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            getApplication<Application>().registerReceiver(downloadReceiver, filter)
        }

        // Carga inicial
        refresh()

        // Atualização periódica leve apenas quando há downloads ativos (30s)
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                val hasActive = _downloads.value.any { it.status == "active" }
                if (hasActive) refresh()
            }
        }
    }

    fun refresh() {
        _downloads.value = repo.getDownloads()
        val dir  = File(getApplication<Application>().filesDir, "downloads")
        val used = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        _storageUsed.value = "Usado: %.0f MB".format(used / 1024.0 / 1024.0)
    }

    fun pause(id: String)  { repo.pauseDownload(id);  refresh() }
    fun resume(id: String) { repo.resumeDownload(id); refresh() }
    fun cancel(id: String) { repo.cancelDownload(id); refresh() }

    override fun onCleared() {
        super.onCleared()
        runCatching { getApplication<Application>().unregisterReceiver(downloadReceiver) }
    }

    companion object {
        const val ACTION_DOWNLOAD_PROGRESS = "com.dendeplay.DOWNLOAD_PROGRESS"
        const val ACTION_DOWNLOAD_COMPLETE = "com.dendeplay.DOWNLOAD_COMPLETE"
        const val ACTION_DOWNLOAD_FAILED   = "com.dendeplay.DOWNLOAD_FAILED"
    }
}
