package com.dendeplay.ui.travel

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.dendeplay.ui.components.DendeLoadingIndicator
import com.dendeplay.ui.components.dendeClickable
import com.dendeplay.ui.theme.DendeColors

@Composable
fun TravelModeScreen(onBack: ()->Unit, vm: TravelViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val gb     by vm.gbReserved.collectAsStateWithLifecycle()
    val active by vm.isActive.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(DendeColors.Background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            IconButton(onBack){Icon(Icons.Rounded.ArrowBack,null,tint=DendeColors.Text)}
            Column(Modifier.weight(1f)) {
                Text("Modo Viagem",color=DendeColors.Text,fontSize=20.sp,fontWeight=FontWeight.Black)
                Text("Downloads automáticos offline",color=DendeColors.TextSub,fontSize=12.sp)
            }
            Switch(active,vm::toggleMode,colors=SwitchDefaults.colors(checkedThumbColor=DendeColors.Background,checkedTrackColor=DendeColors.Primary,uncheckedTrackColor=DendeColors.SurfaceVar))
        }
        AnimatedVisibility(active) {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp)
                .background(DendeColors.Primary.copy(.1f),RoundedCornerShape(10.dp)).padding(12.dp),
                Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                Icon(Icons.Rounded.AirplaneTicket,null,tint=DendeColors.Primary,modifier=Modifier.size(20.dp))
                Text("Modo Viagem ativado",color=DendeColors.Primary,fontSize=13.sp,fontWeight=FontWeight.Bold)
            }
        }
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
            // GB selector
            item {
                Card(shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(DendeColors.Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Espaço a Reservar",color=DendeColors.Text,fontSize=15.sp,fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                            listOf(1,2,5,10).forEach { g ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if(gb==g) DendeColors.Primary else DendeColors.SurfaceVar)
                                    .dendeClickable{vm.setGB(g)}.padding(vertical=12.dp), Alignment.Center) {
                                    Text("${g}GB",color=if(gb==g) Color.Black else DendeColors.TextSub,fontWeight=if(gb==g) FontWeight.Black else FontWeight.Normal,fontSize=14.sp)
                                }
                            }
                        }
                    }
                }
            }
            // Plano
            item {
                Card(shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(DendeColors.Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("O que será baixado",color=DendeColors.Text,fontSize=15.sp,fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        val eps = when{gb>=10->30;gb>=5->15;gb>=2->6;else->3}
                        listOf("$eps próximos episódios das séries" to Icons.Rounded.VideoLibrary,
                               "Top 10 trending agora" to Icons.Rounded.TrendingUp,
                               "5 recomendações personalizadas" to Icons.Rounded.Recommend,
                               "Qualidade máxima disponível" to Icons.Rounded.HighQuality).forEach { (label,icon) ->
                            Row(Modifier.fillMaxWidth().padding(vertical=5.dp), Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                                Icon(icon,null,tint=DendeColors.TextSub,modifier=Modifier.size(16.dp))
                                Text(label,color=DendeColors.TextSub,fontSize=12.sp,modifier=Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Button(onClick=vm::startDownload, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(10.dp), colors=ButtonDefaults.buttonColors(DendeColors.Primary)) {
                            Icon(Icons.Rounded.FlightTakeoff,null,modifier=Modifier.size(18.dp),tint=Color.Black)
                            Spacer(Modifier.width(8.dp)); Text("Preparar para Viagem",color=Color.Black,fontWeight=FontWeight.Black)
                        }
                    }
                }
            }
            // Progresso
            if(state.isDownloading) item {
                Card(shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(DendeColors.Surface)) {
                    Row(Modifier.padding(14.dp), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
                        DendeLoadingIndicator(Modifier.size(32.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Baixando…",color=DendeColors.Text,fontSize=14.sp,fontWeight=FontWeight.Bold)
                            Text(state.currentTitle,color=DendeColors.TextSub,fontSize=11.sp)
                        }
                        Text("${state.overallProgress}%",color=DendeColors.Primary,fontSize=14.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
            // Itens baixados
            if(state.downloadedItems.isNotEmpty()) {
                item { Text("Pronto para Viagem",color=DendeColors.Text,fontSize=15.sp,fontWeight=FontWeight.Bold) }
                items(state.downloadedItems) { item ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(DendeColors.Card).padding(10.dp),
                        Arrangement.spacedBy(10.dp), Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CheckCircle,null,tint=DendeColors.Success,modifier=Modifier.size(20.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title,color=DendeColors.Text,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                            Text("${item.sizeLabel} • ${item.quality}",color=DendeColors.TextSub,fontSize=10.sp)
                        }
                        IconButton(onClick={vm.deleteItem(item.id)},modifier=Modifier.size(30.dp)) {
                            Icon(Icons.Rounded.Delete,null,tint=DendeColors.TextHint,modifier=Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
