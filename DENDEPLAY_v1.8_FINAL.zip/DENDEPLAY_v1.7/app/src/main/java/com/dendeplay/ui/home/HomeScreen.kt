package com.dendeplay.ui.home

import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dendeplay.domain.model.SearchResult
import com.dendeplay.ui.components.*
import com.dendeplay.ui.theme.DendeColors

@Composable
fun HomeScreen(
    onMediaClick:  (SearchResult) -> Unit,
    onSearchClick: () -> Unit,
    onProfileClick: () -> Unit,
    vm: HomeViewModel = hiltViewModel(),
) {
    val state by vm.state.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = DendeColors.Background,
        topBar = {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                DendeLogo(38.dp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onSearchClick) {
                        Icon(Icons.Rounded.Search, null, tint = DendeColors.Text, modifier = Modifier.size(24.dp))
                    }
                    Box(
                        Modifier.size(36.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(DendeColors.FlameOrange, DendeColors.PrimaryDark)))
                            .clickable(onClick = onProfileClick),
                        Alignment.Center
                    ) {
                        Text("D", color = DendeColors.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    }
                }
            }
        }
    ) { pad ->
        when (val s = state) {
            is HomeUiState.Loading -> HomeShimmer(pad)
            is HomeUiState.Error   -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Warning, null, tint = DendeColors.FlameOrange, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(s.message, color = DendeColors.TextSub)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = vm::retry, colors = ButtonDefaults.buttonColors(DendeColors.Primary)) {
                        Text("Tentar novamente", color = Color.Black)
                    }
                }
            }
            is HomeUiState.Success -> LazyColumn(
                Modifier.fillMaxSize().padding(top = pad.calculateTopPadding()),
                contentPadding = PaddingValues(bottom = 28.dp)
            ) {
                item { Spacer(Modifier.height(4.dp)) }

                // ── Em Alta ──────────────────────────────
                if (s.trending.isNotEmpty()) {
                    item { SectionHeader("Em Alta", icon = Icons.Rounded.LocalFireDepartment) }
                    item { BannerRow(s.trending, onMediaClick) }
                }

                // ── Continue Assistindo ───────────────────
                if (s.continueWatching.isNotEmpty()) {
                    item { SectionHeader("Continue Assistindo", Modifier.padding(top = 20.dp), Icons.Rounded.PlayCircle) }
                    item { ContinueRow(s.continueWatching, onMediaClick) }
                }

                // ── Animes ────────────────────────────────
                if (s.animes.isNotEmpty()) {
                    item { SectionHeader("Animes", Modifier.padding(top = 20.dp), Icons.Rounded.AutoAwesome) }
                    item { PosterRow(s.animes, onMediaClick) }
                }

                // ── Novos Episódios ───────────────────────
                if (s.newEpisodes.isNotEmpty()) {
                    item { SectionHeader("Novos Episódios", Modifier.padding(top = 20.dp), Icons.Rounded.FiberNew) }
                    item { EpisodeRow(s.newEpisodes, onMediaClick) }
                }

                // ── Filmes ────────────────────────────────
                if (s.films.isNotEmpty()) {
                    item { SectionHeader("Filmes", Modifier.padding(top = 20.dp), Icons.Rounded.Movie) }
                    item { FilmRow(s.films, onMediaClick) }
                }

                // ── Séries ────────────────────────────────
                if (s.series.isNotEmpty()) {
                    item { SectionHeader("Séries", Modifier.padding(top = 20.dp), Icons.Rounded.Tv) }
                    item { PosterRow(s.series, onMediaClick) }
                }

                // ── 4K / Ultra HD ─────────────────────────
                if (s.ultraHD.isNotEmpty()) {
                    item { UltraHDHeader() }
                    item { UltraHDRow(s.ultraHD, onMediaClick) }
                }

                // ── Recém Adicionados ─────────────────────
                if (s.recentlyAdded.isNotEmpty()) {
                    item { SectionHeader("Recém Adicionados", Modifier.padding(top = 20.dp), Icons.Rounded.NewReleases) }
                    item { PosterRow(s.recentlyAdded, onMediaClick) }
                }

                // ── Recomendados ──────────────────────────
                if (s.recommended.isNotEmpty()) {
                    item { SectionHeader("Recomendados para Você", Modifier.padding(top = 20.dp), Icons.Rounded.Star) }
                    item { PosterRow(s.recommended, onMediaClick) }
                }
            }
        }
    }
}

// ── Section Headers ───────────────────────────────────────

@Composable
private fun SectionHeader(
    title:    String,
    modifier: Modifier = Modifier,
    icon:     androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    Row(
        modifier.padding(start = 16.dp, bottom = 10.dp, end = 16.dp),
        Arrangement.spacedBy(6.dp), Alignment.CenterVertically
    ) {
        if (icon != null)
            Icon(icon, null, tint = DendeColors.Primary, modifier = Modifier.size(16.dp))
        Text(title, color = DendeColors.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, null, tint = DendeColors.TextHint, modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun UltraHDHeader() {
    val shimmer = shimmerBrush()
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 10.dp),
        Arrangement.spacedBy(8.dp), Alignment.CenterVertically
    ) {
        Box(
            Modifier.background(
                Brush.horizontalGradient(listOf(Color(0xFFB8860B), DendeColors.FlameGold, Color(0xFFFFE066))),
                RoundedCornerShape(6.dp)
            ).padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text("4K", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        }
        Text("Ultra HD", color = DendeColors.FlameGold, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, null, tint = DendeColors.TextHint, modifier = Modifier.size(16.dp))
    }
}

// ── Content Rows ──────────────────────────────────────────

@Composable
private fun BannerRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        itemsIndexed(items, key = { _, it -> it.provider + it.id }) { i, item ->
            Box(
                Modifier.width(if (i == 0) 232.dp else 178.dp).height(134.dp)
                    .clip(RoundedCornerShape(12.dp)).dendeClickable { onClick(item) }
            ) {
                AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.8f)), startY = 55f)))
                if (item.rating > 0)
                    Box(Modifier.align(Alignment.TopStart).padding(7.dp)
                        .background(DendeColors.Primary.copy(.92f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp)) {
                        Text("%.1f".format(item.rating), color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                MediaTypeBadge(item.mediaType, Modifier.align(Alignment.TopEnd).padding(7.dp))
                Text(item.title, color = DendeColors.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
            }
        }
    }
}

@Composable
private fun EpisodeRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.provider + it.id }) { item ->
            Column(Modifier.width(180.dp).dendeClickable { onClick(item) }) {
                Box(Modifier.fillMaxWidth().height(104.dp).clip(RoundedCornerShape(10.dp))) {
                    AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
                    Box(Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.6f)), startY = 40f)))
                    Box(Modifier.align(Alignment.Center).size(36.dp)
                        .background(Color.Black.copy(.5f), CircleShape), Alignment.Center) {
                        Icon(Icons.Rounded.PlayArrow, null, tint = DendeColors.White, modifier = Modifier.size(22.dp))
                    }
                    Box(Modifier.align(Alignment.TopEnd).padding(6.dp)
                        .background(DendeColors.Primary, RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text("NOVO", color = Color.Black, fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(item.title, color = DendeColors.Text, fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (item.episodes > 0) "Ep. ${item.episodes}" else "Novo",
                    color = DendeColors.TextSub, fontSize = 10.5.sp)
            }
        }
    }
}

@Composable
private fun ContinueRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.provider + it.id }) { item ->
            Box(Modifier.width(252.dp).height(146.dp).clip(RoundedCornerShape(12.dp)).dendeClickable { onClick(item) }) {
                AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.88f)), startY = 50f)))
                Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
                    Text(item.title, color = DendeColors.White, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("Próximo episódio", color = DendeColors.TextSub, fontSize = 10.sp)
                }
                Box(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp).size(40.dp)
                    .background(DendeColors.Primary.copy(.9f), CircleShape), Alignment.Center) {
                    Icon(Icons.Rounded.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(24.dp))
                }
                // Barra de progresso — largura 0 por padrão até integração com WatchProgress
                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp)
                    .background(Color.White.copy(.18f))) {
                    // Progresso real virá de WatchProgress via PlayerViewModel ao reproduzir
                    if (item.episodes > 0) {
                        // Indicador visual mínimo para itens em andamento
                        Box(Modifier.fillMaxWidth(.15f).fillMaxHeight()
                            .background(Brush.horizontalGradient(listOf(DendeColors.FlameOrange, DendeColors.FlameGold))))
                    }
                }
            }
        }
    }
}

@Composable
private fun FilmRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(items, key = { it.provider + it.id }) { item ->
            Box(Modifier.width(130.dp).height(190.dp).clip(RoundedCornerShape(10.dp)).dendeClickable { onClick(item) }) {
                AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.85f)), startY = 80f)))
                if (item.rating > 0)
                    Row(Modifier.align(Alignment.BottomStart).padding(7.dp),
                        Arrangement.spacedBy(3.dp), Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Star, null, tint = DendeColors.FlameGold, modifier = Modifier.size(11.dp))
                        Text("%.1f".format(item.rating), color = DendeColors.FlameGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                if (item.language == "pt-BR")
                    Box(Modifier.align(Alignment.TopStart).padding(5.dp)
                        .background(Color(0xFF007A33), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)) {
                        Text("DUB", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black)
                    }
            }
        }
    }
}

@Composable
private fun UltraHDRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.provider + it.id }) { item ->
            Box(
                Modifier.width(220.dp).height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.5.dp,
                        Brush.horizontalGradient(listOf(Color(0xFFB8860B), DendeColors.FlameGold)),
                        RoundedCornerShape(12.dp))
                    .dendeClickable { onClick(item) }
            ) {
                AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
                Box(Modifier.fillMaxSize().background(Color.Black.copy(.35f)))
                Box(Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(.82f)), startY = 50f)))
                // Badge 4K
                Box(Modifier.align(Alignment.TopEnd).padding(7.dp)
                    .background(Brush.horizontalGradient(listOf(Color(0xFFB8860B), DendeColors.FlameGold)),
                        RoundedCornerShape(5.dp))
                    .padding(horizontal = 7.dp, vertical = 3.dp)) {
                    Text("4K", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                }
                Column(Modifier.align(Alignment.BottomStart).padding(9.dp)) {
                    Text(item.title, color = DendeColors.White, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Ultra Alta Definição", color = DendeColors.FlameGold, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
fun PosterCard(item: SearchResult, onClick: (SearchResult) -> Unit) {
    Column(Modifier.width(104.dp).dendeClickable { onClick(item) }) {
        Box(Modifier.fillMaxWidth().height(144.dp).clip(RoundedCornerShape(10.dp))) {
            AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                error = coil.compose.rememberAsyncImagePainter(com.dendeplay.R.drawable.ic_logo))
            if (item.language == "pt-BR")
                Box(Modifier.align(Alignment.TopStart).padding(4.dp)
                    .background(Color(0xFF007A33), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)) {
                    Text("BR", color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                }
            MediaTypeBadge(item.mediaType, Modifier.align(Alignment.TopEnd).padding(4.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(item.title, color = DendeColors.Text, fontSize = 10.5.sp,
            fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 13.sp)
    }
}

@Composable
private fun MediaTypeBadge(mediaType: String, modifier: Modifier = Modifier) {
    val (label, color) = when (mediaType) {
        "movie" -> "Filme" to Color(0xFF1565C0).copy(.85f)
        "tv"    -> "Série" to Color(0xFF6A1B9A).copy(.85f)
        else    -> "Anime" to DendeColors.Primary.copy(.85f)
    }
    Box(modifier.background(color, RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp)) {
        Text(label, color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PosterRow(items: List<SearchResult>, onClick: (SearchResult) -> Unit) {
    LazyRow(
        contentPadding       = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(items, key = { it.provider + it.id }) { item -> PosterCard(item, onClick) }
    }
}

@Composable
private fun HomeShimmer(pad: PaddingValues) {
    val br = shimmerBrush()
    LazyColumn(
        Modifier.padding(top = pad.calculateTopPadding()),
        contentPadding      = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Box(Modifier.width(100.dp).height(18.dp).clip(RoundedCornerShape(4.dp)).background(br)) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { repeat(3) { Box(Modifier.width(200.dp).height(132.dp).clip(RoundedCornerShape(12.dp)).background(br)) } } }
        item { Box(Modifier.width(140.dp).height(18.dp).clip(RoundedCornerShape(4.dp)).background(br)) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { repeat(3) { Box(Modifier.width(180.dp).height(104.dp).clip(RoundedCornerShape(10.dp)).background(br)) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { repeat(5) { Box(Modifier.width(104.dp).height(144.dp).clip(RoundedCornerShape(10.dp)).background(br)) } } }
        item { Box(Modifier.width(80.dp).height(18.dp).clip(RoundedCornerShape(4.dp)).background(br)) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { repeat(3) { Box(Modifier.width(220.dp).height(130.dp).clip(RoundedCornerShape(12.dp)).background(br)) } } }
    }
}
