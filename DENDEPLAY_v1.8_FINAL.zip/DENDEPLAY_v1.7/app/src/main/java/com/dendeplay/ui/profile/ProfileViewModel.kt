package com.dendeplay.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dendeplay.account.UserAccount
import com.dendeplay.account.UserAccountManager
import com.dendeplay.api.AudioPreference
import com.dendeplay.api.UserPreferences
import com.dendeplay.api.providers.LocalDataProvider
import com.dendeplay.data.repository.MediaRepository
import com.dendeplay.domain.model.SearchResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val repo:         MediaRepository,
    private val accountMgr:   UserAccountManager,
    private val localProvider: LocalDataProvider,
) : ViewModel() {

    private val _favs        = MutableStateFlow<List<SearchResult>>(emptyList())
    private val _history     = MutableStateFlow<List<SearchResult>>(emptyList())
    private val _preferences = MutableStateFlow(localProvider.getPreferences())

    val favs:          StateFlow<List<SearchResult>> = _favs.asStateFlow()
    val history:       StateFlow<List<SearchResult>> = _history.asStateFlow()
    val account:       StateFlow<UserAccount>        = accountMgr.account
    val preferences:   StateFlow<UserPreferences>    = _preferences.asStateFlow()
    val providerCount: Int                           get() = repo.getProviderCount()

    init {
        viewModelScope.launch {
            // Ambas as operações em coroutine — evita trabalho na main thread no init
            _favs.value = repo.getFavorites()
            repo.getContinueWatching().onSuccess { _history.value = it }
        }
    }

    fun clearCache() = repo.clearCache()

    fun setAutoSkip(on: Boolean) = updatePrefs { it.copy(autoSkipIntro = on) }
    fun setAutoNext(on: Boolean) = updatePrefs { it.copy(autoNextEpisode = on) }
    fun setAudioPref(p: AudioPreference) = updatePrefs { it.copy(audioPreference = p) }
    fun setPreferDubbed(on: Boolean)     = updatePrefs { it.copy(preferDubbed = on) }

    private fun updatePrefs(update: (UserPreferences) -> UserPreferences) {
        val new = update(_preferences.value)
        _preferences.value = new
        localProvider.savePreferences(new)
    }
}
