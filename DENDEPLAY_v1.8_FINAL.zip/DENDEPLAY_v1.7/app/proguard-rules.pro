# ═══════════════════════════════════════════════════════════
# DENDÊPLAY v1.3 — ProGuard Rules
# ═══════════════════════════════════════════════════════════

# Go SDK / gomobile
-keep class go.** { *; }
-keep class golang.** { *; }
-keep class sdk.GoAnimeSDK { *; }
-keep class sdk.** { public *; }
-keepclassmembers class sdk.** { *; }
-dontwarn sdk.**

# Modelos de domínio
-keep class com.dendeplay.domain.model.** { *; }
-keepclassmembers class com.dendeplay.domain.model.** { *; }

# Hilt
-dontwarn com.google.dagger.**
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class * { *; }
-keep @dagger.hilt.InstallIn class * { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }

# Compose
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# Navigation
-keepnames class androidx.navigation.** { *; }

# Lifecycle / ViewModel
-keep class androidx.lifecycle.** { *; }
-keepclassmembers class * extends androidx.lifecycle.ViewModel { *; }

# ExoPlayer / Media3
-keep class androidx.media3.** { *; }
-keep interface androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Google Cast SDK
-keep class com.google.android.gms.cast.** { *; }
-keep class com.google.android.gms.cast.framework.** { *; }
-dontwarn com.google.android.gms.**

# OkHttp
-dontwarn okhttp3.**
-keep class okhttp3.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-dontwarn sun.misc.**

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-keep,includedescriptorclasses class com.dendeplay.**$$serializer { *; }

# Room
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-dontwarn androidx.room.**

# WorkManager
-keep class androidx.work.** { *; }

# Cast Platform
-keep class com.dendeplay.cast.AdvancedCastManager { public *; }
-keep interface com.dendeplay.cast.CastCallback { *; }
-keep class com.dendeplay.cast.CastDevice { *; }
-keep enum com.dendeplay.cast.CastType { *; }

# Remover logs em release
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int d(...);
    public static int v(...);
    public static int i(...);
}

# Otimizações
-optimizationpasses 5
-dontusemixedcaseclassnames
-verbose
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
