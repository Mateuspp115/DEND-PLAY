# DENDÊPLAY — STATUS DO PROJETO
## Guia permanente para não se perder no desenvolvimento
**Última atualização:** v1.7.0 | Março 2026

---

## TL;DR — O que é este projeto

App Android de streaming de animes, filmes e séries em PT-BR.
- Backend: Go SDK com 26 providers (scraping de sites públicos)
- Frontend: Kotlin + Jetpack Compose
- Cast: 6 plataformas de TV
- Versão atual: 1.7.0

---

## Onde está cada coisa

```
DENDÊPLAY/
├── sdk/                        ← SDK Go (lógica de busca, cache, providers)
│   ├── sdk.go                  ← Ponto de entrada (gomobile)
│   ├── providers/              ← 26 sites scrapers
│   ├── cache/                  ← DiskCache simples
│   ├── cache_predictive.go     ← Cache que aprende padrões do usuário
│   ├── provider_health.go      ← Monitor de saúde dos providers
│   ├── rate_limiter.go         ← Limite de requests por provider
│   └── search_context.go       ← Busca paralela + extrator de vídeo
│
├── app/src/main/java/com/dendeplay/
│   ├── ui/                     ← Telas (Compose)
│   │   ├── home/               ← Tela inicial
│   │   ├── search/             ← Busca universal
│   │   ├── detail/             ← Detalhe de anime/filme + episódios
│   │   ├── player/             ← Player de vídeo (ExoPlayer)
│   │   ├── genres/             ← Abas por gênero (11 gêneros)
│   │   ├── downloads/          ← Downloads offline
│   │   ├── profile/            ← Perfil + configurações
│   │   ├── credits/            ← Sobre e créditos (dual license)
│   │   ├── social/             ← Chat por série
│   │   └── travel/             ← Modo Viagem
│   ├── cast/                   ← Sistema de cast para TVs
│   │   ├── AdvancedCastManager.kt    ← Orquestrador principal
│   │   ├── CastPickerSheet.kt        ← UI de seleção de dispositivo
│   │   ├── CastRemoteControl.kt      ← Controle remoto durante cast
│   │   └── platform/                 ← Managers por fabricante
│   ├── player/                 ← Lógica do player
│   │   ├── SkipIntroManager.kt ← Skip abertura/encerramento inteligente
│   │   └── QualityManager.kt   ← Seleção de qualidade de vídeo
│   ├── api/                    ← API unificada (local/cloud)
│   │   ├── DendeAPI.kt         ← Ponto de entrada da API
│   │   └── providers/          ← LocalDataProvider (offline)
│   ├── account/                ← Conta Google (estrutura pronta)
│   └── di/AppModule.kt         ← Injeção de dependências (Hilt)
│
├── .github/workflows/build.yml ← CI/CD GitHub Actions (5 jobs)
├── docs/
│   ├── PLAYSTORE_LEGAL_ANALYSIS.md ← Análise legal para distribuição
│   └── RELATORIO_DENDEPLAY.md      ← Relatório técnico completo
├── LICENSE                     ← MIT License (GoAnime/Krone)
├── LICENSE_DENDEPLAY           ← DENDÊPLAY License (Mateus TinkWink)
├── PROJECT_STATUS.md           ← ESTE ARQUIVO
└── README.md                   ← Instruções de build
```

---

## Como fazer o build

```bash
# 1. Compilar SDK Go → AAR
cd sdk
go mod download
go install golang.org/x/mobile/cmd/gomobile@latest
gomobile init
gomobile bind -target=android/arm64,android/arm,android/amd64 \
  -androidapi=26 -trimpath \
  -o ../app/libs/dendeplay_sdk.aar .

# 2. Compilar APK
cd ..
chmod +x gradlew
./gradlew assembleDebug    # APK de teste
./gradlew assembleRelease  # APK final (precisa do keystore)
```

Para o CI/CD (GitHub Actions):
- Push em `main` → APK debug automático
- Tag `v1.7.0` → APK release assinado + GitHub Release

---

## Estado de cada funcionalidade

| Funcionalidade | Status | Onde está |
|---|---|---|
| Busca universal (26 providers) | Completo | sdk/providers/ |
| Player ExoPlayer | Completo | ui/player/ |
| Skip abertura/encerramento | Completo | player/SkipIntroManager.kt |
| Qualidade selecionável | Completo | player/QualityManager.kt |
| Cast Chromecast | Completo | cast/AdvancedCastManager.kt |
| Cast DLNA | Completo | cast/platform/ |
| Cast Samsung (legacy + SmartThings) | Completo | cast/platform/ |
| Cast LG webOS (3-8) | Completo | cast/platform/ |
| Cast Roku TV | Completo | cast/platform/ |
| Cast Android TV | Básico | cast/platform/ |
| Abas por gênero | Completo | ui/genres/ |
| Modo Surpresa inteligente | Completo | ui/components/SurpriseModeViewModel |
| Chat por série | Completo (local) | ui/social/ |
| Conta Google | Estrutura pronta | account/UserAccountManager.kt |
| API ARUAN (IA) | Estrutura pronta | api/DendeAPI.kt |
| Downloads offline | Completo | ui/downloads/ |
| Modo Viagem | Completo | ui/travel/ |
| Dual License na tela | Completo | ui/credits/CreditsScreen.kt |

---

## Funcionalidades que precisam de servidor (para o futuro)

Quando você tiver um servidor:

1. **Google Sign-In real**
   - Criar projeto no Firebase: console.firebase.google.com
   - Baixar `google-services.json` → colocar em `app/`
   - Substituir `YOUR_GOOGLE_WEB_CLIENT_ID` em `UserAccountManager.kt`

2. **Chat entre usuários**
   - Implementar servidor WebSocket
   - Substituir SharedPreferences por API REST em `ChatViewModel.kt`

3. **ARUAN IA**
   - Configurar: `dendeApi.setAruanEndpoint("http://seu-servidor/aruan")`
   - A interface já está pronta em `DendeAPI.kt`

4. **Sync entre dispositivos**
   - Implementar `CloudSyncService` (interface já definida em `DendeAPI.kt`)
   - Chamar `userAccountManager.syncToCloud()`

---

## Dispositivos testados / compatibilidade

| Dispositivo | Android | Status |
|---|---|---|
| Moto G35 | 15 (API 35) | Principal de testes |
| Samsung A32 | 11 (API 30) | Compatível |
| Samsung A10 | 9 (API 28) | Compatível |
| Samsung J5 | 8.0 (API 26) | Compatível (mínimo) |

**Nota para dispositivos com pouca RAM (A10, J5):**
O `DendePlayApp.kt` implementa `onTrimMemory()` que libera o cache do Coil automaticamente quando o SO sinalizar pressão de memória.

---

## Cast — como testar

| Plataforma | Como testar |
|---|---|
| Chromecast | Conectar ao mesmo Wi-Fi, botão Cast no player |
| Samsung TV | Wi-Fi igual, o app descobre automaticamente |
| LG TV | Wi-Fi igual, descoberta automática |
| Roku TV | Wi-Fi igual, descoberta via SSDP |
| Qualquer TV | DLNA/UPnP — padrão para TVs antigas |

Se a TV não aparecer:
- Verificar se está na mesma rede Wi-Fi
- Desabilitar firewall no roteador
- Fallback manual: implementar campo de IP em `CastPickerSheet.kt`

---

## Licenças

Este projeto usa dual licensing:

**MIT License** (GoAnime original)
- Autor: Krone © 2023
- Uso livre, inclusive comercial

**DENDÊPLAY License** (modificações)
- Autor: Mateus "TinkWink" © 2026
- Uso pessoal e não comercial apenas
- Proibido: vender, anúncios, remoção de créditos

---

## Histórico de versões

| Versão | Destaque |
|---|---|
| v1.0 | Go SDK + Kotlin/Compose básico |
| v1.1 | Cast básico (Chromecast + DLNA) |
| v1.2 | Dual license, ProGuard, zero emojis |
| v1.3 | Cast avançado (6 plataformas), análise legal |
| v1.4 | Correção de 10 bugs críticos, SDK melhorado |
| v1.5 | API ARUAN, abas gênero, surpresa, chat, conta Google |
| v1.6 | SkipIntro inteligente, qualidade selecionável, Samsung SmartThings, docs |

---

*DENDÊPLAY © 2026 Mateus "TinkWink" | GoAnime © 2023 Krone — MIT*
